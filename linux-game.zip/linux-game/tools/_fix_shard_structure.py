import yaml
from pathlib import Path

fixes_options = {
    'whoami': ['No options — just print the effective user name'],
    'printenv': ['VARIABLE — print just this variable', '-i — include variables inherited from the parent', 'No arguments — print every exported variable'],
    'bg': ['%N — send job N to the background', 'No argument — act on the current job'],
    'fg': ['%N — bring job N to the foreground', 'No argument — act on the current job'],
    'nohup': ['COMMAND — run COMMAND immune to hangups', 'Output is redirected to nohup.out unless you redirect it yourself'],
    'sleep': ['SECONDS — sleep for SECONDS (accepts decimals like 0.5)', 'No options — just a duration argument'],
}

# safe examples to inject (cmd, note) for commands lacking any safe example
fixes_safe = {
    'bg': ('bg %1', 'Sends job 1 to the background — safe: nothing new is started, only an existing job is resumed.'),
    'fg': ('jobs', 'Lists current jobs first; fg %1 would bring job 1 back to the foreground when you need it.'),
    'pkill': ('pgrep -l sleep', 'Preview the matching PIDs with pgrep before pkill ever signals anything — safe reconnaissance.'),
    'renice': ('renice -n 0 -p $$', 'Adjusts the nice level of your own shell ($$) to 0 — safe: touches only your own process.'),
    'apt': ('apt --version', 'Prints apt version — offline-safe, contacts no repository.'),
    'apt-get': ('apt-get --version', 'Prints apt-get version — offline-safe, contacts no repository.'),
    'su': ('su --help', 'Prints usage help — safe: does not switch users.'),
    'useradd': ('useradd --help', 'Prints usage help — safe: creates nobody.'),
    'usermod': ('usermod --help', 'Prints usage help — safe: modifies nobody.'),
    'userdel': ('userdel --help', 'Prints usage help — safe: deletes nobody.'),
    'passwd': ('passwd --help', 'Prints usage help — safe: changes nobody.'),
    'groupadd': ('groupadd --help', 'Prints usage help — safe: creates nobody.'),
    'sudo': ('sudo -V', 'Prints sudo version — safe: no command is elevated.'),
    'traceroute': ('traceroute --help', 'Prints usage help — safe: sends no packets.'),
    'dig': ('dig -v', 'Prints version — safe: performs no lookup.'),
    'nslookup': ('nslookup -help', 'Prints usage help — safe: queries nothing.'),
    'scp': ('scp -V', 'Prints OpenSSH scp version — safe: copies nothing.'),
    'rsync': ('rsync --version', 'Prints rsync version — safe: syncs nothing.'),
    'host': ('host -V', 'Prints version — safe: performs no lookup.'),
}

for i in range(1, 6):
    p = Path(f'linuxgame/commands/_shard{i}.yaml')
    d = yaml.safe_load(open(p, encoding='utf-8'))
    changed = []
    for c in d['commands']:
        n = c['name']
        if 'options' not in c and n in fixes_options:
            c['options'] = fixes_options[n]
            changed.append(f'{n}:options')
        ex = c.get('examples', [])
        if not any(e.get('safe') for e in ex) and n in fixes_safe:
            cmd, note = fixes_safe[n]
            ex.append({'cmd': cmd, 'note': note, 'safe': True})
            c['examples'] = ex
            changed.append(f'{n}:safe-example')
    if changed:
        open(p, 'w', encoding='utf-8', newline='\n').write(
            yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=100))
        print(f'shard{i} fixed: {changed}')
print('done')
