#!/usr/bin/env python3
"""Generate or verify linuxgame/game/secrets.yaml for Nimbus Casebook.

The chain levels in levels.yaml never store passwords; this tool mints them
into secrets.yaml (structure: version 1 + passwords mapping id -> password):

  * id 0 is always the PUBLIC start password ``begin``.
  * every id >= 1 gets a unique 16-character password drawn from [a-z2-9]
    (ambiguous 0/O/1/l/I removed) using the ``secrets`` CSPRNG.

Run it ONCE after the act shards have been merged into levels.yaml, then treat
the output as a committed secret file.  Re-running with no arguments rotates
every non-zero password on purpose -- there is deliberately no seed.

Usage:
  python tools/gen_secrets.py                  # write secrets.yaml
  python tools/gen_secrets.py --check          # verify existing secrets.yaml
  python tools/gen_secrets.py --levels P --out P

Exit codes: 0 = ok, 1 = check problems, 2 = fatal (unreadable input).
"""
import argparse
import secrets
import string
import sys
from pathlib import Path

import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_GAME_LEVELS = REPO_ROOT / "linuxgame" / "game" / "levels.yaml"
DEFAULT_ALT_LEVELS = REPO_ROOT / "linuxgame" / "levels.yaml"
DEFAULT_OUT = REPO_ROOT / "linuxgame" / "game" / "secrets.yaml"

PUBLIC_START_PASSWORD = "begin"
PASSWORD_LEN = 16
AMBIGUOUS = set("0O1lI")
ALPHABET = "".join(
    c for c in string.ascii_lowercase + string.digits if c not in AMBIGUOUS
)


def default_levels_path():
    """Prefer the runtime file (game/levels.yaml), fall back to the merge target."""
    for cand in (DEFAULT_GAME_LEVELS, DEFAULT_ALT_LEVELS):
        if cand.is_file():
            return cand
    return DEFAULT_GAME_LEVELS


def load_level_ids(levels_path):
    """Return the chain level ids from levels.yaml.

    New schema: each entry carries an explicit integer `id`.
    Old prototype: no id fields -> the list index is the level id.
    """
    try:
        doc = yaml.safe_load(levels_path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise SystemExit(f"ERROR: cannot read levels file {levels_path}: {exc}")
    except yaml.YAMLError as exc:
        raise SystemExit(f"ERROR: cannot parse {levels_path} as YAML: {exc}")
    if not isinstance(doc, dict) or not isinstance(doc.get("levels"), list):
        raise SystemExit(
            f"ERROR: {levels_path} has no top-level 'levels' list "
            "-- expected the merged levels.yaml (docs/AUTHORING.md section 1)")
    entries = doc["levels"]
    if not entries:
        raise SystemExit(f"ERROR: {levels_path} contains an empty 'levels' list")
    ids = []
    for i, lv in enumerate(entries):
        if isinstance(lv, dict) and "id" in lv:
            try:
                ids.append(int(lv["id"]))
            except (TypeError, ValueError):
                raise SystemExit(
                    f"ERROR: levels[{i}].id is not an integer: {lv['id']!r}")
        else:
            ids.append(i)
    if len(set(ids)) != len(ids):
        raise SystemExit(f"ERROR: duplicate level ids in {levels_path}: {ids}")
    return ids


def make_password(existing):
    """One 16-char CSPRNG password, unique against `existing` (mutated in place)."""
    while True:
        pw = "".join(secrets.choice(ALPHABET) for _ in range(PASSWORD_LEN))
        if pw not in existing:
            existing.add(pw)
            return pw


def build_passwords(ids):
    """id 0 -> 'begin'; every other id -> fresh unique secret."""
    passwords = {}
    used = set()
    for lid in sorted(ids):
        if lid == 0:
            passwords[0] = PUBLIC_START_PASSWORD
        else:
            passwords[lid] = make_password(used)
    return passwords


def write_secrets(out_path, passwords):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc = {"version": 1, "passwords": dict(sorted(passwords.items()))}
    out_path.write_text(
        yaml.safe_dump(doc, sort_keys=False, allow_unicode=True),
        encoding="utf-8", newline="\n")


def check_secrets(level_ids, out_path):
    """Return a list of PROBLEM strings; empty list means the file is valid."""
    problems = []
    if not out_path.is_file():
        return [f"secrets file not found: {out_path} (run tools/gen_secrets.py)"]
    try:
        doc = yaml.safe_load(out_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        return [f"cannot parse {out_path}: {exc}"]
    if not isinstance(doc, dict):
        return [f"{out_path}: top level must be a mapping with version/passwords"]
    if doc.get("version") != 1:
        problems.append(f"version: expected 1, got {doc.get('version')!r}")
    raw = doc.get("passwords")
    if not isinstance(raw, dict):
        problems.append("passwords: missing or not a mapping")
        return problems
    try:
        pws = {int(k): (v if isinstance(v, str) else "") for k, v in raw.items()}
    except (TypeError, ValueError) as exc:
        problems.append(f"passwords: non-integer id key ({exc})")
        return problems
    expected, actual = set(level_ids), set(pws)
    for lid in sorted(expected - actual):
        problems.append(f"passwords: missing id {lid}")
    for lid in sorted(actual - expected):
        problems.append(f"passwords: unexpected id {lid} (not in levels.yaml)")
    if 0 in pws and pws[0] != PUBLIC_START_PASSWORD:
        problems.append(
            f"passwords[0]: expected the public start password "
            f"{PUBLIC_START_PASSWORD!r}, got {pws[0]!r}")
    seen = set()
    for lid in sorted(actual & expected):
        if lid == 0:
            continue
        pw = pws[lid]
        if len(pw) != PASSWORD_LEN:
            problems.append(
                f"passwords[{lid}]: length {len(pw)} != {PASSWORD_LEN}")
        bad = sorted({c for c in pw if c not in ALPHABET})
        if bad:
            problems.append(
                f"passwords[{lid}]: forbidden characters {bad} "
                f"(allowed: a-z2-9, ambiguous 0O1lI removed)")
        if pw in seen:
            problems.append(f"passwords[{lid}]: duplicate of another level")
        seen.add(pw)
    return problems


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Generate or verify secrets.yaml for Nimbus Casebook.")
    ap.add_argument("--levels", metavar="PATH",
                    help="levels.yaml to read chain ids from "
                         "(default: linuxgame/game/levels.yaml)")
    ap.add_argument("--out", metavar="PATH",
                    help="secrets.yaml to write/check "
                         "(default: linuxgame/game/secrets.yaml)")
    ap.add_argument("--check", action="store_true",
                    help="verify an existing secrets.yaml instead of writing")
    args = ap.parse_args(argv)

    levels_path = Path(args.levels) if args.levels else default_levels_path()
    out_path = Path(args.out) if args.out else DEFAULT_OUT
    try:
        level_ids = load_level_ids(levels_path)
    except SystemExit as exc:
        print(exc)
        return 2

    if args.check:
        problems = check_secrets(level_ids, out_path)
        for p in problems:
            print(f"PROBLEM: {p}")
        if problems:
            print(f"CHECK FAILED: {len(problems)} problem(s) "
                  f"({out_path} vs {levels_path})")
            return 1
        print(f"OK: {out_path} covers {len(level_ids)} level ids "
              f"(1 public + {len(level_ids) - 1} secret)")
        return 0

    passwords = build_passwords(level_ids)
    write_secrets(out_path, passwords)
    print(f"wrote {len(passwords)} passwords (1 public + {len(passwords) - 1} secret)")
    print(f"  -> {out_path} (from {levels_path}); "
          "run once, then treat as a committed secret file")
    return 0


if __name__ == "__main__":
    sys.exit(main())
