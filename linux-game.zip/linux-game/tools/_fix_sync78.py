import yaml
from pathlib import Path

# Extra safe examples to inject for commands with <3 safe examples
extra_safe = {
    # shard2
    'join': [('join /etc/hostname /etc/hostname', 'Joining a file with itself prints each line once — safe self-demo.')],
    'cmp': [('cmp -s /etc/hostname /etc/hostname; echo $?', 'Silent compare of identical files; exit code 0 proves a match.')],
    'comm': [('comm -3 /etc/hostname /etc/hostname || true', 'Comparing a file with itself leaves column 3 empty — nothing unique.')],
    'nl': [('nl /etc/group | head -3', 'Numbers the first three group lines — read-only.')],
    'fold': [('fold -w 10 /etc/hostname', 'Wraps the hostname at 10 columns — display only.')],
    'column': [('printf "a\\tb\\n1\\t2\\n" | column -t', 'Tiny two-row table, aligned — pure formatting.')],
    'pr': [('pr -t -n /etc/hostname', 'Numbered, headerless print view of the hostname.')],
    'fmt': [('printf "a b c d e f g h i j k l m n o p\\n" | fmt -w 10', 'Rewraps a long line at 10 chars.')],
    'shuf': [('seq 1 5 | shuf', 'Shuffles five numbers — harmless demo.')],
    'od': [('printf "hi\\n" | od -c', 'Shows the two bytes plus newline in character form.')],
    'zgrep': [('printf "alpha\\nbeta\\n" | gzip > /tmp/t.gz && zgrep beta /tmp/t.gz', 'Compresses a tiny file then searches inside it.')],
    'zcat': [('printf "hello\\n" | gzip | zcat', 'Compresses then immediately prints back.')],
    # shard3
    'uname': [('uname -a', 'Prints all system identity fields at once.')],
    'hostname': [('hostname -f 2>/dev/null || hostname', 'Prints the fully-qualified hostname, falling back to short name.')],
    'whoami': [('whoami --help | head -3', 'Shows usage options safely.')],
    'cal': [('cal 2>/dev/null || ncal 2>/dev/null || echo "calendar tool not installed"', 'Prints this month calendar (ncal package).')],
    'df': [('df -h /', 'Human-readable usage of the root filesystem.')],
    'du': [('du -sh /etc 2>/dev/null | head -1', 'Summarizes /etc size — read-only.')],
    'env': [('env | head -5', 'First five environment variables.')],
    'set': [('set | head -5', 'First five shell variables/options.')],
    'uptime': [('uptime -p 2>/dev/null || uptime', 'Pretty-printed uptime.')],
    'free': [('free -h', 'Human-readable memory summary.')],
    'ps': [('ps -eo pid,comm --sort=pid | head -5', 'First five processes by PID.')],
    'bg': [('jobs', 'Lists current jobs — safe inspection before bg/fg.')],
    'fg': [('jobs', 'Lists current jobs — safe inspection before fg.')],
    'jobs': [('jobs -l', 'Lists jobs with PIDs — read-only.')],
    'nohup': [('nohup --help | head -3', 'Shows nohup usage without launching anything.')],
    'sleep': [('sleep 0.1 && echo done', 'Tiny half-second pause then a message.')],
    'time': [('time true', 'Times the no-op command true.')],
    'top': [('top -b -n1 | head -8', 'Single batch snapshot of top — no interactive loop.')],
    'kill': [('kill -l | head -5', 'Lists the first five signal names — no signal sent.')],
    'killall': [('killall --help | head -3', 'Shows usage without killing anything.')],
    'pkill': [('pkill -l sleep 2>/dev/null || pgrep -l sleep', 'Lists sleep processes by name without signaling.')],
    'pgrep': [('pgrep -l bash | head -3', 'Finds bash processes and prints names — read-only.')],
    'watch': [('watch --help | head -3', 'Shows usage without starting the interval loop.')],
    'nice': [('nice -n 10 echo hello', 'Runs echo at lower priority — harmless.')],
    'renice': [('renice -n 0 -p $$ 2>/dev/null || echo "cannot renice this shell"', 'Adjusts your own shell priority only.')],
    'tmux': [('tmux -V', 'Prints tmux version.')],
    # shard4
    'apt-cache': [('apt-cache --help | head -5', 'Shows apt-cache usage — no network contact.')],
    'chown': [('chown --help | head -3', 'Shows chown usage without changing anything.')],
    'ping': [('ping -c 1 127.0.0.1 2>/dev/null || echo "ping unavailable"', 'One packet to loopback — safe local test.')],
    'ssh': [('ssh -V', 'Prints OpenSSH client version.')],
    # dpkg/dig/rsync already have --help safe from earlier fix? check
    'dpkg': [('dpkg --help | head -5', 'Shows dpkg usage.')],
    'dig': [('dig -v 2>/dev/null || echo "dig version unavailable"', 'Prints dig version.')],
    'rsync': [('rsync --version | head -2', 'Prints rsync version.')],
}

# Fix dict-mistakes: convert dict entries to readable strings
def fix_mistakes(c):
    ms = c.get('mistakes', [])
    new_ms = []
    changed = False
    for m in ms:
        if isinstance(m, dict):
            # common shapes: {problem: ..., fix: ...} or {bad: ..., good: ...}
            parts = []
            for k, v in m.items():
                parts.append(f'{k}: {v}')
            new_ms.append('; '.join(parts))
            changed = True
        else:
            new_ms.append(m)
    if changed:
        c['mistakes'] = new_ms
    return changed

for i in range(1, 6):
    p = Path(f'linuxgame/commands/_shard{i}.yaml')
    d = yaml.safe_load(open(p, encoding='utf-8'))
    fixed_dicts = []
    added_safe = []
    for c in d['commands']:
        if fix_mistakes(c):
            fixed_dicts.append(c['name'])
        ex = c.get('examples', [])
        safe_count = sum(1 for e in ex if e.get('safe'))
        if safe_count < 3 and c['name'] in extra_safe:
            for cmd, note in extra_safe[c['name']]:
                if safe_count >= 3:
                    break
                ex.append({'cmd': cmd, 'note': note, 'safe': True})
                safe_count += 1
                added_safe.append(c['name'])
            c['examples'] = ex
    open(p, 'w', encoding='utf-8', newline='\n').write(yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=100))
    print(f'shard{i}: fixed-dicts={fixed_dicts}, added-safe-to={sorted(set(added_safe))}')
print('done')
