import re
from pathlib import Path

p = Path('linuxgame/levels/_act3.yaml')
t = p.read_text(encoding='utf-8')

replacements = {
    # L22
    """    story: |
      Scaffold placeholder.
    goal: |
      Find the inode twin pair; the second name of the pair holds the key.
    commands: [ln, stat]""":
    """    story: |
      Two names, one inode. `ls -i` prints the inode number beside each filename —
      the filesystem's true identity card for the data. When two names share an
      inode, they are hard links: not copies, not shortcuts, but two doorways
      into the exact same storage. chmod on one name changes both; delete one
      and the other still works.

      Someone left a back door into Morgan's stash this way. Find the twin pair,
      and cat the name that is NOT the obvious original.
    goal: |
      Find the inode twin pair using ls -i; the second, less obvious name of the
      pair holds the password for level23.
    commands: [ln, stat]""",

    # L23
    """    story: |
      Scaffold placeholder.
    goal: |
      Follow the chain of symlinks to the real file that holds the key.
    commands: [ln, ls]""":
    """    story: |
      Symlink Street: every door here points at another door. A symbolic link
      is a slip of paper that says "the real thing is over there" — `ls -l`
      shows the target after an arrow: name.txt -> other.txt. Follow the chain
      link by link until the arrow stops appearing.

      Unlike hard links, symlinks can point anywhere, even across filesystems,
      and they break when the target moves. A chain of them is a paper trail
      made of pointers.
    goal: |
      Follow the chain of symlinks (ls -l shows the -> targets) to the real file
      that holds the password for level24.
    commands: [ln, ls]""",

    # L24
    """    story: |
      Scaffold placeholder.
    goal: |
      Read the key from the named pipe: start a writer in the background, then cat the pipe.
    commands: [mkfifo]""":
    """    story: |
      A named pipe — a FIFO — sits on the floor of this room like a hose left
      running. `mkfifo` created it; it is not a file with contents, but a
      meeting point: nothing appears until a writer and a reader arrive at the
      same time. Write first and the writer blocks; read first and the reader
      blocks. They wait for each other.

      A writer is already staged to push the password through the moment
      someone reads. Start it in the background with `&`, then cat the pipe.
      The message comes through once — then the pipe is empty again.
    goal: |
      Read the password for level25 from the named pipe: start a writer in the
      background (or find the staged one), then cat the fifo in the foreground.
    commands: [mkfifo]""",

    # L25
    """    story: |
      Scaffold placeholder.
    goal: |
      Rebuild Morgan's lock scheme: report the re-owned file's history.
    commands: [chmod, stat, ln, id, file, tree]""":
    """    story: |
      The boss level of Act 3: Morgan's lock scheme, reconstructed. The rooms
      directory holds files with modes, owners and timestamps that do not add
      up. `tree` surveys the layout, `file` identifies types, `stat` reads
      owner and mtime, `ls -i` hunts for hard-link twins, and `id` confirms
      group memberships.

      The twist the story bible promised: the mtimes say these files were
      re-owned AFTER the disappearance night. Someone tidied the scene. The
      re-owned file's history points at the night shift — and its contents
      hold the password for level26, the door to Act 4.
    goal: |
      Rebuild Morgan's lock scheme: survey with tree/file, inspect with stat,
      find the re-owned file whose mtime post-dates the disappearance, and read
      the password for level26 from it.
    commands: [chmod, stat, ln, id, file, tree]""",
}

count = 0
for old, new in replacements.items():
    if old in t:
        t = t.replace(old, new)
        count += 1
    else:
        print('MISS:', old[:80])

p.write_text(t, encoding='utf-8', newline='\n')
print(f'replaced {count}/4')
