import yaml
from pathlib import Path

p = Path('linuxgame/levels/_act5.yaml')
d = yaml.safe_load(open(p, encoding='utf-8'))

fixes = {
    38: ['export', 'source', 'history', 'clear', 'unalias'],
    39: ['true', 'false', 'yes', 'seq'],
    43: ['ssh', 'scp', 'rsync', 'ssh-keygen'],
    45: ['vim', 'nano'],
    47: ['tar', 'base64', 'sed', 'awk', 'sha256sum', 'ssh-keygen', 'tmux', 'vim'],
}
for lv in d['levels']:
    if lv['id'] in fixes:
        lv['commands'] = fixes[lv['id']]

open(p, 'w', encoding='utf-8', newline='\n').write(yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=100))
print('act5 chips fixed')

# verify round-trip
d2 = yaml.safe_load(open(p, encoding='utf-8'))
for lv in d2['levels']:
    if lv['id'] in fixes:
        print(lv['id'], lv['commands'], [type(c).__name__ for c in lv['commands']])
