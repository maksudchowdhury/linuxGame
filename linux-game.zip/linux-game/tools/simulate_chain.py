#!/usr/bin/env python3
"""Chain-solvability simulator (host-side, no docker).

For each selected level id:
  1. fresh temp HOME, run level `setup` with NEXT_PW=TESTPW (bash -e)
  2. run the matching solution; its last non-empty stdout line must equal TESTPW
     (id 47 = capstone: no next password; solution must exit 0)
  3. if the level has `verify`, it must FAIL on the pristine home (before the
     solution runs) and PASS after the solution runs.

Windows-host sim artifacts (allowed, real check deferred to docker M5):
  - `usermod: user 'levelN' does not exist`  (container build creates users first)
  - `mkfifo ... Operation not supported`      (host FS lacks FIFO)

Usage:
  python tools/simulate_chain.py --ids 9,10,11
  python tools/simulate_chain.py                # all 48 from merged game/levels.yaml
  python tools/simulate_chain.py --act 2        # from levels/_act2.yaml + solutions/_act2.yaml
"""
import argparse
import os
import subprocess
import sys
import tempfile
import time

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GAME = os.path.join(ROOT, "linuxgame", "game")

ALLOWED = ("does not exist", "Operation not supported")

# On Windows temp dirs (NTFS via WSL) chmod is a no-op, so permission-based
# verifies (stat checks) can't be exercised here — defer those to the container.
CHMOD_DEFER_MARKERS = ("stat -c", "%a")


def load_act(n):
    lv = yaml.safe_load(open(os.path.join(ROOT, "linuxgame", "levels", "_act%d.yaml" % n),
                             encoding="utf-8"))["levels"]
    sol = yaml.safe_load(open(os.path.join(ROOT, "linuxgame", "solutions", "_act%d.yaml" % n),
                              encoding="utf-8"))
    sols = sol.get("solutions") or sol.get("chain") or []
    return lv, {s["id"]: s["solution"] for s in sols}


def load_merged():
    lv = yaml.safe_load(open(os.path.join(GAME, "levels.yaml"), encoding="utf-8"))["levels"]
    sol = yaml.safe_load(open(os.path.join(ROOT, "linuxgame", "solutions", "solutionbook.yaml"),
                              encoding="utf-8"))
    return lv, {s["id"]: s["solution"] for s in sol["solutions"]}


def bash_run(script, home, testpw, i, check=False):
    """Run a script under bash with env injected via wrapper (WSL bash on
    Windows drops custom env vars; Docker/Linux is unaffected either way)."""
    wrapper = os.path.join(home, "._simwrap.sh")
    body = ("export NEXT_PW='%s'\nexport HOME='%s'\nexport LEVEL_ID='%s'\n"
            "export LEVEL_USER='level%d'\n" % (testpw, home, i, i))
    open(wrapper, "w", encoding="utf-8", newline="\n").write(body + (script or ":"))
    return subprocess.run(["bash", "./._simwrap.sh"], cwd=home,
                          capture_output=True, text=True, timeout=30)


def sim_one(i, lv, script, capstone_id):
    testpw = "TESTPW%02dX" % i
    home = tempfile.mkdtemp(prefix="sol%02d_" % i)
    st = bash_run(lv.get("setup") or ":", home, testpw, i)
    if st.returncode != 0 and not any(a in (st.stderr or "") for a in ALLOWED):
        return False, "SETUP rc=%d %s" % (st.returncode, (st.stderr or "").strip()[-140:])
    # Settle: setups may background a fifo writer (`(echo $NEXT_PW > tunnel &)`).
    # On Linux it blocks on the fifo; on Windows (no fifo) it races as an orphan
    # regular-file write — give it a moment before the solution reads it.
    time.sleep(0.6)
    # Windows fifo emulation: `mkfifo X` fails on NTFS and the setup's background
    # writer dies with the WSL process tree — so pre-fill the pipe file with what
    # the blocked writer would deliver the moment a reader (cat) connects.
    setup_src = lv.get("setup") or ""
    if "mkfifo" in setup_src and "Operation not supported" in (st.stderr or ""):
        import re as _re
        for m in _re.finditer(r"mkfifo\s+(\S+)", setup_src):
            pipe = os.path.join(home, m.group(1).strip("'\""))
            if not os.path.exists(pipe):
                with open(pipe, "w", encoding="utf-8", newline="\n") as fh:
                    fh.write(testpw + "\n")
    verify = (lv.get("verify") or "").strip()
    chmod_defer = any(m in verify for m in CHMOD_DEFER_MARKERS)
    if verify and not chmod_defer:
        pv = bash_run(verify, home, testpw, i)
        if pv.returncode == 0:
            return False, "VERIFY passes on pristine home (must fail before solution)"
    so = bash_run(script, home, testpw, i)
    lines = [x for x in (so.stdout or "").splitlines() if x.strip()]
    last = lines[-1] if lines else "<EMPTY>"
    if so.returncode != 0 and not any(a in (so.stderr or "") for a in ALLOWED):
        return False, "SOLUTION rc=%d err=%s" % (so.returncode, (so.stderr or "").strip()[-140:])
    if i == capstone_id:
        if verify and not chmod_defer:
            pv2 = bash_run(verify, home, testpw, i)
            if pv2.returncode != 0:
                return False, "VERIFY still fails after solution: %s" % (pv2.stderr or pv2.stdout)[-140:]
        return True, "capstone solution rc0 (no next pw)"
    if last != testpw:
        return False, "SOLUTION last line %r != next password" % last[:70]
    if verify and not chmod_defer:
        pv2 = bash_run(verify, home, testpw, i)
        if pv2.returncode != 0:
            return False, "VERIFY still fails after solution: %s" % (pv2.stderr or pv2.stdout)[-140:]
    if verify and chmod_defer:
        return True, "ok (chmod-verify deferred to container)"
    return True, "ok"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ids", help="comma-separated ids")
    ap.add_argument("--act", type=int, help="act shard 1-5")
    a = ap.parse_args()
    if a.act:
        levels, sols = load_act(a.act)
    else:
        levels, sols = load_merged()
    total = len(levels)
    by_id = {lv["id"]: lv for lv in levels}
    # Capstone = highest id in the selected set (ids are NOT 0-based per shard;
    # comparing against total-1 false-passed e.g. act2 id 9 — SYNC-13).
    capstone_id = max(by_id)
    ids = sorted(by_id) if not a.ids else [int(x) for x in a.ids.split(",")]
    fails = 0
    for i in ids:
        ok, msg = sim_one(i, by_id[i], sols.get(i, ""), capstone_id)
        print("L%-3d %s %s" % (i, "PASS" if ok else "FAIL", msg))
        if not ok:
            fails += 1
    print("---- %d/%d pass ----" % (len(ids) - fails, len(ids)))
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
