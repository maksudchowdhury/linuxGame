import yaml

groups = {
 1: {'pwd':'nav','ls':'nav','cd':'nav','pushd':'nav','popd':'nav','dirs':'nav','basename':'nav','dirname':'nav','mkdir':'files','rmdir':'files','stat':'files','tree':'files','touch':'files','cp':'files','mv':'files','rm':'files','ln':'files','mktemp':'files','mkfifo':'files','dd':'files','shred':'files','cpio':'archive','file':'files','rename':'files','split':'text','cat':'text','tac':'text','head':'text','tail':'text','less':'text','more':'text','nano':'text','vim':'text'},
 2: {'awk':'text','sed':'text','cut':'text','paste':'text','join':'text','tr':'text','tee':'text','sort':'text','uniq':'text','wc':'text','diff':'text','cmp':'text','comm':'text','nl':'text','fold':'text','column':'text','pr':'text','fmt':'text','shuf':'text','od':'text','find':'search','grep':'search','egrep':'search','which':'search','type':'search','locate':'search','whereis':'search','xargs':'search','eval':'script','exec':'script','expr':'script','zgrep':'archive','zcat':'archive'},
 3: {'uname':'system','hostname':'system','whoami':'system','id':'system','date':'system','cal':'system','df':'system','du':'system','env':'system','printenv':'system','set':'system','uptime':'system','free':'system','ps':'process','bg':'process','fg':'process','jobs':'process','nohup':'process','sleep':'process','time':'process','top':'process','kill':'process','killall':'process','pkill':'process','pgrep':'process','watch':'process','nice':'process','renice':'process','tmux':'process'},
 4: {'apt':'packages','apt-get':'packages','apt-cache':'packages','dpkg':'packages','apt-mark':'packages','add-apt-repository':'packages','chmod':'perms','chown':'perms','chgrp':'perms','su':'users','useradd':'users','usermod':'users','userdel':'users','passwd':'users','groupadd':'users','sudo':'users','ping':'network','ip':'network','ifconfig':'network','netstat':'network','ss':'network','curl':'network','wget':'network','traceroute':'network','dig':'network','nslookup':'network','nc':'network','ssh':'network','scp':'network','rsync':'network','host':'network'},
}

for i, gmap in groups.items():
    p = f'linuxgame/commands/_shard{i}.yaml'
    d = yaml.safe_load(open(p, encoding='utf-8'))
    unmapped = []
    for c in d['commands']:
        if 'group' not in c:
            c['group'] = gmap.get(c['name'], 'misc')
        if c['name'] not in gmap:
            unmapped.append(c['name'])
    open(p, 'w', encoding='utf-8', newline='\n').write(
        yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=100))
    n = len(d['commands'])
    print(f'shard{i}: {n} entries, unmapped->misc: {unmapped}')
