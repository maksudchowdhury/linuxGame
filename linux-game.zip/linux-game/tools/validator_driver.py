import subprocess, sys, time
print('WIPE old homes+users', flush=True)
subprocess.run(['bash', '-c',
                'for u in $(getent passwd | awk -F: \'/^level[0-9]/{print $1}\'); do userdel -r "$u" 2>/dev/null; done; '
                'userdel -r intern 2>/dev/null; rm -rf /home/level[0-9]* /home/intern; true'], check=False)
t0 = time.time()
print('SETUP game start', flush=True)
r = subprocess.run(['timeout', '240', 'python3', '/opt/game/setup.py', '--target', 'game'],
                   capture_output=True, text=True)
print('SETUP game rc %s (%.0fs)' % (r.returncode, time.time() - t0), flush=True)
print((r.stderr or '')[-600:], flush=True)
if r.returncode != 0:
    sys.exit(1)
subprocess.run(['bash', '-c', 'id intern >/dev/null 2>&1 || useradd -m -s /bin/bash -G sudo intern; echo intern:learn | chpasswd'], check=True)
t05 = time.time()
print('SETUP lab start', flush=True)
r = subprocess.run(['timeout', '120', 'python3', '/opt/game/setup.py', '--target', 'lab'],
                   capture_output=True, text=True)
print('SETUP lab rc %s (%.0fs)' % (r.returncode, time.time() - t05), flush=True)
print((r.stderr or '')[-600:], flush=True)
if r.returncode != 0:
    sys.exit(1)
t1 = time.time()
print('BUILDCHECK start', flush=True)
rc = subprocess.run(['timeout', '420', 'python3', '/opt/solutions/_buildcheck.py']).returncode
print('BUILDCHECK rc %s (%.0fs)' % (rc, time.time() - t1), flush=True)
sys.exit(rc)
