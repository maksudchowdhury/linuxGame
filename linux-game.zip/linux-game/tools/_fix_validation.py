import yaml
from pathlib import Path

# Fix act5 true/false/yes booleans in commands chip list
p = Path('linuxgame/levels/_act5.yaml')
t = p.read_text(encoding='utf-8')
old = 'commands: [true, false, yes, seq]'
new = 'commands: ["true", "false", "yes", seq]'
if old in t:
    t = t.replace(old, new)
    p.write_text(t, encoding='utf-8', newline='\n')
    print('act5 chip quoting fixed')
else:
    print('act5 pattern not found — checking manually')
    for i, ln in enumerate(t.splitlines(), 1):
        if 'true' in ln and 'commands' in ln:
            print(i, ln)

# Add ssh-keygen to shard4 if missing
p4 = Path('linuxgame/commands/_shard4.yaml')
d = yaml.safe_load(open(p4, encoding='utf-8'))
names = [c['name'] for c in d['commands']]
if 'ssh-keygen' not in names:
    d['commands'].append({
        'name': 'ssh-keygen', 'kind': 'binary', 'group': 'network',
        'summary': 'Generate and manage SSH keypairs',
        'explain': 'ssh-keygen creates the public/private keypairs that let you log in without passwords. The private key stays with you; the public key goes into authorized_keys on machines you trust. Empty passphrases are fine for training boxes, but real keys deserve protection.',
        'syntax': 'ssh-keygen [-t TYPE] [-f FILE] [-N PASS]',
        'options': ['-t TYPE — key type, e.g. rsa or ed25519', '-f FILE — output filename for the keypair', '-N PASS — passphrase (use empty quotes for none)', '-q — quiet mode'],
        'examples': [
            {'cmd': 'ssh-keygen -t rsa -f ~/.ssh/id_rsa -N "" -q', 'note': 'Generates a keypair with no passphrase — fine for the training box.', 'safe': True},
            {'cmd': 'ssh-keygen -l -f ~/.ssh/id_rsa.pub', 'note': 'Lists fingerprint details of a public key.', 'safe': True},
            {'cmd': 'ssh-keygen --help', 'note': 'Prints usage.', 'safe': True},
        ],
        'mistakes': ['Letting the tool overwrite an existing key without -f and confirming the destructive prompt.', 'Using a key with no passphrase on a machine that leaves your control.'],
        'learn_more': ['man ssh-keygen', 'ssh-keygen -A --help', 'whatis ssh-keygen'],
        'runtime': 'image',
    })
    open(p4, 'w', encoding='utf-8', newline='\n').write(yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=100))
    print('ssh-keygen added to shard4')
else:
    print('ssh-keygen already present')
