Write-Output "=== solve_all ==="
python E:/linux-game/linuxgame/tests/solve_all.py
Write-Output "SOLVE_ALL_RC=$LASTEXITCODE"
Write-Output "=== abuse ==="
python E:/linux-game/linuxgame/tests/abuse.py
Write-Output "ABUSE_RC=$LASTEXITCODE"
Write-Output "=== offline ==="
python E:/linux-game/linuxgame/tests/offline.py
Write-Output "OFFLINE_RC=$LASTEXITCODE"
Write-Output "=== secrets_leak ==="
python E:/linux-game/linuxgame/tests/secrets_leak.py
Write-Output "SECRETS_LEAK_RC=$LASTEXITCODE"
