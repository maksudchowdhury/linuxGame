docker run --rm -v "C:/Users/dmax/AppData/Local/Temp/opencode/sudoprobe.sh:/tmp/probe.sh:ro" --entrypoint bash linux-lab -c "tr -d '\r' < /tmp/probe.sh | bash"
