import re, sys
path = sys.argv[1]
lines = open(path, encoding='utf-8').read().splitlines()
issues = []
for i, ln in enumerate(lines, 1):
    # plain scalar after key: OR after "- " in list items
    m = re.match(r'^(\s*)(-\s+)?([A-Za-z_]+:\s+)?(.+)$', ln)
    if not m:
        continue
    indent, dash, key, val = m.groups()
    if val[:1] in ('"', "'", '>', '|', '[', '{', '#'):
        continue
    if ': ' in val or val.endswith(':'):
        issues.append((i, ln[:160]))
for i, ln in issues:
    print(f'{i}: {ln}')
print(f'Total: {len(issues)}')
