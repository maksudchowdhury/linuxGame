import yaml
from pathlib import Path

# Map command -> level id to attach the chip (per STORY_BIBLE coverage note + sensible placement)
placements = {
    # Act 1
    'more': 4,        # alternate to less
    'rm': 8,          # boss cleanup flavor
    'rmdir': 8,
    'mktemp': 7,      # label maker / temp files
    'tac': 4,         # reverse reading flavor
    'shred': 8,       # boss: secure delete mention
    'nano': 45,       # editor alternative to vim
    # Act 2
    'egrep': 9,       # search family
    'locate': 9,
    'whereis': 10,
    'which': 10,
    'type': 10,
    'paste': 13,
    'join': 14,
    'od': 16,
    'column': 14,
    'pr': 18,
    'shuf': 18,       # already used in setup but add chip
    'chown': 25,      # boss permissions forensics
    'unalias': 38,    # shell flavor
}

for i in range(1, 6):
    p = Path(f'linuxgame/levels/_act{i}.yaml')
    d = yaml.safe_load(open(p, encoding='utf-8'))
    changed = []
    for lv in d.get('levels', []):
        lid = lv['id']
        for cmd, target in placements.items():
            if lid == target and cmd not in lv['commands']:
                lv['commands'].append(cmd)
                changed.append(f'L{lid}+{cmd}')
    if changed:
        open(p, 'w', encoding='utf-8', newline='\n').write(yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=100))
        print(f'act{i}: {changed}')
print('done')
