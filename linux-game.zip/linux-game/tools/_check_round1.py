import yaml, glob, os, re, sys

print("== commands ==")
total = set()
for f in sorted(glob.glob(r'E:\linux-game\linuxgame\commands\_shard*.yaml')):
    try:
        d = yaml.safe_load(open(f, encoding='utf-8'))
        names = [c['name'] for c in d['commands']]
        total.update(names)
        issues = []
        for c in d['commands']:
            req = {'name','kind','summary','explain','syntax','options','examples','mistakes','learn_more','runtime'}
            miss = req - set(c)
            if miss: issues.append(f"{c['name']}:{sorted(miss)}")
            if c.get('runtime') not in ('image','lab'): issues.append(f"{c['name']}:runtime={c.get('runtime')}")
        print(os.path.basename(f), len(names), 'ISSUES:', issues if issues else 'none')
    except Exception as e:
        print(os.path.basename(f), 'PARSE FAIL:', e)
print('unique commands:', len(total))

print("== levels ==")
for f in sorted(glob.glob(r'E:\linux-game\linuxgame\levels\_act*.yaml')):
    try:
        d = yaml.safe_load(open(f, encoding='utf-8'))
        lv = d.get('levels', [])
        stubs = [l['id'] for l in lv if len(str(l.get('story',''))) < 200]
        print(os.path.basename(f), 'ids', [l['id'] for l in lv],
              'puzzles', [i.get('id') for i in d.get('interactive',[])],
              'labs', [x.get('id') for x in d.get('labs',[])],
              'SHORT-STORY ids:', stubs)
    except Exception as e:
        print(os.path.basename(f), 'PARSE FAIL:', e)

print("== solutions ==")
for f in sorted(glob.glob(r'E:\linux-game\linuxgame\solutions\_act*.yaml')):
    try:
        d = yaml.safe_load(open(f, encoding='utf-8'))
        print(os.path.basename(f), 'chain', [s['id'] for s in d.get('chain',[])],
              'labs', [s['id'] for s in d.get('labs',[])])
    except Exception as e:
        print(os.path.basename(f), 'PARSE FAIL:', e)

print("== index.html ==")
s = open(r'E:\linux-game\linuxgame\game\index.html', encoding='utf-8').read()
ids = re.findall(r'id="([^"]+)"', s)
dups = [i for i in set(ids) if ids.count(i) > 1]
ext = [u for u in re.findall(r'https?://[^"\s]+', s) if 'localhost' not in u and '127.0.0.1' not in u]
print('bytes', len(s), 'dup_ids', dups, 'ext_urls', ext[:3],
      'has_verify', '/api/verify' in s, 'has_deduction', '/api/deduction' in s,
      'innerHTML', s.count('innerHTML'))

print("== tools ==")
for f in ['gen_secrets.py', 'validate_levels.py']:
    p = os.path.join(r'E:\linux-game\tools', f)
    print(f, 'EXISTS' if os.path.exists(p) else 'MISSING', os.path.getsize(p) if os.path.exists(p) else '')
