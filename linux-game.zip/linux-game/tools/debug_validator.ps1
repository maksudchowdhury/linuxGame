# Debug harness: setup + buildcheck inside the existing game image, streamed.
docker run --rm `
  --mount "type=bind,src=E:/linux-game/linuxgame/game,dst=/opt/game,readonly" `
  --mount "type=bind,src=E:/linux-game/linuxgame/solutions,dst=/opt/solutions,readonly" `
  --mount "type=bind,src=E:/linux-game/tools,dst=/dbg,readonly" `
  --entrypoint bash linux-game -c "python3 /dbg/validator_driver.py"
