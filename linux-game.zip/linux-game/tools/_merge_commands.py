import yaml, sys, re
from pathlib import Path

root = Path('linuxgame/commands')
shards = [root / f'_shard{i}.yaml' for i in range(1, 6)]
all_cmds = []
seen = {}
for sp in shards:
    d = yaml.safe_load(open(sp, encoding='utf-8'))
    for c in d['commands']:
        name = c['name']
        if name in seen:
            print(f'DUPLICATE: {name} in {sp.name} and {seen[name]}')
            sys.exit(1)
        seen[name] = sp.name
        all_cmds.append(c)

print(f'Total commands: {len(all_cmds)}')

# coverage vs master list
lines = open('commands-to-incorporate.txt', encoding='utf-8').read().splitlines()
master = []
for ln in lines:
    if re.match(r'^\s*\d+\.\s', ln):
        continue
    m = re.match(r'^\s*([a-z][a-z0-9_-]*)\s*-\s', ln)
    if m and m.group(1) != 'note':
        master.append(m.group(1))
seen_m = set()
master = [c for c in master if not (c in seen_m or seen_m.add(c))]
names = {c['name'] for c in all_cmds}
missing = [c for c in master if c not in names]
extra = sorted(names - set(master))
print(f'Master list: {len(master)}')
print(f'Missing from shards: {missing}')
print(f'Extra (not in master txt, may be valid): {extra}')

# structure check
req = {'name', 'kind', 'summary', 'explain', 'syntax', 'options', 'examples', 'mistakes', 'learn_more', 'runtime', 'group'}
bad = []
for c in all_cmds:
    lack = req - set(c.keys())
    if lack:
        bad.append((c['name'], sorted(lack)))
    if c['kind'] not in ('builtin', 'binary'):
        bad.append((c['name'], f"bad kind {c['kind']}"))
    if c['runtime'] not in ('image', 'lab'):
        bad.append((c['name'], f"bad runtime {c['runtime']}"))
    if not isinstance(c.get('learn_more'), list):
        bad.append((c['name'], 'learn_more not list'))
    ex = c.get('examples', [])
    if len(ex) < 2:
        bad.append((c['name'], f'only {len(ex)} examples'))
    if not any(e.get('safe') for e in ex):
        bad.append((c['name'], 'no safe example'))
if bad:
    print('STRUCTURE PROBLEMS:')
    for b in bad:
        print(' ', b)
else:
    print('Structure: ALL OK')

if missing:
    sys.exit(2)
if bad:
    sys.exit(3)

# write merged
merged = {'version': 1, 'commands': all_cmds}
out = root / 'commands.yaml'
out.write_text(yaml.safe_dump(merged, sort_keys=False, allow_unicode=True, width=100), encoding='utf-8', newline='\n')
print(f'WROTE {out} ({len(all_cmds)} commands)')
