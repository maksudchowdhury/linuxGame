#!/usr/bin/env python3
"""ISOLATED Unit Test for tools/gen_secrets.py

Target: E:/linux-game/tools/gen_secrets.py
Session: ses_tools1

WARNING: THIS FILE IS DELETED AFTER THE TEST PASSES.
Test code preserved in: .opencode/unit-tests/

Isolation: imports ONLY gen_secrets; all filesystem I/O confined to a
tempfile.TemporaryDirectory; no network.
"""
import contextlib
import importlib.util
import io
import string
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

TOOLS_DIR = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location(
    "gen_secrets", TOOLS_DIR / "gen_secrets.py")
gen_secrets = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(gen_secrets)


def run_main(argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = gen_secrets.main(argv)
    return rc, buf.getvalue()


class GenSecretsTest(unittest.TestCase):
    def _write_levels(self, tmp, text):
        p = Path(tmp) / "levels.yaml"
        p.write_text(text, encoding="utf-8")
        return p

    NEW_SCHEMA = (
        "version: 1\n"
        "meta: {title: X}\n"
        "levels:\n"
        "  - id: 0\n"
        "    title: A\n"
        "  - id: 1\n"
        "    title: B\n"
        "  - id: 2\n"
        "    title: C\n"
        "  - id: 3\n"
        "    title: D\n"
    )
    OLD_SCHEMA = (
        "levels:\n"
        "  - title: First Steps\n"
        "    password: begin\n"
        "  - title: Hidden Things\n"
        "    password: whatever\n"
    )

    def test_write_and_check_roundtrip_new_schema(self):
        with tempfile.TemporaryDirectory() as tmp:
            lv = self._write_levels(tmp, self.NEW_SCHEMA)
            out = Path(tmp) / "secrets.yaml"
            rc, text = run_main(["--levels", str(lv), "--out", str(out)])
            self.assertEqual(rc, 0, text)
            self.assertIn("wrote 4 passwords (1 public + 3 secret)", text)
            doc = yaml.safe_load(out.read_text(encoding="utf-8"))
            self.assertEqual(doc["version"], 1)
            pws = {int(k): v for k, v in doc["passwords"].items()}
            self.assertEqual(set(pws), {0, 1, 2, 3})
            self.assertEqual(pws[0], "begin")
            others = [pws[i] for i in (1, 2, 3)]
            for pw in others:
                self.assertEqual(len(pw), 16)
                for ch in pw:
                    self.assertIn(ch, gen_secrets.ALPHABET)
            self.assertEqual(len(set(others)), 3)
            # --check passes on what we just wrote
            rc, text = run_main(
                ["--check", "--levels", str(lv), "--out", str(out)])
            self.assertEqual(rc, 0, text)

    def test_ids_from_index_old_schema(self):
        with tempfile.TemporaryDirectory() as tmp:
            lv = self._write_levels(tmp, self.OLD_SCHEMA)
            out = Path(tmp) / "secrets.yaml"
            rc, text = run_main(["--levels", str(lv), "--out", str(out)])
            self.assertEqual(rc, 0, text)
            doc = yaml.safe_load(out.read_text(encoding="utf-8"))
            pws = {int(k): v for k, v in doc["passwords"].items()}
            self.assertEqual(set(pws), {0, 1})

    def test_check_detects_bad_password(self):
        with tempfile.TemporaryDirectory() as tmp:
            lv = self._write_levels(tmp, self.NEW_SCHEMA)
            out = Path(tmp) / "secrets.yaml"
            run_main(["--levels", str(lv), "--out", str(out)])
            doc = yaml.safe_load(out.read_text(encoding="utf-8"))
            doc["passwords"][1] = "short"           # wrong length
            doc["passwords"][2] = doc["passwords"][3]  # duplicate
            out.write_text(yaml.safe_dump(doc), encoding="utf-8")
            rc, text = run_main(["--check", "--levels", str(lv), "--out", str(out)])
            self.assertEqual(rc, 1, text)
            self.assertIn("PROBLEM", text)

    def test_missing_levels_is_fatal(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc, text = run_main(
                ["--levels", str(Path(tmp) / "nope.yaml"),
                 "--out", str(Path(tmp) / "s.yaml")])
            self.assertEqual(rc, 2)
            self.assertIn("ERROR", text)

    def test_check_missing_secrets_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            lv = self._write_levels(tmp, self.OLD_SCHEMA)
            rc, text = run_main(
                ["--check", "--levels", str(lv),
                 "--out", str(Path(tmp) / "absent.yaml")])
            self.assertEqual(rc, 1)
            self.assertIn("PROBLEM", text)

    def test_alphabet_has_no_ambiguous(self):
        for ch in "0O1lI":
            self.assertNotIn(ch, gen_secrets.ALPHABET)
        self.assertEqual(len(gen_secrets.ALPHABET), len(string.ascii_lowercase + string.digits) - 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
