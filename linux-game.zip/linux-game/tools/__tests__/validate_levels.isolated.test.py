#!/usr/bin/env python3
"""ISOLATED Unit Test for tools/validate_levels.py

Target: E:/linux-game/tools/validate_levels.py
Session: ses_tools1

WARNING: THIS FILE IS DELETED AFTER THE TEST PASSES.
Test code preserved in: .opencode/unit-tests/

Isolation: imports ONLY validate_levels; all filesystem I/O confined to a
tempfile.TemporaryDirectory; no network.
"""
import contextlib
import importlib.util
import io
import tempfile
import unittest
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location(
    "validate_levels", TOOLS_DIR / "validate_levels.py")
validate_levels = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(validate_levels)


PASS_LEVELS = """\
version: 1
meta:
  title: Nimbus Casebook
  ranks:
    - {name: Constable, at: 0}
    - {name: Chief, at: 100}
  hint_costs: {nudge: 5, direction: 15, near: 30}
  base_points: {flag: 100, evidence: 120, task: 150, breather: 80, boss: 250, capstone: 300}
levels:
  - id: 0
    act: 1
    type: flag
    title: The New Badge
    story: |
      You wake at a plain desk. A note says: begin your case by listing files.
    goal: Find the note in your folder and read it.
    commands: [pwd, ls, cat]
    hints:
      - {tier: nudge, text: Try listing files with ls.}
    learned: Use pwd when lost, ls to list, cat to read.
    setup: echo ok
  - id: 1
    act: 1
    type: capstone
    title: Case Closed
    story: |
      The final folder waits. Pack the evidence and close the file.
    goal: Produce the CASE-CLOSED marker in your home folder.
    commands: []
    hints:
      - {tier: nudge, text: Look again at the desk plate.}
    learned: Every case ends with one clean artifact.
    setup: echo ok
    verify: test -f CASE-CLOSED
interactive: []
labs: []
"""

PASS_SECRETS = """\
version: 1
passwords:
  0: begin
  1: abcdefghij234567
"""

PASS_COMMANDS = """\
commands:
  - {name: pwd}
  - {name: ls}
  - {name: cat}
"""

FINDINGS_LEVELS = """\
version: 1
meta:
  title: X
  ranks:
    - {name: Constable, at: 0}
    - {name: Chief, at: 100}
  hint_costs: {nudge: 5, direction: 15, near: 30}
  base_points: {flag: 100, evidence: 120, task: 150, breather: 80, boss: 250, capstone: 300}
levels:
  - id: 0
    act: 1
    type: flag
    title: Leaky Level
    story: |
      The stash key is abcdefghij234567 hidden in prose. TODO fix this text.
    goal: See http://evil.com for help.
    commands: [ls -a]
    hints:
      - {tier: nudge, text: Look harder.}
    learned: Nothing learned yet.
    setup: echo ok
  - id: 1
    act: 1
    type: capstone
    title: Cap
    story: |
      Final stretch of the case.
    goal: Close the case cleanly today.
    commands: []
    hints:
      - {tier: nudge, text: Breathe.}
    learned: You are done for now.
    setup: echo ok
    verify: test -f CASE-CLOSED
    solution: echo inline-solution-not-allowed
interactive:
  - id: match-1
    act: 1
    title: Tiny Match
    requires: 0
    kind: match
    points: 50
    commands: []
    teach: Match things up here.
    data:
      pairs:
        - {left: list files, right: ls}
    answer:
      pairs:
        - [list files, ls]
labs: []
"""


def run_main(argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = validate_levels.main(argv)
    return rc, buf.getvalue()


class ValidateLevelsTest(unittest.TestCase):
    def _write(self, tmp, name, text):
        p = Path(tmp) / name
        p.write_text(text, encoding="utf-8")
        return p

    def _args(self, tmp, levels_text=PASS_LEVELS, secrets_text=PASS_SECRETS,
              commands_text=PASS_COMMANDS):
        lv = self._write(tmp, "levels.yaml", levels_text)
        args = ["--levels", str(lv)]
        if secrets_text is not None:
            args += ["--secrets", str(self._write(tmp, "secrets.yaml", secrets_text))]
        if commands_text is not None:
            args += ["--commands", str(self._write(tmp, "commands.yaml", commands_text))]
        return args

    def test_clean_fixture_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc, text = run_main(self._args(tmp))
            self.assertEqual(rc, 0, text)
            self.assertIn("PASS: 2 levels, 0 puzzles, 0 labs, 3 chips", text)

    def test_findings_fixture_fails_with_expected_messages(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc, text = run_main(self._args(tmp, levels_text=FINDINGS_LEVELS))
            self.assertEqual(rc, 1, text)
            for needle in ("abcdefghij234567", "TODO", "http://evil.com",
                           "ls -a", "inline", "pairs"):
                self.assertIn(needle, text, f"missing {needle!r} in:\n{text}")

    def test_missing_secrets_gives_finding_not_crash(self):
        with tempfile.TemporaryDirectory() as tmp:
            args = self._args(tmp, secrets_text=None)
            args += ["--secrets", str(Path(tmp) / "absent.yaml")]
            rc, text = run_main(args)
            self.assertEqual(rc, 1)
            self.assertIn("secrets", text.lower())

    def test_capstone_next_pw_is_warning_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            args = self._args(tmp)
            sol = self._write(tmp, "solutionbook.yaml",
                              "levels:\n  0: echo go\n  1: echo NEXT_PW tail\nlabs: {}\n")
            args += ["--solutions", str(sol)]
            rc, text = run_main(args)
            self.assertEqual(rc, 0, text)
            self.assertIn("WARNING", text)
            self.assertIn("NEXT_PW", text)
            self.assertIn("PASS:", text)

    def test_missing_solutions_entries_are_findings(self):
        with tempfile.TemporaryDirectory() as tmp:
            args = self._args(tmp)
            sol = self._write(tmp, "solutionbook.yaml", "levels:\n  0: echo go\nlabs: {}\n")
            args += ["--solutions", str(sol)]
            rc, text = run_main(args)
            self.assertEqual(rc, 1)
            self.assertIn("solution", text.lower())

    def test_old_prototype_runs_without_crash(self):
        proto = Path(__file__).resolve().parents[2] / "linuxgame" / "game" / "levels.yaml"
        if not proto.is_file():
            self.skipTest("prototype levels.yaml absent")
        rc, text = run_main(["--levels", str(proto)])
        self.assertIn(rc, (0, 1))
        self.assertTrue("FINDING" in text or "PASS:" in text)

    def test_act_range_helper(self):
        self.assertEqual(validate_levels.expected_act(0), 1)
        self.assertEqual(validate_levels.expected_act(8), 1)
        self.assertEqual(validate_levels.expected_act(9), 2)
        self.assertEqual(validate_levels.expected_act(18), 2)
        self.assertEqual(validate_levels.expected_act(19), 3)
        self.assertEqual(validate_levels.expected_act(25), 3)
        self.assertEqual(validate_levels.expected_act(26), 4)
        self.assertEqual(validate_levels.expected_act(36), 4)
        self.assertEqual(validate_levels.expected_act(37), 5)
        self.assertEqual(validate_levels.expected_act(47), 5)
        self.assertIsNone(validate_levels.expected_act(48))


if __name__ == "__main__":
    unittest.main(verbosity=2)
