#!/usr/bin/env python3
"""Validate the merged Nimbus Casebook levels.yaml against AUTHORING.md contracts.

Checks (structure, chips, act gates, pw chain, budgets, guardrails):
  1. YAML parses; version present; meta has title/ranks/hint_costs/base_points.
  2. levels: list of 48 (ids 0..47 sequential), each with id/act/type/title/
     story/goal/commands/hints/learned/setup; verify required for task/boss/
     capstone; no `solution:` or `password:` keys anywhere in levels.
  3. types valid; acts match STORY_BIBLE ranges; points default from meta.
  4. hints: 1-3 entries, tiers nudge/direction/near, text budget.
  5. Text budgets (AUTHORING.md section 4).
  6. No password leaks: no learner-visible field contains any password from
     secrets.yaml (except public start 'begin' on level 0's start context —
     level 0's own password IS 'begin' and that is fine for start_password).
  7. Offline: no external http(s) URLs anywhere (localhost/127.0.0.1 allowed).
  8. Commands chips: every chip string equals a `name` in commands.yaml;
     every command in commands.yaml appears as a chip on >=1 entry (chain,
     interactive, or lab).
  9. Chain order: setup+verify+solution contracts — static check that verify
     scripts do not contain a password literal; solution scripts end in a way
     that can print $NEXT_PW (we do not execute here; e2e does that).
 10. interactive: kinds valid; requires <= some reachable level; payload shape
     per kind; answer present (server-side only — checked here but the file
     is build-only when merged from shards? answer IS in levels.yaml per
     AUTHORING — server never sends it before pass).
 11. labs: verify required; requires field; no chain password dependency.

Exit codes: 0 ok, 1 validation problems, 2 fatal (unreadable inputs).
"""
import argparse
import re
import sys
from pathlib import Path

import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LEVELS = REPO_ROOT / "linuxgame" / "game" / "levels.yaml"
DEFAULT_COMMANDS = REPO_ROOT / "linuxgame" / "commands" / "commands.yaml"
DEFAULT_SECRETS = REPO_ROOT / "linuxgame" / "game" / "secrets.yaml"

VALID_TYPES = {"flag", "evidence", "task", "breather", "boss", "capstone"}
VALID_TIERS = {"nudge", "direction", "near"}
VALID_KINDS = {"match", "order", "chmod", "scenario", "tree"}
GRADED_TYPES = {"task", "boss", "capstone"}

BUDGETS = {
    "title": 40,
    "goal": 400,
    "story": 1600,
    "hint": 400,
    "learned": 500,
    "casebook_text": 300,
    "teach": 400,
}

FORBIDDEN_TEXT = re.compile(r"\[FILL|TODO|FIXME|lorem", re.IGNORECASE)
URL_RE = re.compile(r"https?://[^\s\"']+")


def load_yaml(path):
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise SystemExit(f"FATAL: cannot read {path}: {exc}")
    except yaml.YAMLError as exc:
        raise SystemExit(f"FATAL: cannot parse {path}: {exc}")


def validate(levels_path, commands_path, secrets_path):
    problems = []

    def bad(msg):
        problems.append(msg)

    doc = load_yaml(levels_path)
    if not isinstance(doc, dict):
        bad("top level must be a mapping")
        return problems

    if doc.get("version") != 1:
        bad(f"version: expected 1, got {doc.get('version')!r}")

    meta = doc.get("meta")
    if not isinstance(meta, dict):
        bad("meta: missing or not a mapping")
        meta = {}
    for k in ("title", "ranks", "hint_costs", "base_points"):
        if k not in meta:
            bad(f"meta.{k}: missing")
    base_points = meta.get("base_points", {}) if isinstance(meta.get("base_points"), dict) else {}

    levels = doc.get("levels")
    if not isinstance(levels, list) or not levels:
        bad("levels: missing or empty")
        return problems

    ids = []
    for i, lv in enumerate(levels):
        if not isinstance(lv, dict):
            bad(f"levels[{i}]: not a mapping")
            continue
        lid = lv.get("id")
        if not isinstance(lid, int):
            bad(f"levels[{i}].id: missing or not int ({lid!r})")
            continue
        ids.append(lid)

    if ids != list(range(len(ids))):
        bad(f"level ids must be sequential 0..n-1, got {ids[:10]}... (len {len(ids)})")

    # secrets
    secrets = {}
    if secrets_path.is_file():
        sdoc = load_yaml(secrets_path)
        raw = (sdoc or {}).get("passwords", {})
        try:
            secrets = {int(k): str(v) for k, v in raw.items()}
        except (TypeError, ValueError):
            bad("secrets.yaml passwords keys not int-parseable")
    else:
        bad(f"secrets.yaml not found at {secrets_path} (run tools/gen_secrets.py)")

    # commands
    chip_names = set()
    cdoc = load_yaml(commands_path)
    if isinstance(cdoc, dict) and isinstance(cdoc.get("commands"), list):
        chip_names = {c.get("name") for c in cdoc["commands"] if isinstance(c, dict)}
    else:
        bad(f"commands.yaml unreadable or missing commands list at {commands_path}")

    used_chips = set()

    def check_text(field, val, budget_key, ctx):
        if not isinstance(val, str):
            bad(f"{ctx}.{field}: not a string")
            return
        if FORBIDDEN_TEXT.search(val):
            bad(f"{ctx}.{field}: contains forbidden placeholder text")
        for m in URL_RE.finditer(val):
            url = m.group(0)
            if "localhost" not in url and "127.0.0.1" not in url:
                bad(f"{ctx}.{field}: external URL {url}")
        budget = BUDGETS.get(budget_key)
        if budget and len(val) > budget:
            bad(f"{ctx}.{field}: {len(val)} chars > budget {budget}")

    def check_no_pw(val, ctx, lid):
        if not isinstance(val, str):
            return
        low = val.lower()
        for pwid, pw in secrets.items():
            if pwid == 0:
                continue  # public start password may be referenced as start context only
            if pw and pw.lower() in low:
                bad(f"{ctx}: leaks password for level {pwid}")

    for lv in levels:
        lid = lv.get("id")
        ctx = f"L{lid}"
        for req in ("id", "act", "type", "title", "story", "goal", "commands", "hints", "learned", "setup"):
            if req not in lv:
                bad(f"{ctx}: missing required field '{req}'")
        t = lv.get("type")
        if t not in VALID_TYPES:
            bad(f"{ctx}.type: invalid {t!r}")
        if t in GRADED_TYPES and "verify" not in lv:
            bad(f"{ctx}: type {t} requires a verify script")
        if "solution" in lv:
            bad(f"{ctx}: solution must NOT live in levels.yaml (use solutions/_actN.yaml)")
        if "password" in lv:
            bad(f"{ctx}: password key forbidden in levels.yaml (use secrets.yaml)")
        check_text("title", lv.get("title", ""), "title", ctx)
        check_text("goal", lv.get("goal", ""), "goal", ctx)
        check_text("story", lv.get("story", ""), "story", ctx)
        check_text("learned", lv.get("learned", ""), "learned", ctx)
        hints = lv.get("hints")
        if not isinstance(hints, list) or not (1 <= len(hints) <= 3):
            bad(f"{ctx}.hints: must be list of 1-3")
        else:
            for hi, h in enumerate(hints):
                if not isinstance(h, dict) or h.get("tier") not in VALID_TIERS:
                    bad(f"{ctx}.hints[{hi}]: bad tier {h.get('tier') if isinstance(h, dict) else h!r}")
                check_text("text", h.get("text", "") if isinstance(h, dict) else "", "hint", f"{ctx}.hints[{hi}]")
        cmds = lv.get("commands")
        if not isinstance(cmds, list):
            bad(f"{ctx}.commands: not a list")
        else:
            for ch in cmds:
                if ch not in chip_names:
                    bad(f"{ctx}.commands: chip '{ch}' not in commands.yaml")
                used_chips.add(ch)
        for cb in lv.get("casebook", []) or []:
            if not isinstance(cb, dict) or "id" not in cb or "title" not in cb or "text" not in cb:
                bad(f"{ctx}.casebook: entries need id/title/text")
            else:
                check_text("text", cb.get("text", ""), "casebook_text", f"{ctx}.casebook[{cb['id']}]")
        # learner-visible string fields leak check
        for field in ("title", "story", "goal", "learned", "setup", "verify"):
            if field in lv:
                check_no_pw(lv.get(field), f"{ctx}.{field}", lid)
        for hi, h in enumerate(lv.get("hints", []) or []):
            if isinstance(h, dict):
                check_no_pw(h.get("text", ""), f"{ctx}.hints[{hi}]", lid)
        for cb in lv.get("casebook", []) or []:
            if isinstance(cb, dict):
                check_no_pw(cb.get("text", ""), f"{ctx}.casebook", lid)
        # acts sanity: STORY_BIBLE ranges
        act = lv.get("act")
        if isinstance(lid, int) and isinstance(act, int):
            expected = 1 if lid <= 8 else 2 if lid <= 18 else 3 if lid <= 25 else 4 if lid <= 36 else 5
            if act != expected:
                bad(f"{ctx}.act: expected {expected} for id {lid}, got {act}")
        # points
        pts = lv.get("points")
        if pts is None and t not in base_points:
            bad(f"{ctx}: no points and type {t!r} not in meta.base_points")
        # setup must not echo NEXT_PW raw in an obvious leak to stdout
        setup = lv.get("setup", "")
        if isinstance(setup, str) and re.search(r"echo\s+[\"']?\$NEXT_PW[\"']?\s*$", setup, re.M):
            bad(f"{ctx}.setup: appears to echo NEXT_PW to stdout unconditionally")

    # interactive
    for puzzle in doc.get("interactive", []) or []:
        pid = puzzle.get("id", "?")
        ctx = f"interactive[{pid}]"
        for req in ("id", "act", "title", "requires", "kind", "points", "commands", "teach", "data", "answer"):
            if req not in puzzle:
                bad(f"{ctx}: missing '{req}'")
        if puzzle.get("kind") not in VALID_KINDS:
            bad(f"{ctx}.kind: invalid {puzzle.get('kind')!r}")
        for ch in puzzle.get("commands", []) or []:
            if ch not in chip_names:
                bad(f"{ctx}.commands: chip '{ch}' not in commands.yaml")
            used_chips.add(ch)
        check_text("teach", puzzle.get("teach", ""), "teach", ctx)
        check_no_pw(puzzle.get("teach", ""), ctx, None)
        data = puzzle.get("data", {})
        kind = puzzle.get("kind")
        if kind == "match" and not (isinstance(data, dict) and isinstance(data.get("pairs"), list)):
            bad(f"{ctx}: match needs data.pairs")
        if kind == "order" and not (isinstance(data, dict) and isinstance(data.get("steps"), list)):
            bad(f"{ctx}: order needs data.steps")
        if kind == "chmod" and not (isinstance(data, dict) and isinstance(data.get("questions"), list)):
            bad(f"{ctx}: chmod needs data.questions")
        if kind == "scenario" and not (isinstance(data, dict) and isinstance(data.get("cards"), list)):
            bad(f"{ctx}: scenario needs data.cards")
        if kind == "tree" and not (isinstance(data, dict) and isinstance(data.get("tree"), dict)):
            bad(f"{ctx}: tree needs data.tree")

    # labs
    for lab in doc.get("labs", []) or []:
        lid = lab.get("id", "?")
        ctx = f"lab[{lid}]"
        for req in ("id", "act", "title", "requires", "points", "commands", "story", "goal", "hints", "learned", "setup", "verify"):
            if req not in lab:
                bad(f"{ctx}: missing '{req}'")
        if "solution" in lab:
            bad(f"{ctx}: solution must NOT live in levels.yaml")
        for ch in lab.get("commands", []) or []:
            if ch not in chip_names:
                bad(f"{ctx}.commands: chip '{ch}' not in commands.yaml")
            used_chips.add(ch)
        for field in ("story", "goal", "learned", "setup", "verify"):
            check_no_pw(lab.get(field, ""), f"{ctx}.{field}", None)
        check_text("story", lab.get("story", ""), "story", ctx)

    # coverage: every command in commands.yaml used as chip somewhere
    unused = sorted(chip_names - used_chips)
    if unused:
        bad(f"coverage: commands never used as a chip: {unused}")

    return problems


def main(argv=None):
    ap = argparse.ArgumentParser(description="Validate merged levels.yaml against AUTHORING.md.")
    ap.add_argument("--levels", default=str(DEFAULT_LEVELS))
    ap.add_argument("--commands", default=str(DEFAULT_COMMANDS))
    ap.add_argument("--secrets", default=str(DEFAULT_SECRETS))
    args = ap.parse_args(argv)

    problems = validate(Path(args.levels), Path(args.commands), Path(args.secrets))
    for p in problems:
        print(f"PROBLEM: {p}")
    if problems:
        print(f"VALIDATION FAILED: {len(problems)} problem(s)")
        return 1
    print("VALIDATION OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
