import yaml
from pathlib import Path

root = Path('linuxgame')
meta = {
    'title': 'Nimbus Casebook',
    'ranks': [
        {'name': 'Constable', 'at': 0},
        {'name': 'Detective', 'at': 800},
        {'name': 'Inspector', 'at': 2000},
        {'name': 'Chief', 'at': 3500},
    ],
    'hint_costs': {'nudge': 5, 'direction': 15, 'near': 30},
    'base_points': {'flag': 100, 'evidence': 120, 'task': 150, 'breather': 80, 'boss': 250, 'capstone': 300},
}

levels, interactive, labs = [], [], []
for i in range(1, 6):
    p = root / 'levels' / f'_act{i}.yaml'
    d = yaml.safe_load(open(p, encoding='utf-8'))
    levels.extend(d.get('levels', []))
    interactive.extend(d.get('interactive', []) or [])
    labs.extend(d.get('labs', []) or [])

# strip any solution/password keys defensively
for lv in levels:
    lv.pop('solution', None)
    lv.pop('password', None)
for lab in labs:
    lab.pop('solution', None)

levels.sort(key=lambda l: l['id'])
ids = [l['id'] for l in levels]
assert ids == list(range(48)), f'bad ids: {ids}'

merged = {'version': 1, 'meta': meta, 'levels': levels, 'interactive': interactive, 'labs': labs}
out = root / 'game' / 'levels.yaml'
out.write_text(yaml.safe_dump(merged, sort_keys=False, allow_unicode=True, width=100), encoding='utf-8', newline='\n')
print(f'WROTE {out}: {len(levels)} levels, {len(interactive)} puzzles, {len(labs)} labs')

# solutions
solutions, lab_solutions = [], []
for i in range(1, 6):
    p = root / 'solutions' / f'_act{i}.yaml'
    d = yaml.safe_load(open(p, encoding='utf-8'))
    solutions.extend(d.get('solutions') or d.get('chain') or [])
    lab_solutions.extend(d.get('labs', []) or [])
solutions.sort(key=lambda s: s['id'])
sol = {'version': 1, 'solutions': solutions, 'labs': lab_solutions}
sout = root / 'solutions' / 'solutionbook.yaml'
sout.write_text(yaml.safe_dump(sol, sort_keys=False, allow_unicode=True, width=100), encoding='utf-8', newline='\n')
print(f'WROTE {sout}: {len(solutions)} chain solutions, {len(lab_solutions)} lab solutions')
