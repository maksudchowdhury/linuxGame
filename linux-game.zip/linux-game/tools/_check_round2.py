import yaml, re, os

print("== index.html ==")
s = open(r'E:\linux-game\linuxgame\game\index.html', encoding='utf-8').read()
eps = ['/api/state','/api/level','/api/commands','/api/casebook','/api/export',
       '/api/hint','/api/verify','/api/puzzle','/api/labverify','/api/deduction']
missing = [e for e in eps if e not in s]
ids = re.findall(r'id="([^"]+)"', s)
dups = [i for i in set(ids) if ids.count(i) > 1]
ext = [u for u in re.findall(r'https?://[^"\s]+', s) if 'localhost' not in u and '127.0.0.1' not in u]
print('bytes', len(s), 'missing_eps', missing, 'dups', dups,
      'ext_urls', ext, 'innerHTML', s.count('innerHTML'),
      'start_password_ref', 'start_password' in s, 'TODO', 'TODO' in s)

print("== act4 ==")
d = yaml.safe_load(open(r'E:\linux-game\linuxgame\levels\_act4.yaml', encoding='utf-8'))
print('short stories', [l['id'] for l in d['levels'] if len(str(l.get('story',''))) < 200])
print('short labs', [x['id'] for x in d['labs'] if len(str(x.get('story',''))) < 150])
print('verify', [l['id'] for l in d['levels'] if 'verify' in l])
sol = yaml.safe_load(open(r'E:\linux-game\linuxgame\solutions\_act4.yaml', encoding='utf-8'))
key = 'chain' if 'chain' in sol else 'solutions'
print('sol key', key, [x['id'] for x in sol[key]],
      'pwrefs', sum('NEXT_PW' in x['solution'] for x in sol[key]))

print("== all levels ==")
for n in range(1, 6):
    p = rf'E:\linux-game\linuxgame\levels\_act{n}.yaml'
    if not os.path.exists(p):
        print(f'act{n}: MISSING'); continue
    try:
        d = yaml.safe_load(open(p, encoding='utf-8'))
        lv = d['levels']
        print(f"act{n}: ids {[l['id'] for l in lv]}",
              'short', [l['id'] for l in lv if len(str(l.get('story',''))) < 200],
              'puzzles', [i.get('id') for i in d.get('interactive', [])],
              'labs', [x.get('id') for x in d.get('labs', [])])
    except Exception as e:
        print(f'act{n}: PARSE FAIL {e}')

print("== all solutions ==")
for n in range(1, 6):
    p = rf'E:\linux-game\linuxgame\solutions\_act{n}.yaml'
    if not os.path.exists(p):
        print(f'sol act{n}: MISSING'); continue
    try:
        d = yaml.safe_load(open(p, encoding='utf-8'))
        key = 'chain' if 'chain' in d else 'solutions'
        items = d.get(key, [])
        print(f"sol act{n}: key={key} ids {[x['id'] for x in items]}",
              'labs', [x.get('id') for x in d.get('labs', [])],
              'pwrefs', sum('NEXT_PW' in str(x.get('solution','')) for x in items))
    except Exception as e:
        print(f'sol act{n}: PARSE FAIL {e}')
