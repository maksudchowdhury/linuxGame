@echo off
REM Reset one level (files only, keeps your progress).
REM   usage: reset.bat 7
if "%~1"=="" goto usage
docker exec linuxgame python3 /opt/game/setup.py --target game --level %~1
exit /b %errorlevel%
:usage
echo usage: reset.bat ^<level^>   e.g. reset.bat 7
exit /b 2
