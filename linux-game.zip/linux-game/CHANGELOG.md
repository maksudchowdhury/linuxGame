# Changelog

All notable changes to Nimbus Casebook. Format: keep it short, one entry per phase.

## [Unreleased] — full game (Phases 1–7)

- 48 chain levels across 5 acts, 6 interactive puzzles, 5 sudo labs; ~150 command
  chips (`commands/commands.yaml`, 203 KB) with container-verified examples.
- `game/server.py`: full 10-endpoint JSON API (state/level/commands/casebook/export,
  hint/verify/puzzle/labverify/deduction); grading ssh's into the level account via
  `sshpass -e` (password env-only); scores JSON gameserver-owned; hint costs 5/15/30;
  ranks Constable/Detective/Sergeant/Inspector.
- `game/setup.py`: build-time provisioning `--target game|lab` with per-child
  timeouts, file-based child I/O (no pipe deadlocks on fifo levels), secrets never
  on argv.
- Dockerfile: 5 stages — base, game, validator (build-time solvability gate:
  `_buildcheck.py` proves 48/48 chain + 5/5 labs, never enters runtime image),
  labbuild, lab (intern + sudo + software-properties-common).
- Tests: `tests/run-base-test.ps1` (21 checks + PAM chain) and
  `tests/e2e_suite.py` (API abuse, secrets-leak sweep, L0–L7 solve flow through
  the real ssh grader, hint economics, isolation, offline statics, labverify).
- Dashboard `game/index.html`: full case-file UI wired to all 10 endpoints.
- Per-level reset: `setup.py --target game --level N` wipes one level's home and
  re-provisions it (progress/scores untouched); lab banner text corrected
  (recreate, not restart, restores lab files).

## [Unreleased] — Phase 0 (audit & base test)

- Repo under git; `.gitattributes` enforces LF everywhere, `.gitignore` added.
- Dockerfile: added missing teaching packages (`cpio`, `rename`, `plocate`,
  `netcat-openbsd`, `traceroute`, `which`, `ncal` for `cal`); `updatedb` runs at
  build time with a `PRUNEPATHS` list that hides `/home`, `/opt`, `/var/lib` from `locate`.
- sshd hardening on both services: `MaxAuthTries 3`, `LoginGraceTime 30`,
  `PermitEmptyPasswords no`, `KbdInteractiveAuthentication no`.
- `entrypoint.sh` now fails loudly if sshd does not come up.
- `mark.sh` only records `levelN` users.
- compose: `ulimits` (nofile/nproc) + healthchecks per service; test-only
  `tester` service behind profile `tests`.
- PAM-hook installation fails the build if `/etc/pam.d/{sshd,su,su-l}` is missing.
- New: `tests/run-base-test.ps1` + `tests/base_test.py` (login on each service,
  dashboard follows the SSH session).
- New: `docs/PHASE0_AUDIT.md`.

## [0.1.0] — baseline

- Existing skeleton: 6 levels, dashboard, PAM progress hook, game + lab images,
  offline pendrive workflow (`build.bat`).
