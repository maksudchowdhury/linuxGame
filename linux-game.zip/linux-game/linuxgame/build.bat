@echo off
set DOCKER_DEFAULT_PLATFORM=linux/amd64
REM 1) build the game image and export it
docker compose build
docker save linux-game linux-lab -o linux-game.tar
REM 2) download Docker + Compose .deb files for Ubuntu 24.04 / Mint 22
if not exist debs mkdir debs
docker run --rm -v "%cd%\debs:/out" ubuntu:24.04 bash -c "apt-get update && apt-get install -y --download-only docker.io docker-compose-v2 && cp /var/cache/apt/archives/*.deb /out/"
echo Done. Copy linux-game.tar, docker-compose.yml and the debs folder to the pendrive.
