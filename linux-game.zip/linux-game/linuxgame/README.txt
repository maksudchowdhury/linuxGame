NIMBUS CASEBOOK — offline Linux detective trainer
=================================================
Story-driven CTF: 48 chain levels (5 acts), 6 interactive puzzles, 5 sudo labs.
Learn ~150 Linux commands by closing the case. Localhost only, fully offline.

BUILD (Windows, with internet):  build.bat   -> linux-game.tar (game + lab images) + debs\   (the build is slow and large)
   The build runs the solvability gate first: `docker build --target validator .`
   proves every level and lab is solvable (53/53) before the runtime images assemble.
TEST on Windows (automated):  powershell -ExecutionPolicy Bypass -File tests\run-base-test.ps1
   builds, starts, checks both logins (game + lab), verifies the dashboard follows the SSH session; exit code 0 = pass
TEST on Windows (e2e):  python tests\e2e_suite.py
   API smoke + abuse, secrets-leak sweep, L0..L7 solve flow through the real ssh grading
   path, hint economics, isolation, offline statics, lab verify; exit code 0 = pass
TEST on Windows (manual):  docker compose up -d --build
   http://localhost:9021  -> welcome screen (nobody connected)
   ssh level0@localhost -p 2222   (password: begin)   -> page switches to level 0
   ssh level1@localhost -p 2222   (password from levels.yaml) -> page switches to level 1; level 0 stays readable in the sidebar
   ssh intern@localhost -p 2223   (password: learn)   -> practice lab with sudo
HOW PROGRESSION WORKS
   Flag levels hand you the next key inside the level (read carefully). Task/boss/capstone
   levels are graded: the dashboard (or POST /api/verify) re-checks your work over ssh,
   then stages the next key in ~/.cleared. Logging in marks progress (PAM); points feed
   ranks: Constable 0, Detective 800, Sergeant 2000, Inspector 3500. Hints cost 5/15/30.
PENDRIVE: linux-game.tar, docker-compose.yml, debs\
MINT (offline):
  sudo apt install ./debs/*.deb
  sudo docker load -i linux-game.tar
  sudo docker compose up -d
RESET (restores deleted files, clears progress):  sudo docker compose down && sudo docker compose up -d
RESET ONE LEVEL (files only, keeps your progress):
   docker exec linuxgame python3 /opt/game/setup.py --target game --level 7
   ...or simply:  reset.bat 7  (Windows)   /   bash resetLevel.sh 7  (run from the repo root)
Host key warning after a rebuild:  ssh-keygen -R "[localhost]:2222"   (and :2223 for the lab)
To allow other PCs: change "127.0.0.1:" ports in docker-compose.yml to plain "9021", "2222", "2223".
LEARN MORE (repo only, never shipped to learners): docs/AUTHORING.md (schemas),
docs/STORY_BIBLE.md (all 48 levels + puzzles + labs), docs/API_CONTRACT.md (server/dashboard).
