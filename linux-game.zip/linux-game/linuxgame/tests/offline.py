#!/usr/bin/env python3
"""Offline / no-egress suite (host world). docs/TEST_PLAN.md section 1.6.

Asserts the game is fully offline:
  1. static scan of source assets for external URLs / CDN tokens
  2. live HTTP bodies (GET /, /api/commands, /api/casebook) carry no external URL
  3. runtime: established TCP peers of game+lab are loopback or compose subnet only

Run from the repo root with the stack up: python linuxgame/tests/offline.py
"""
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common as C  # noqa: E402

# Tokens that indicate a remote asset/dependency (AUTHORING section 4 offline).
BAD_TOKENS = [
    "cdn.", "jsdelivr", "unpkg", "googleapis", "fonts.gstatic",
    "cloudflare", "bootstrapcdn", "ajax.googleapis", "cdnjs",
]
# Absolute http(s) URLs that are NOT localhost/127.0.0.1 are suspicious. We
# allow explicit localhost/127.0.0.1 references (the learner talks to those).
URL_RE = re.compile(r"https?://([^\s\"'<>]+)", re.I)
LOCAL_HOSTS = ("localhost", "127.0.0.1", "0.0.0.0", "::1")

SOURCE_ASSETS = [
    os.path.join(C.GAME_DIR, "index.html"),
    os.path.join(C.GAME_DIR, "server.py"),
    os.path.join(C.GAME_DIR, "levels.yaml"),
    os.path.join(C.LINUXGAME_DIR, "commands", "commands.yaml"),
]

COMPOSE_SUBNET_PREFIXES = ("172.16.", "172.17.", "172.18.", "172.19.",
                          "10.", "192.168.")


def _external_urls(text):
    """Return list of non-local hosts referenced by http(s) URLs in text."""
    bad = []
    for m in URL_RE.finditer(text or ""):
        hostport = m.group(1)
        host = hostport.split("/")[0].split("@")[-1].split(":")[0].strip("[]")
        if host.lower() in LOCAL_HOSTS:
            continue
        bad.append(m.group(0))
    return bad


def check_static_assets():
    for path in SOURCE_ASSETS:
        name = os.path.relpath(path, C.ROOT)
        if not os.path.isfile(path):
            C.check("static: %s exists" % name, False, "missing file")
            continue
        text = open(path, encoding="utf-8", errors="replace").read()
        # CDN / remote-asset tokens
        hits = [t for t in BAD_TOKENS if t.lower() in text.lower()]
        C.check("static: %s has no CDN/remote tokens" % name,
                not hits, "found %s" % hits)
        # external absolute URLs
        bad = _external_urls(text)
        C.check("static: %s has no external URLs" % name,
                not bad, "found %s" % bad[:3])
        # explicit CSS/HTML remote-asset patterns
        if path.endswith(".html"):
            for pat, label in [
                    (r"@import\s+url\(\s*['\"]?https?:", "CSS @import http"),
                    (r"url\(\s*['\"]?https?://", "CSS url(http)"),
                    (r"<link[^>]+rel=[\"']?stylesheet[^>]+href=[\"']?https?:",
                     "remote stylesheet"),
                    (r"<script[^>]+src=[\"']?https?:", "remote script src")]:
                C.check("static: %s has no %s" % (name, label),
                        not re.search(pat, text, re.I),
                        "pattern %r matched" % label)


def check_live_bodies():
    for path in ("/", "/api/commands", "/api/casebook"):
        body, code = C.http_raw(path)
        text = body.decode("utf-8", errors="replace") if isinstance(body, bytes) else str(body)
        bad = _external_urls(text)
        hits = [t for t in BAD_TOKENS if t.lower() in text.lower()]
        C.check("live: %s (rc=%s) has no external URL/CDN" % (path, code),
                not bad and not hits, "url=%s cdn=%s" % (bad[:2], hits[:3]))


def _peers(container):
    rc, out, err = C.exec_sh(
        container,
        "ss -tnH state established 2>/dev/null | awk '{print $5}' || true",
        timeout=30)
    if rc != 0:
        return None, err
    peers = [ln.strip().rsplit(":", 1)[0] for ln in out.splitlines() if ln.strip()]
    return peers, ""


def _is_private(host):
    if host in LOCAL_HOSTS:
        return True
    return any(host.startswith(p) for p in COMPOSE_SUBNET_PREFIXES)


def check_runtime_peers():
    for container in (C.GAME_CONTAINER, C.LAB_CONTAINER):
        peers, err = C._peers(container) if hasattr(C, "_peers") else _peers(container)
        if peers is None:
            C.check("runtime: %s peers readable" % container, False, err.strip()[:120])
            continue
        bad = [p for p in peers if p and not _is_private(p)]
        C.check("runtime: %s established peers all private" % container,
                not bad, "public peers %s" % bad[:5])


def main():
    C.require_stack()
    check_static_assets()
    check_live_bodies()
    check_runtime_peers()
    C.finish("offline")


if __name__ == "__main__":
    main()
