#!/usr/bin/env python3
"""API-hardening / abuse suite (host world). docs/TEST_PLAN.md section 1.5.

Asserts the server rejects bad input, keeps scores server-side, survives
oversized/malformed bodies, blocks path traversal, and is idempotent on replay.

Run from the repo root with the stack up: python linuxgame/tests/abuse.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common as C  # noqa: E402

PUZZLE_ID = "match-1"


def set_reached(level):
    """Set the PAM progress so reached == level (list-arg docker exec)."""
    C.exec_in(C.GAME_CONTAINER,
              ["bash", "-c",
               "printf '%s\\n' %s > /var/lib/game/progress"
               % ("%s", " ".join("'level%d'" % i for i in range(level + 1)))],
              timeout=20)


def reset_scores():
    C.exec_in(C.GAME_CONTAINER, ["bash", "-c",
                                "rm -f /var/lib/game/scores.json"], timeout=15)


def read_scores_total():
    data, code = C.http_json("/api/state")
    if code == 200 and isinstance(data, dict):
        return (data.get("scores") or {}).get("total", 0)
    return None


def check_locked_and_bad_input():
    C.reset_state()
    set_reached(0)
    # locked GRADED level (7 is task) n > reached -> 403. Non-graded levels are
    # rejected 400 by design (cannot verify a flag level), so use a graded id.
    for n in (7, 47):
        _, code = C.http_post("/api/verify", {"n": n})
        C.check("POST /api/verify graded n=%d (locked) -> 403" % n,
                code == 403, "got %s" % code)
    # out of range -> 4xx (400 by design, before the lock check)
    _, code = C.http_post("/api/verify", {"n": 9999})
    C.check("POST /api/verify n=9999 (range) -> 4xx", isinstance(code, int) and 400 <= code < 500,
            "got %s" % code)
    # bad n types -> 400
    for payload in [{"n": -1}, {}, {"n": None}]:
        _, code = C.http_post("/api/verify", payload)
        C.check("POST /api/verify %r -> 400" % payload, code == 400, "got %s" % code)


def check_score_tamper():
    C.reset_state()
    set_reached(0)
    before = read_scores_total()
    # Try to inject score fields on a locked GRADED verify; grants stay server-side.
    _, code = C.http_post("/api/verify",
                          {"n": 7, "points": 99999, "total": 99999,
                           "score": 99999, "scores": {"total": 99999}})
    after = read_scores_total()
    C.check("score tamper: verify stays 403 and total unchanged",
            code == 403 and before == after,
            "code=%s before=%s after=%s" % (code, before, after))
    # puzzle replay idempotency: solve match-1 twice (need reached>=requires).
    # requires for match-1 is 0, so reachable at reached=0.
    ans = _puzzle_answer()
    if ans is None:
        C.check("abuse: puzzle answer resolvable", False, "match-1 not found")
        return
    r1, c1 = C.http_post("/api/puzzle", {"id": PUZZLE_ID, "answer": ans})
    r2, c2 = C.http_post("/api/puzzle", {"id": PUZZLE_ID, "answer": ans})
    pts1 = (r1 or {}).get("points") if isinstance(r1, dict) else None
    pts2 = (r2 or {}).get("points") if isinstance(r2, dict) else None
    ok1 = isinstance(r1, dict) and r1.get("ok")
    ok2 = isinstance(r2, dict) and r2.get("ok")
    C.check("puzzle: first solve ok + points", ok1 and (pts1 or 0) >= 0,
            "r1=%r" % r1)
    C.check("puzzle: replay ok + 0 points", ok2 and pts2 == 0,
            "r2=%r" % r2)


def _puzzle_answer():
    """Fetch the interactive's answer from levels.yaml (test-time only)."""
    doc = C.load_levels()
    for it in doc.get("interactive") or []:
        if it.get("id") == PUZZLE_ID:
            return it.get("answer")
    return None


def check_oversized_and_malformed():
    C.reset_state()
    set_reached(0)
    big = "x" * (5 * 1024 * 1024)
    for ep in ("/api/hint", "/api/verify", "/api/puzzle"):
        _, code = C.http_post(ep, {"n": 0, "blob": big}, timeout=30)
        # Accept a clean 4xx OR a connection abort (server closed the socket to
        # reject the oversized body before it was fully read) — both are valid
        # hardening; only a 5xx or a hung server is a failure.
        aborted = isinstance(code, str) and code.startswith("ERR:")
        ok = (isinstance(code, int) and code < 500) or aborted
        C.check("oversized body to %s handled (no 5xx)" % ep, ok, "got %s" % code)
    # malformed JSON via raw request
    import urllib.request
    import urllib.error
    for broken in (b"{broken", b"", b"null"):
        req = urllib.request.Request(
            C.API + "/api/verify", data=broken,
            headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                code = r.status
        except urllib.error.HTTPError as e:
            code = e.code
        except Exception as e:
            code = "ERR:%s" % e
        C.check("malformed body %r -> 4xx (no 5xx)" % broken[:8],
                isinstance(code, int) and 400 <= code < 500, "got %s" % code)
    # server still alive
    _, code = C.http_json("/api/state")
    C.check("server alive after oversized/malformed", code == 200, "got %s" % code)


def check_path_traversal():
    for p in ("/api/level?n=../../etc/passwd", "/api/level?n=%2e%2e%2f",
              "/../etc/passwd", "/api/level?n=..%2f..%2fetc%2fpasswd"):
        body, code = C.http_raw(p)
        text = body.decode("utf-8", errors="replace") if isinstance(body, bytes) else str(body)
        safe = (not isinstance(code, int) or code >= 400) and "root:x:0:0" not in text
        C.check("traversal %s blocked" % p, safe, "code=%s" % code)
    # /api/export ignores unknown query params (returns the learner export);
    # the property that matters is that no filesystem content ever leaks.
    body, code = C.http_raw("/api/export?file=/etc/shadow")
    text = body.decode("utf-8", errors="replace") if isinstance(body, bytes) else str(body)
    C.check("export?file=/etc/shadow leaks no file content",
            "root:x:0:0" not in text and "/bin/bash" not in text,
            "code=%s body leaks file content" % code)


def check_hint_economics():
    C.reset_state()
    set_reached(0)
    # emptied scores -> low_score (409) on a paid hint. Level 0 hints may be free;
    # use a level whose hint costs points: reach level 2 and empty scores.
    set_reached(2)
    reset_scores()
    _, code = C.http_post("/api/hint", {"n": 2})
    C.check("hint with empty scores -> 409/403 (not 200 freebie)",
            code in (403, 409), "got %s" % code)
    # n > reached -> 403
    set_reached(0)
    _, code = C.http_post("/api/hint", {"n": 5})
    C.check("hint n>reached -> 403", code == 403, "got %s" % code)


def main():
    C.require_stack()
    check_locked_and_bad_input()
    check_score_tamper()
    check_oversized_and_malformed()
    check_path_traversal()
    check_hint_economics()
    C.reset_state()
    C.finish("abuse")


if __name__ == "__main__":
    main()
