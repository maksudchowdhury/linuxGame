#!/usr/bin/env python3
"""Isolation / PAM-marking & reset suite (host world). docs/TEST_PLAN.md 1.3.

Uses sshpass INSIDE the game container (the image ships sshpass + sshd on
localhost:22) so password-SSH assertions need no tester container. Proves:
  Phase A:
    - wrong password is rejected and does not advance progress
    - a correct login advances reached to exactly that level
    - logging into level3 (skipping 2) does NOT make level2 reachable (the
      progress file records only levels actually authenticated)
    - level1 cannot read level2's home (FS isolation)
  Phase B (compose down && up):
    - challenge files are restored, learner junk is gone, reached resets to 0

Run from the repo root with the stack up: python linuxgame/tests/isolation.py
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common as C  # noqa: E402

SSH_OPTS = ("-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "
            "-o LogLevel=ERROR -o ConnectTimeout=5 -o PasswordAuthentication=yes")


def ssh_login(user, password, cmd="true", port=22):
    """Attempt an ssh login inside the game container; returns (rc, output)."""
    script = ("sshpass -p '%s' ssh %s -p %d %s@localhost %s 2>&1"
              % (password.replace("'", "'\\''"), SSH_OPTS, port, user, cmd))
    rc, out, _ = C.exec_sh(C.GAME_CONTAINER, script, timeout=40)
    return rc, out


def progress_lines():
    rc, out, _ = C.exec_sh(C.GAME_CONTAINER,
                           "cat /var/lib/game/progress 2>/dev/null || true",
                           timeout=20)
    return [l.strip() for l in (out or "").splitlines() if l.strip()]


def reached():
    data, code = C.http_json("/api/state")
    return data.get("reached") if code == 200 and isinstance(data, dict) else None


def level_status(n):
    _, code = C.http_json("/api/level?n=%d" % n)
    return code


def check_wrong_password(secrets):
    C.reset_state()
    before = progress_lines()
    rc, out = ssh_login("level2", "definitely-wrong-password")
    C.check("wrong password rejected (non-zero rc)", rc != 0, "rc=%s" % rc)
    time.sleep(1)
    C.check("wrong password does not advance progress",
            progress_lines() == before, "progress changed")
    C.check("level2 still locked after wrong password",
            level_status(2) == 403, "got %s" % level_status(2))


def check_progress_advances(secrets):
    C.reset_state()
    rc, out = ssh_login("level1", secrets[1])
    C.check("level1 correct password accepted", rc == 0, "rc=%s out=%s" % (rc, out[-120:]))
    time.sleep(1)
    C.check("reached advanced to 1", reached() == 1, "reached=%s" % reached())
    C.check("level2 still locked (n+1 without clearing)", level_status(2) == 403,
            "got %s" % level_status(2))


def check_no_level_jump(secrets):
    # Login directly to level3 (we know its password). progress should record
    # only level3; level2 (never authenticated) must stay locked.
    C.reset_state()
    rc, out = ssh_login("level3", secrets[3])
    C.check("level3 correct password accepted", rc == 0, "rc=%s" % rc)
    time.sleep(1)
    lines = progress_lines()
    C.check("progress records level3", "level3" in lines, "progress=%s" % lines)
    C.check("reached advanced to 3", reached() == 3, "reached=%s" % reached())
    # level2 was never logged into -> must remain locked even though 3 is open.
    C.check("level2 locked despite level3 reached", level_status(2) == 403,
            "got %s" % level_status(2))


def check_fs_isolation(secrets):
    # As level1, reading the file in /home/level2 that holds secrets[3] must be
    # permission-denied (homes are 700 per setup.py).
    plant = C.exec_sh(C.GAME_CONTAINER,
                      "grep -rl '%s' /home/level2 2>/dev/null | head -1 || true"
                      % secrets[3].replace("'", "'\\''"), timeout=30)[1].strip()
    if not plant:
        C.check("fs isolation: level2 plant found", False, "no file with secrets[3]")
        return
    rc, out, err = C.exec_sh(C.GAME_CONTAINER,
                             "runuser -u level1 -- cat '%s' >/dev/null 2>&1; echo $?"
                             % plant, timeout=20)
    denied = (out or "").strip().endswith("1")
    C.check("fs isolation: level1 cannot read level2's %s" % os.path.basename(plant),
            denied, "rc=%s" % (out or "").strip())


def check_reset():
    # Drop junk in level0's home and delete a challenge file, then down/up.
    C.exec_sh(C.GAME_CONTAINER,
              "rm -f /home/level0/welcome/readme.txt; "
              "touch /home/level0/junk-learner-dropped.txt", timeout=20)
    # Advance reached so we can prove it resets.
    C.exec_sh(C.GAME_CONTAINER,
              "printf 'level0\\nlevel1\\n' > /var/lib/game/progress", timeout=15)
    C.compose(["down"], timeout=180)
    C.compose(["up", "-d"], timeout=180)
    up = C.wait_api(120)
    C.check("stack back up after down/up", up, "api never returned 200")
    if not up:
        return
    # challenge file restored
    rc, out, _ = C.exec_sh(C.GAME_CONTAINER,
                           "test -s /home/level0/welcome/readme.txt; echo $?",
                           timeout=20)
    restored = (out or "").strip().endswith("0")
    C.check("reset: deleted challenge file restored", restored, "rc=%s" % (out or "").strip())
    # learner junk gone
    rc, out, _ = C.exec_sh(C.GAME_CONTAINER,
                           "test -e /home/level0/junk-learner-dropped.txt; echo $?",
                           timeout=20)
    gone = (out or "").strip().endswith("1")
    C.check("reset: learner junk removed", gone, "rc=%s" % (out or "").strip())
    # reached reset (no volumes -> progress wiped on recreate)
    C.check("reset: reached back to 0", reached() == 0, "reached=%s" % reached())


def main():
    C.require_stack()
    secrets = C.load_secrets()
    check_wrong_password(secrets)
    check_progress_advances(secrets)
    check_no_level_jump(secrets)
    check_fs_isolation(secrets)
    check_reset()
    C.finish("isolation")


if __name__ == "__main__":
    main()
