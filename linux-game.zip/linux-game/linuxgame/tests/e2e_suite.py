#!/usr/bin/env python3
"""E2E runtime suite (host-side) for the running compose stack.

Pragmatic fold of TEST_PLAN.md: API smoke + abuse, secrets-leak sweep,
solve/verify flow through the real ssh grading path, hint economics,
labverify, isolation (home modes, loopback-only peers), offline statics.

Run:  python tests/e2e_suite.py          (requires `docker compose up -d` healthy)
Exit: 0 = all pass. Never prints passwords.
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
GAME_DIR = os.path.join(ROOT, "linuxgame")
HTTP = "http://127.0.0.1:9021"
GAME_C = "linuxgame"
LAB_C = "linuxlab"

PASS = 0
FAIL = 0


def ok(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  [PASS] %s" % name)
    else:
        FAIL += 1
        print("  [FAIL] %s %s" % (name, detail[:160]))


def req(path, data=None, raw=False, timeout=30):
    url = HTTP + path
    body = None
    headers = {}
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    r = urllib.request.Request(url, data=body, headers=headers,
                               method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            payload = resp.read()
            if raw:
                return resp.status, payload
            return resp.status, json.loads(payload)
    except urllib.error.HTTPError as e:
        payload = e.read()
        if raw:
            return e.code, payload
        try:
            return e.code, json.loads(payload)
        except ValueError:
            return e.code, {"error": payload[:80].decode("utf-8", "replace")}
    except (urllib.error.URLError, ConnectionError, OSError, TimeoutError):
        # mid-restart connection refused / reset — callers treat as not-ready
        return 0, {"error": "connection"}


def docker(*args, timeout=120):
    return subprocess.run(["docker", *args], capture_output=True,
                          text=True, timeout=timeout)


def dc(*args, timeout=120):
    return subprocess.run(["docker", "compose", *args], cwd=GAME_DIR,
                          capture_output=True, text=True, timeout=timeout)


def load_secrets():
    with open(os.path.join(GAME_DIR, "game", "secrets.yaml"), encoding="utf-8") as fh:
        return {str(k): str(v) for k, v in
                (yaml.safe_load(fh) or {}).get("passwords", {}).items()}


def load_solution(n):
    with open(os.path.join(GAME_DIR, "solutions", "solutionbook.yaml"),
              encoding="utf-8") as fh:
        book = yaml.safe_load(fh)
    for e in book["solutions"]:
        if e["id"] == n:
            return e["solution"]
    raise KeyError(n)


def wait_healthy():
    for _ in range(60):
        s, st = req("/api/state", timeout=4)
        if s == 200:
            return True
        time.sleep(2)
    return False


def reset_state():
    docker("exec", GAME_C, "bash", "-c",
           "truncate -s 0 /var/lib/game/progress; "
           "echo '{}' > /var/lib/game/scores.json; "
           "chown gameserver:gameserver /var/lib/game/scores.json; "
           "for i in $(seq 0 47); do rm -f /home/level$i/.cleared; done")
    dc("restart", "game")
    wait_healthy()


def solve_in_container(container, user, home, script):
    """Pipe a solution into the container and run it as `user` (root exec)."""
    wrapped = "#!/bin/bash\ncd %s\n%s\n" % (home, script)
    p = subprocess.run(["docker", "exec", "-i", container, "bash", "-c",
                        "cat > /tmp/_sol.sh && chmod 755 /tmp/_sol.sh && "
                        "runuser -u %s -- env HOME=%s bash /tmp/_sol.sh; "
                        "rm -f /tmp/_sol.sh" % (user, home)],
                       input=wrapped.encode("utf-8"), capture_output=True,
                       timeout=120)
    return p.returncode, ((p.stdout or b"").decode("utf-8", "replace") +
                          (p.stderr or b"").decode("utf-8", "replace"))


def main():
    secrets = load_secrets()
    pw_list = [v for k, v in sorted(secrets.items(), key=lambda kv: kv[0])
               if k != "0" and len(v) >= 8]  # never check the public 'begin'

    print("== e2e: wait for healthy ==")
    ok("game responds", wait_healthy())

    print("== e2e: reset ==")
    reset_state()
    s, st = req("/api/state")
    ok("state.reached fresh after reset", st.get("reached") in (0, None),
       "got %s" % (st.get("reached"),))
    ok("state.total 0 after reset", st.get("scores", {}).get("total") == 0)

    print("== e2e: API smoke ==")
    for path in ("/api/commands", "/api/casebook", "/api/export", "/"):
        s, body = req(path, raw=True) if path == "/" else req(path)
        ok("GET %s -> 200" % path, s == 200)
    s, body = req("/api/level?n=0")
    ok("GET /api/level?n=0 -> 200", s == 200)
    ok("level payload has story+goal+commands",
       isinstance(body, dict) and body.get("story") and body.get("goal")
       and body.get("commands"))
    s, body = req("/api/level?n=2")
    ok("GET /api/level?n=2 -> 403 locked", s == 403)
    s, body = req("/api/level?n=9999")
    ok("GET /api/level?n=9999 -> 4xx", s in (400, 403, 404))

    print("== e2e: API abuse ==")
    s, body = req("/api/verify", {"n": 8})   # graded boss, still locked
    ok("POST /api/verify locked graded level -> 403", s == 403, str(body)[:80])
    s, body = req("/api/verify", {"n": -1})
    ok("POST /api/verify n=-1 -> 400/403", s in (400, 403))
    s, body = req("/api/hint", {"n": 8})     # locked
    ok("POST /api/hint locked level -> 403", s == 403, str(body)[:80])
    s, body = req("/api/hint", {"n": 99})    # out of range
    ok("POST /api/hint n=99 -> 400/403", s in (400, 403))
    s, body = req("/api/puzzle", {"id": "nosuch", "answer": "x"})
    ok("POST /api/puzzle unknown id -> 4xx", s in (400, 403, 404))
    big = b"x" * (5 * 1024 * 1024)
    r = urllib.request.Request(HTTP + "/api/verify", data=big,
                               headers={"Content-Type": "application/json"},
                               method="POST")
    try:
        urllib.request.urlopen(r, timeout=15)
        s = 200
    except urllib.error.HTTPError as e:
        s = e.code
    except Exception:
        s = -1
    ok("oversized POST body handled 4xx/conn-close", s != 200, "status %s" % s)
    s, body = req("/api/level?n=..%2f..%2fetc%2fpasswd")
    ok("path traversal /api/level -> 4xx", s in (400, 403, 404))

    print("== e2e: GET /api/hint must not exist ==")
    s, body = req("/api/hint?n=0", raw=True)
    text = body.decode("utf-8", "replace") if isinstance(body, bytes) else str(body)
    ok("GET /api/hint is not a hint payload", not (s == 200 and "hint" in text),
       "status %s" % s)

    print("== e2e: secrets-leak sweep (HTTP) ==")
    endpoints = ["/api/state", "/api/level?n=0", "/api/commands",
                 "/api/casebook", "/api/export", "/"]
    leaks = []
    for path in endpoints:
        s, raw = req(path, raw=True)
        text = raw.decode("utf-8", "replace")
        for pw in pw_list:
            if pw in text:
                leaks.append("%s contains a secret" % path)
    ok("no password in any learner-facing response", not leaks, "; ".join(leaks))

    print("== e2e: solve L0 (flag) + PAM walk to L7 ==")
    sol0 = load_solution(0)
    rc, out = solve_in_container(GAME_C, "level0", "/home/level0", sol0)
    ok("L0 solution exits 0 in container", rc == 0, out[-160:])
    # flag levels hand over the next key by printing it; the learner then logs
    # in as the next user (PAM marks reached). Solve+login L1..L7 the same way.
    advanced = []
    for k in range(1, 8):
        sol = load_solution(k)
        rc, out = solve_in_container(GAME_C, "level%d" % k,
                                     "/home/level%d" % k, sol)
        if rc != 0:
            break
        r = docker("exec", GAME_C, "su", "-", "level%d" % k, "-c", "true",
                   timeout=30)
        if r.returncode != 0:
            break
        advanced.append(k)
    s, st = req("/api/state")
    ok("PAM walk reached == 7", st.get("reached") == 7,
       "reached=%s advanced=%s" % (st.get("reached"), advanced))
    total = st.get("scores", {}).get("total", 0)
    ok("scores.total > 0 after walk", total > 0, "total=%s" % total)

    print("== e2e: graded verify L7 through real ssh grading ==")
    rc, out = solve_in_container(GAME_C, "level7", "/home/level7", load_solution(7))
    ok("L7 solution exits 0 in container", rc == 0, out[-160:])
    s, body = req("/api/verify", {"n": 7})
    ok("POST /api/verify {n:7} graded pass", s == 200 and body.get("ok") is True,
       "status %s body %s" % (s, str(body)[:120]))
    ok("verify awards points for L7", body.get("points", 0) > 0, str(body)[:120])
    r = docker("exec", GAME_C, "bash", "-c",
               "test -s /home/level7/.cleared && echo CLEARED")
    ok("next key staged in ~/.cleared", "CLEARED" in (r.stdout or ""))
    s, body = req("/api/verify", {"n": 7})
    ok("replay /api/verify {n:7} re-grants 0",
       s == 200 and body.get("points") == 0, str(body)[:120])
    ok("GET /api/level?n=7 -> 200 after verify path",
       req("/api/level?n=7")[0] == 200)

    print("== e2e: PAM marks L8..L19 (lab requires gate) ==")
    for k in range(8, 20):
        r = docker("exec", GAME_C, "su", "-", "level%d" % k, "-c", "true",
                   timeout=30)
        if r.returncode != 0:
            break
    s, st = req("/api/state")
    ok("reached >= 19 for lab requires", (st.get("reached") or 0) >= 19,
       "reached=%s" % st.get("reached"))

    print("== e2e: hint economics ==")
    s, st = req("/api/state")
    before = st.get("scores", {}).get("total", 0)
    s, body = req("/api/hint", {"n": 1})
    ok("POST /api/hint {n:1} -> 200", s == 200 and "hint" in body,
       "status %s" % s)
    if s == 200:
        ok("hint cost deducted from total",
           body.get("total") == before - body.get("cost", -1),
           "before=%s body=%s" % (before, str(body)[:120]))

    print("== e2e: isolation ==")
    r = docker("exec", GAME_C, "bash", "-c",
               "stat -c '%a' /home/level0 /home/level1 | tr '\\n' ' '")
    modes = (r.stdout or "").split()
    ok("level homes mode 700", modes == ["700", "700"], "got %s" % modes)
    r = docker("exec", GAME_C, "bash", "-c",
               "runuser -u level1 -- cat /home/level0/.profile >/dev/null 2>&1; echo $?")
    ok("level1 cannot read level0 home", (r.stdout or "").strip() == "1")
    # Authoritative exposure control: the published ports must bind
    # loopback only on the host (a local browser session legitimately
    # appears inside the container as a docker-gateway peer, so
    # container-side ss alone cannot distinguish it from LAN exposure).
    ns = subprocess.run(["netstat", "-ano", "-p", "tcp"],
                        capture_output=True, text=True).stdout
    listeners = {}
    for line in ns.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[0].upper() == "TCP" \
                and parts[3] == "LISTENING":
            port = parts[1].rsplit(":", 1)[-1]
            if port in ("9021", "2223"):
                listeners.setdefault(port, []).append(
                    parts[1].rsplit(":", 1)[0])
    ok("game+lab published ports bind loopback only",
       all(ips and all(ip in ("127.0.0.1", "::1", "[::1]") for ip in ips)
           for ips in (listeners.get("9021"), listeners.get("2223"))),
       str(listeners))
    for c in (GAME_C, LAB_C):
        r = docker("exec", c, "bash", "-c",
                   "gw=$(ip route | awk '/default/ {print $3}'); "
                   "ss -tnH state established | awk '{print $5}' | "
                   "sed 's/:[0-9]*$//' | "
                   "grep -v -e '^127\\.' -e '^::1$' -e \"^${gw}$\" | "
                   "grep -v '^$' | wc -l")
        ok("%s: peers only loopback or docker port-forward gateway" % c,
           (r.stdout or "").strip() == "0", (r.stdout or "").strip())

    print("== e2e: offline statics ==")
    s, raw = req("/", raw=True)
    html = raw.decode("utf-8", "replace")
    external = re.findall(r'(?:src|href)=["\']https?://(?!127\.0\.0\.1|localhost)[^"\']+',
                          html)
    ok("dashboard loads no external assets", not external, str(external[:3]))
    with open(os.path.join(GAME_DIR, "game", "server.py"), encoding="utf-8") as fh:
        srv = fh.read()
    ok("server.py makes no outbound http calls",
       "urllib.request.urlopen(\"http" not in srv.replace("'", '"'))

    print("== e2e: labverify first-users ==")
    lab = None
    with open(os.path.join(GAME_DIR, "game", "levels.yaml"), encoding="utf-8") as fh:
        doc = yaml.safe_load(fh)
    for lb in doc["labs"]:
        if lb["id"] == "first-users":
            lab = lb
    book = yaml.safe_load(open(os.path.join(GAME_DIR, "solutions", "solutionbook.yaml"),
                               encoding="utf-8"))
    lab_sol = next(e["solution"] for e in book["labs"] if e["id"] == "first-users")
    rc, out = solve_in_container(LAB_C, "intern", "/home/intern", lab_sol)
    ok("lab first-users solution exits 0", rc == 0, out[-160:])
    s, body = req("/api/labverify", {"id": "first-users"})
    ok("POST /api/labverify first-users -> ok", s == 200 and body.get("ok") is True,
       "status %s body %s" % (s, str(body)[:120]))

    print("== e2e: clean-state guardrail (reset restores) ==")
    reset_state()
    s, st = req("/api/state")
    ok("reached back to fresh after second reset", st.get("reached") in (0, None),
       "got %s" % st.get("reached"))

    print()
    print("E2E RESULT: %d pass, %d fail" % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
