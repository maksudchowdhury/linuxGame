<#
 Phase 0 base test runner (Windows, PowerShell).

   powershell -ExecutionPolicy Bypass -File tests\run-base-test.ps1 [-Rebuild] [-Down]

Builds both images, starts compose, checks the host port mappings, resets the
progress file (reproducible baseline), runs tests/base_test.py in a throwaway
tester container (compose profile "tests"), then verifies from the host that
the PAM hook really appended to the progress file.
Exit code 0 = all checks passed.
#>
param(
    [switch]$Rebuild,   # docker compose build --no-cache
    [switch]$Down       # docker compose down after the test
)
$ErrorActionPreference = "Stop"
Push-Location (Split-Path -Parent $PSScriptRoot)
try {
    if ($Rebuild) { docker compose build --no-cache } else { docker compose build }
    if ($LASTEXITCODE -ne 0) { throw "docker compose build failed" }

    docker compose up -d
    if ($LASTEXITCODE -ne 0) { throw "docker compose up failed" }

    $portFail = $false
    foreach ($p in 9021, 2222, 2223) {
        $ok = $false
        for ($i = 0; $i -lt 60; $i++) {
            try {
                $c = New-Object Net.Sockets.TcpClient
                $c.Connect("127.0.0.1", $p)
                $c.Close()
                $ok = $true
                break
            } catch { Start-Sleep -Seconds 1 }
        }
        if ($ok) { Write-Host "[PASS] host port 127.0.0.1:$p reachable" }
        else { Write-Host "[FAIL] host port 127.0.0.1:$p not reachable"; $portFail = $true }
    }
    if ($portFail) { exit 1 }

    # reproducible baseline: nobody has reached any level
    docker exec linuxgame truncate -s 0 /var/lib/game/progress
    if ($LASTEXITCODE -ne 0) { Write-Host "[FAIL] could not reset progress file"; exit 1 }
    Write-Host "[PASS] progress file truncated (baseline reached=0)"

    docker compose --profile tests build tester
    if ($LASTEXITCODE -ne 0) { throw "tester build failed" }

    docker compose --profile tests run --rm tester
    $code = $LASTEXITCODE

    # host-side proof that the PAM hook wrote during this run's logins
    $prog = docker exec linuxgame cat /var/lib/game/progress
    $hasL0 = [bool]($prog | Select-String -Pattern '^level0$')
    $hasL1 = [bool]($prog | Select-String -Pattern '^level1$')
    if ($hasL0 -and $hasL1) {
        Write-Host "[PASS] PAM hook recorded level0 and level1 in /var/lib/game/progress"
    } else {
        Write-Host "[FAIL] progress file missing entries: $($prog -join ', ')"
        $code = 1
    }

    Write-Host "`n-- compose status --"
    docker compose ps

    if ($Down) { docker compose --profile tests down }
    exit $code
}
finally { Pop-Location }
