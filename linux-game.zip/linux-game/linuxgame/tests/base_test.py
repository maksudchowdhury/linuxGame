#!/usr/bin/env python3
"""Phase 0 base test (runs inside the tester container, compose profile "tests").

Covers the Phase 0 bar from the spec:
  1. dashboard answers and shows the welcome screen
  2. initial API state is sane (nobody connected, level 0 open, rest locked)
  3. SSH login works on the game service and the dashboard follows the session
     (level0 then level1; the level1 login proves the PAM -> progress -> API chain
      because `reached` only changes when a level > 0 logs in)
  4. locked levels stay 403; progress persists after logout
  5. SSH login and sudo work in the lab service (intern)

NOTE: run via tests/run-base-test.ps1, which truncates /var/lib/game/progress
first so the "initial: reached == 0" baseline is reproducible.
"""
import json
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request

import yaml

GAME = os.environ.get("GAME_HOST", "game")
LAB = os.environ.get("LAB_HOST", "lab")
API = "http://%s:9021" % GAME
LEVELS = yaml.safe_load(open("/opt/test/levels.yaml", encoding="utf-8"))["levels"]
# Passwords live only in secrets.yaml (never in levels.yaml). The tester image
# is test-only (never exported to learners) so it may carry secrets.yaml.
SECRETS = {int(k): str(v) for k, v in
           (yaml.safe_load(open("/opt/test/secrets.yaml", encoding="utf-8"))
            .get("passwords") or {}).items()}

failures = []


def check(name, cond, detail=""):
    print("[%s] %s%s" % ("PASS" if cond else "FAIL", name,
                         (" -- " + detail) if (detail and not cond) else ""),
          flush=True)
    if not cond:
        failures.append(name + ((": " + detail) if detail else ""))


def get(path):
    """GET; returns (json_or_None, http_code)."""
    try:
        with urllib.request.urlopen(API + path, timeout=5) as r:
            return json.loads(r.read().decode()), r.status
    except urllib.error.HTTPError as e:
        return None, e.code


def state():
    data, code = get("/api/state")
    if code != 200 or data is None:
        raise RuntimeError("GET /api/state -> %s" % code)
    return data


def wait_until(fn, timeout, interval=1.0):
    """Poll fn() until it returns something truthy or timeout passes."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            v = fn()
            if v:
                return v
        except Exception:
            pass
        time.sleep(interval)
    return None


def ssh_base(host, user, pw, port=22, tty=False):
    cmd = ["sshpass", "-p", pw, "ssh",
           "-o", "StrictHostKeyChecking=no",
           "-o", "UserKnownHostsFile=/dev/null",
           "-o", "LogLevel=ERROR",
           "-o", "ConnectTimeout=5",
           "-p", str(port)]
    if tty:
        # Force a pty: server.py's "connected" scan counts processes with a
        # controlling tty, exactly like a real learner's interactive login.
        cmd.append("-tt")
    cmd.append("%s@%s" % (user, host))
    return cmd


def ssh_run(host, user, pw, remote, port=22, timeout=45):
    p = subprocess.run(ssh_base(host, user, pw, port) + [remote],
                       capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout.strip(), p.stderr.strip()


def spawn_session(host, user, pw, seconds):
    """Interactive-style SSH session (forced pty) that just sleeps."""
    return subprocess.Popen(
        ssh_base(GAME if host == GAME else host, user, pw, tty=True)
        + ["sleep %d" % seconds],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True)


def end_session(proc):
    if proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except OSError:
            pass
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        pass


def main():
    print("== Phase 0 base test ==  game=%s lab=%s levels=%d"
          % (GAME, LAB, len(LEVELS)), flush=True)

    # --- 1. dashboard is up -------------------------------------------------
    def fetch_home():
        with urllib.request.urlopen(API + "/", timeout=5) as r:
            body = r.read().decode("utf-8", "replace")
            return body if r.status == 200 else None
    html = wait_until(fetch_home, 90)
    check("dashboard GET / answers within 90s", bool(html))
    if not html:
        return finish()
    check("dashboard shows welcome screen", "Welcome to Nimbus Corp" in html)

    # --- 2. sane initial state ---------------------------------------------
    wait_until(lambda: state().get("connected") is None, 30)
    s = state()
    check("initial: nobody connected", s.get("connected") is None,
          repr(s.get("connected")))
    check("initial: reached == 0 (progress truncated by runner)",
          s.get("reached") == 0, repr(s.get("reached")))
    check("initial: total matches levels.yaml",
          s.get("total") == len(LEVELS),
          "%r != %d" % (s.get("total"), len(LEVELS)))
    check("initial: public start password is level0's",
          s.get("start_password") == SECRETS[0])
    check("initial: only level 0 is open",
          all(l["status"] == ("open" if l["n"] == 0 else "locked")
              for l in s["levels"]), json.dumps(s["levels"]))

    data, code = get("/api/level?n=1")
    check("locked level /api/level?n=1 -> 403", code == 403, "got %s" % code)
    data, code = get("/api/level?n=0")
    check("open level /api/level?n=0 -> 200",
          code == 200 and data is not None
          and data.get("title") == LEVELS[0]["title"].strip(),
          "got %s %r" % (code, data))

    # --- 3. lab login (intern / sudo) ---------------------------------------
    rc, out, err = ssh_run(LAB, "intern", "learn", "whoami")
    check("lab: ssh intern@lab works", rc == 0 and out == "intern",
          "rc=%s out=%r err=%r" % (rc, out, err))
    rc, out, err = ssh_run(LAB, "intern", "learn",
                           "echo learn | sudo -kS id -u 2>/dev/null")
    check("lab: intern can sudo (real password)",
          rc == 0 and out.splitlines()[-1:] == ["0"],
          "rc=%s out=%r err=%r" % (rc, out, err))

    # --- 4. game: dashboard follows level0 ----------------------------------
    proc = spawn_session(GAME, "level0", SECRETS[0], 12)
    try:
        got = wait_until(lambda: state().get("connected") == 0, 40)
        check("game: dashboard follows level0 SSH session", got is not None,
              "connected never became 0 within 40s")
        if got:
            data, code = get("/api/level?n=1")
            check("while connected: level 1 still 403", code == 403,
                  "got %s" % code)
            # POST /api/hint {n:0}: 200 (revealed/paid) or 409 (low_score).
            req = urllib.request.Request(
                API + "/api/hint",
                data=json.dumps({"n": 0}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST")
            try:
                with urllib.request.urlopen(req, timeout=5) as resp:
                    hint_data = json.loads(resp.read().decode())
                    code = resp.status
            except urllib.error.HTTPError as e:
                hint_data = None
                code = e.code
            check("while connected: POST /api/hint {n:0} -> 200 or 409",
                  code in (200, 409),
                  "got %s %r" % (code, hint_data))
        gone = wait_until(lambda: state().get("connected") is None, 40)
        check("after level0 logout: connected back to null", gone is not None,
              "session never disappeared within 40s")
    finally:
        end_session(proc)

    # --- 5. game: PAM -> progress -> API chain via level1 -------------------
    # reached can only become 1 if mark.sh really appended level1 to the
    # root-owned progress file during the sshd login.
    proc = spawn_session(GAME, "level1", SECRETS[1], 12)
    try:
        got = wait_until(lambda: state().get("connected") == 1, 40)
        check("game: dashboard follows level1 SSH session", got is not None,
              "connected never became 1 within 40s")
        if got:
            s = state()
            check("PAM chain: reached advanced to 1 on level1 login",
                  s.get("reached") == 1, repr(s.get("reached")))
            data, code = get("/api/level?n=1")
            check("level1 now readable via API",
                  code == 200 and data is not None
                  and data.get("title") == LEVELS[1]["title"].strip(),
                  "got %s %r" % (code, data))
            data, code = get("/api/level?n=2")
            check("level 2 still locked -> 403", code == 403, "got %s" % code)
        gone = wait_until(lambda: state().get("connected") is None, 40)
        check("after level1 logout: connected back to null", gone is not None)
        check("after level1 logout: reached stays 1 (persisted)",
              state().get("reached") == 1)
    finally:
        end_session(proc)

    return finish()


def finish():
    print("-" * 60, flush=True)
    if failures:
        print("FAILED %d check(s):" % len(failures), flush=True)
        for f in failures:
            print("  - " + f, flush=True)
        return 1
    print("ALL CHECKS PASSED", flush=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("[FAIL] unhandled error: %r" % (e,), flush=True)
        sys.exit(1)
