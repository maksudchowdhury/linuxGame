#!/usr/bin/env python3
"""Solvability harness (host world). docs/TEST_PLAN.md section 1.2.

Proves AUTHORING section 3 for all 48 chain levels + 5 labs against the BUILT
image, reusing the authoritative build-time gate (_buildcheck.py, the same
script the Dockerfile `validator` stage runs). Steps:
  1. static phase-gate sanity: every interactive/lab `requires` is a valid,
     in-range chain level id (out-of-range = unsatisfiable gate = FAIL).
  2. build the `validator` target (cheap; layers cached) so homes are baked from
     the CURRENT levels/secrets/solutions.
  3. run _buildcheck.py in a throwaway container from the validator image and
     assert every unit passes (48 chain + 5 lab = 53).

Run from the repo root: python linuxgame/tests/solve_all.py
"""
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common as C  # noqa: E402

GRADED = {"task", "boss", "capstone"}


def check_static_gates():
    doc = C.load_levels()
    levels = doc.get("levels") or []
    n = len(levels)
    ids = {lv.get("id") for lv in levels}
    bad = []
    for it in doc.get("interactive") or []:
        req = it.get("requires")
        if not (isinstance(req, int) and 0 <= req < n and req in ids):
            bad.append("interactive %s requires=%r" % (it.get("id"), req))
    for lab in doc.get("labs") or []:
        req = lab.get("requires")
        if not (isinstance(req, int) and 0 <= req < n and req in ids):
            bad.append("lab %s requires=%r" % (lab.get("id"), req))
    C.check("gates: every interactive/lab requires an in-range chain level",
            not bad, "; ".join(bad[:5]))
    # graded levels must declare a verify script (AUTHORING section 3).
    noverify = [lv.get("id") for lv in levels
                if lv.get("type") in GRADED and not (lv.get("verify") or "").strip()]
    C.check("gates: every graded level has a verify script", not noverify,
            "missing verify for %s" % noverify[:6])


def run_buildcheck():
    # Build the validator with --no-cache so setup + _buildcheck re-run fresh in
    # ONE RUN (the authoritative gate). The committed validator image alone is
    # NOT a valid re-run target: buildcheck's solution outputs are baked into the
    # layer, so a re-run would see pristine verify already passing. We therefore
    # parse the BUILD output for the buildcheck report.
    rc, out, err = C.docker(
        ["build", "--no-cache", "--target", "validator", "-t", "nimbus-validator",
         C.LINUXGAME_DIR], timeout=900)
    text = (out or "") + ("\n" + (err or "") if err else "")
    pass_lines = re.findall(r"^\s*#\d+\s+[\d.]+\s+PASS ", text, re.M) or \
        re.findall(r"\bPASS L\d+\b|\bPASS LAB ", text)
    fail_lines = re.findall(r"\bFAIL (?:L\d+|LAB \S+):.*", text)
    ok_summary = "BUILDCHECK OK: 53/53" in text.replace("  ", " ")
    n_pass = len(re.findall(r"\bPASS (?:L\d+|LAB \S+)\b", text))
    C.check("validator build exit 0", rc == 0, (err or out)[-300:])
    C.check("buildcheck: no unit failed", not fail_lines,
            "fails: %s" % fail_lines[:5])
    C.check("buildcheck: BUILDCHECK OK 53/53 in build output", ok_summary,
            "summary missing")
    C.check("buildcheck: all 53 units passed", n_pass == 53, "passed %d" % n_pass)
    return rc == 0 and not fail_lines and ok_summary and n_pass == 53


def main():
    check_static_gates()
    run_buildcheck()
    C.finish("solve_all")


if __name__ == "__main__":
    main()
