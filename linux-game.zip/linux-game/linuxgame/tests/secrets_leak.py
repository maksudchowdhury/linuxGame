#!/usr/bin/env python3
"""Secrets-leak hunt (host world). docs/TEST_PLAN.md section 1.4 (+ the §3 item-3
"runtime secrets delivery" decision).

DECISION (Commander): in-image allowlist for the server-internal secrets file.
The server needs every password to grade over local ssh, so game/secrets.yaml is
baked at /opt/game/secrets.yaml and locked to 750 root:gameserver. That file is
the ONE legitimate in-image home of the passwords. The guardrail that matters is
LEARNER-facing: a level user must never be able to read a password, and no
password may ever surface in HTTP/API/HTML/logs. This suite proves exactly that:
  1. learner (level0) cannot read /opt/game/secrets.yaml (lockdown)
  2. no secret appears in any file a level user CAN read
  3. HTTP crawl over every endpoint incl. error + fuzz paths: no secret except begin
  4. runtime traces: /proc cmdline, docker logs, scores.json
  5. image config (docker inspect env/cmd, history) carries no secret
  6. GET /api/hint no longer returns a hint (legacy route removed)

Run from the repo root with the stack up: python linuxgame/tests/secrets_leak.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common as C  # noqa: E402

SECRETS_FILE = "/opt/game/secrets.yaml"


def secret_values():
    secrets = C.load_secrets()
    return {k: v for k, v in secrets.items() if k != 0 and v and len(v) >= 6}


def stage_patterns(container, values, path="/tmp/pw.patterns"):
    C.exec_sh(container, "printf '%s\\n' %s > %s" % (
        "%s", " ".join("'%s'" % v.replace("'", "'\\''") for v in values), path),
        timeout=30)
    return path


def check_lockdown(secrets):
    # The allowlisted secrets file must be owned root:gameserver and NOT
    # world-readable (group-readable so the gameserver process can grade).
    rc, out, _ = C.exec_sh(C.GAME_CONTAINER,
                           f"stat -c '%a %U %G' {SECRETS_FILE}", timeout=20)
    parts = (out or "").strip().split()
    mode = parts[0] if parts else ""
    owner_ok = len(parts) >= 3 and parts[1] == "root" and parts[2] == "gameserver"
    # stat -c '%a' yields octal (e.g. 640); the 3rd digit is "other" perms.
    not_world = len(mode) == 3 and mode[2] == "0"
    C.check("lockdown: %s root:gameserver, not world-readable" % SECRETS_FILE,
            rc == 0 and owner_ok and not_world, "got %r" % (out or "").strip())
    # level0 must NOT be able to read it.
    rc, out, err = C.exec_sh(C.GAME_CONTAINER,
                             "runuser -u level0 -- cat %s >/dev/null 2>&1; "
                             "echo $?" % SECRETS_FILE, timeout=20)
    denied = (out or "").strip().endswith("1")
    C.check("lockdown: level0 cannot read %s" % SECRETS_FILE, denied,
            "level0 read rc=%s" % (out or "").strip())


def check_learner_readable_fs(secrets):
    # secrets[1] (level1's password) is BY DESIGN planted in /home/level0 (the
    # L0 puzzle). Only secrets[2..] being readable by a level user = leak.
    higher = [v for k, v in secrets.items() if k >= 2]
    pfile = stage_patterns(C.GAME_CONTAINER, higher, path="/tmp/pw.higher")
    try:
        cmd = ("grep -RIl -f {p} /home /tmp /var/tmp /opt /etc 2>/dev/null "
               "| grep -v '^/tmp/pw.higher$' | sort -u || true").format(p=pfile)
        rc, out, err = C.exec_sh(C.GAME_CONTAINER, cmd, user="level0", timeout=120)
        hits = [l.strip() for l in (out or "").splitlines() if l.strip()]
        C.check("learner FS: no level>=2 secret readable by level0",
                not hits, "hits %s" % hits[:6])
    finally:
        C.exec_sh(C.GAME_CONTAINER, "rm -f %s" % pfile, timeout=15)
    # secrets[1] plant must live only under /home/level0 (design), not shared dirs.
    v1 = secrets.get(1)
    if v1:
        pfile = stage_patterns(C.GAME_CONTAINER, [v1], path="/tmp/pw.one")
        try:
            cmd = ("grep -RIl -f {p} /home /tmp /var/tmp 2>/dev/null "
                   "| grep -v '^/tmp/pw.one$' | sort -u || true").format(p=pfile)
            rc, out, err = C.exec_sh(C.GAME_CONTAINER, cmd, user="level0", timeout=90)
            files = [l.strip() for l in (out or "").splitlines() if l.strip()]
            stray = [f for f in files if not f.startswith("/home/level0/")]
            C.check("learner FS: secrets[1] plant only under /home/level0",
                    not stray, "stray %s" % stray[:6])
        finally:
            C.exec_sh(C.GAME_CONTAINER, "rm -f %s" % pfile, timeout=15)


def check_http(secrets):
    values = list(secrets.values())
    paths = ["/", "/index.html", "/api/state", "/api/commands",
             "/api/casebook", "/api/export"]
    paths += ["/api/level?n=%d" % n for n in list(range(0, 48)) + [-1, 9999]]
    paths += ["/api/level?n=abc", "/api/level?n=", "/../etc/passwd",
              "/api/level?n=../../etc/passwd", "/api/level?n=%2e%2e%2f",
              "/api/export?file=/etc/shadow"]
    leaks = []
    for p in paths:
        body, code = C.http_raw(p)
        text = body.decode("utf-8", errors="replace") if isinstance(body, bytes) else str(body)
        if "root:x:0:0" in text:
            leaks.append((p, code, "passwd-leak"))
        for v in values:
            if v in text:
                leaks.append((p, code, v[:4]))
    for ep, payload in [("/api/hint", {"n": 0}), ("/api/verify", {"n": 0}),
                        ("/api/puzzle", {"id": "match-1", "answer": {}}),
                        ("/api/labverify", {"id": "first-users"}),
                        ("/api/deduction", {"suspect": "x", "evidence": []})]:
        body, code = C.http_post(ep, payload)
        text = body if isinstance(body, str) else str(body)
        for v in values:
            if v in text:
                leaks.append((ep, code, v[:4]))
    C.check("HTTP: no secret in any endpoint body", not leaks, "leaks %s" % leaks[:6])
    data, code = C.http_json("/api/state")
    C.check("HTTP: start_password == begin",
            code == 200 and isinstance(data, dict)
            and data.get("start_password") == "begin",
            "got %r" % (data.get("start_password") if isinstance(data, dict) else data))


def check_runtime_traces(secrets):
    values = list(secrets.values())
    pfile = stage_patterns(C.GAME_CONTAINER, values)
    try:
        rc, out, _ = C.exec_sh(C.GAME_CONTAINER,
                               "grep -aHf %s /proc/[0-9]*/cmdline 2>/dev/null || true"
                               % pfile, timeout=40)
        hits = [l for l in (out or "").splitlines() if l.strip()]
        C.check("runtime: no secret in any /proc cmdline", not hits,
                "hits %s" % hits[:3])
    finally:
        C.exec_sh(C.GAME_CONTAINER, "rm -f %s" % pfile, timeout=15)
    rc, out, _ = C.docker(["logs", C.GAME_CONTAINER], timeout=30)
    leaked = [v[:4] for v in values if v in (out or "")]
    C.check("runtime: no secret in docker logs", not leaked, "logs leak %s" % leaked)
    rc, out, _ = C.exec_sh(C.GAME_CONTAINER,
                           "cat /var/lib/game/scores.json 2>/dev/null || true", timeout=20)
    leaked = [v[:4] for v in values if v in (out or "")]
    C.check("runtime: no secret in scores.json", not leaked, "scores leak %s" % leaked)


def check_image_config(secrets):
    values = list(secrets.values())
    rc, out, _ = C.docker(["inspect", "--format",
                           "{{json .Config.Env}} {{json .Config.Cmd}} "
                           "{{json .Config.Entrypoint}}", C.GAME_CONTAINER], timeout=30)
    leaked = [v[:4] for v in values if v in (out or "")]
    C.check("image config: no secret in Env/Cmd/Entrypoint", not leaked,
            "leak %s" % leaked)
    rc, out, _ = C.docker(["history", "--no-trunc", "linux-game"], timeout=60)
    leaked = [v[:4] for v in values if v in (out or "")]
    C.check("image history: no secret in layer metadata", not leaked,
            "leak %s" % leaked)


def check_hint_get_removed():
    body, code = C.http_raw("/api/hint?n=0")
    text = body.decode("utf-8", errors="replace") if isinstance(body, bytes) else str(body)
    bad = (code == 200 and '"hint"' in text)
    C.check("GET /api/hint does NOT return a hint", not bad, "rc=%s" % code)


def main():
    C.require_stack()
    secrets = secret_values()
    if len(secrets) < 2:
        print("FATAL: secrets.yaml did not yield enough passwords", flush=True)
        sys.exit(2)
    C.reset_state()
    check_lockdown(secrets)
    check_learner_readable_fs(secrets)
    check_http(secrets)
    check_runtime_traces(secrets)
    check_image_config(secrets)
    check_hint_get_removed()
    C.finish("secrets_leak")


if __name__ == "__main__":
    main()
