#!/usr/bin/env python3
"""Shared helpers for Nimbus Casebook test suites (host world unless noted).

Every suite follows the same contract (docs/TEST_PLAN.md section 1):
  - one `[PASS]/[FAIL] <name> -- <detail>` line per assertion
  - final `ALL CHECKS PASSED` or `FAILED n check(s):` list
  - exit 0 iff no failures, else 1

Host world = PowerShell 7 + python + pyyaml + docker CLI. It has NO sshpass, so
every password-SSH assertion must run inside the tester container. Host suites
drive docker and HTTP; they never need a pty.
"""
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

import yaml

# Repo root (…/linuxgame/tests/_common.py -> repo root is two levels up).
TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
LINUXGAME_DIR = os.path.dirname(TESTS_DIR)
ROOT = os.path.dirname(LINUXGAME_DIR)
GAME_DIR = os.path.join(LINUXGAME_DIR, "game")
COMPOSE_FILE = os.path.join(LINUXGAME_DIR, "docker-compose.yml")

API = "http://127.0.0.1:9021"
GAME_CONTAINER = "linuxgame"
LAB_CONTAINER = "linuxlab"

failures = []


def check(name, cond, detail=""):
    """Record one assertion; print [PASS]/[FAIL] line."""
    ok = bool(cond)
    print("[%s] %s%s" % ("PASS" if ok else "FAIL", name,
                         (" -- " + detail) if (detail and not ok) else ""),
          flush=True)
    if not ok:
        failures.append(name + ((": " + detail) if detail else ""))
    return ok


def finish(suite):
    """Print summary and exit with the suite's status."""
    if failures:
        print("FAILED %d check(s) in %s:" % (len(failures), suite))
        for f in failures:
            print("  - %s" % f)
        sys.exit(1)
    print("ALL CHECKS PASSED (%s)" % suite)
    sys.exit(0)


def load_yaml(path):
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def load_levels():
    return load_yaml(os.path.join(GAME_DIR, "levels.yaml"))


def load_secrets():
    doc = load_yaml(os.path.join(GAME_DIR, "secrets.yaml")) or {}
    return {int(k): str(v) for k, v in (doc.get("passwords") or {}).items()}


def load_solutionbook():
    path = os.path.join(ROOT, "linuxgame", "solutions", "solutionbook.yaml")
    return load_yaml(path) or {}


# ---------------------------------------------------------------- HTTP ----
def http_json(path, timeout=8):
    """GET a JSON endpoint; returns (data_or_None, status_or_None)."""
    try:
        with urllib.request.urlopen(API + path, timeout=timeout) as r:
            return json.loads(r.read().decode()), r.status
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode()
        except Exception:
            body = ""
        try:
            return json.loads(body), e.code
        except Exception:
            return body, e.code
    except Exception as e:
        return None, "ERR:%s" % e


def http_raw(path, timeout=8):
    """GET returning raw bytes + status (for body-content leak checks)."""
    try:
        with urllib.request.urlopen(API + path, timeout=timeout) as r:
            return r.read(), r.status
    except urllib.error.HTTPError as e:
        return e.read(), e.code
    except Exception as e:
        return b"", "ERR:%s" % e


def http_post(path, payload, timeout=8):
    """POST JSON; returns (data_or_raw, status)."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        API + path, data=data,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode()
            try:
                return json.loads(raw), r.status
            except Exception:
                return raw, r.status
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            return json.loads(raw), e.code
        except Exception:
            return raw, e.code
    except Exception as e:
        return None, "ERR:%s" % e


def wait_api(timeout=90, interval=1.5):
    """Poll GET /api/state until 200 (used after container restart)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        data, code = http_json("/api/state", timeout=4)
        if code == 200:
            return True
        time.sleep(interval)
    return False


# ----------------------------------------------------------- docker -------
def docker(args, timeout=120, binary="docker"):
    """Run a docker CLI command; returns (rc, stdout, stderr)."""
    cmd = [binary] + list(args)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout after %ds" % timeout
    except Exception as e:
        return 1, "", str(e)


def compose(args, timeout=180, profile_tests=False):
    """Run docker compose against the project compose file."""
    cmd = ["docker", "compose", "-f", COMPOSE_FILE]
    if profile_tests:
        cmd += ["--profile", "tests"]
    return docker(cmd + list(args), timeout=timeout)


def exec_in(container, argv, user=None, timeout=60):
    """docker exec into a container with a list argv (no shell re-parse)."""
    args = ["exec"]
    if user:
        args += ["-u", user]
    args += [container] + list(argv)
    return docker(args, timeout=timeout)


def exec_sh(container, script, user=None, timeout=60):
    """Run a shell script inside a container via bash -lc (list argv)."""
    return exec_in(container, ["bash", "-lc", script], user=user, timeout=timeout)


def reset_state():
    """Truncate progress + drop scores so suites start from a clean baseline."""
    exec_in(GAME_CONTAINER, ["bash", "-c",
                             "truncate -s 0 /var/lib/game/progress; "
                             "rm -f /var/lib/game/scores.json"])
    # give the server a beat to re-read on next call
    time.sleep(1)


def container_running(name):
    rc, out, _ = docker(["inspect", "-f", "{{.State.Running}}", name], timeout=30)
    return rc == 0 and out.strip() == "true"


def require_stack():
    """Fail fast with a clear message if game/lab containers are not up."""
    for c in (GAME_CONTAINER, LAB_CONTAINER):
        if not container_running(c):
            print("FATAL: container %s is not running "
                  "(run: docker compose up -d)" % c, flush=True)
            sys.exit(2)
