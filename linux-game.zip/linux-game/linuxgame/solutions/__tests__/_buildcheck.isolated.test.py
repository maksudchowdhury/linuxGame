#!/usr/bin/env python3
"""ISOLATED Unit Test for linuxgame/solutions/_buildcheck.py

Target: E:/linux-game/linuxgame/solutions/_buildcheck.py
Session: ses_m3c

WARNING: THIS FILE IS DELETED AFTER THE TEST PASSES.
Test code preserved in: .opencode/unit-tests/

Isolation: imports ONLY _buildcheck; run_script (runuser/subprocess) is
monkeypatched so no process is spawned and no filesystem state is touched.
All fixtures are in-memory dicts shaped like the real YAML documents.
"""
import importlib.util
import unittest
from pathlib import Path

SOLUTIONS_DIR = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location(
    "_buildcheck", SOLUTIONS_DIR / "_buildcheck.py")
bc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bc)


class Proc:
    """Stand-in for subprocess.CompletedProcess."""

    def __init__(self, rc, out="", err=""):
        self.returncode = rc
        self.stdout = out
        self.stderr = err


def make_runner(wrong_pw=(), solution_rc=None, verify_always=()):
    """Fake run_script: verifies fail until their user 'solved'; solve-* runs."""
    solved = set()
    calls = []

    def fake(script, user, home, env_pairs=()):
        env = dict(env_pairs)
        calls.append((script, user, home, env))
        if script.startswith("solve-") or script == "lab-solve":
            key = script[6:] if script.startswith("solve-") else "lab"
            if solution_rc and key in solution_rc:
                return Proc(1, "", "boom")
            solved.add(user)
            pw = "WRONG" if key in wrong_pw else env.get("NEXT_PW", "")
            return Proc(0, "work done\n%s\n" % pw)
        if user in verify_always:
            return Proc(0, "", "")
        return Proc(0 if user in solved else 1, "", "")

    fake.calls = calls
    return fake


def chain_fixture():
    levels = [
        {"id": 0, "type": "flag", "setup": "x"},                       # no verify
        {"id": 1, "type": "task", "setup": "x", "verify": "verify"},   # graded
        {"id": 2, "type": "capstone", "setup": "x", "verify": "verify"},
    ]
    secrets = {0: "begin", 1: "pw1", 2: "pw2"}
    book = {"version": 1, "solutions": [
        {"id": 0, "solution": "solve-0"},
        {"id": 1, "solution": "solve-1"},
        {"id": 2, "solution": "solve-2"},
    ], "labs": []}
    return levels, secrets, book


def run_chain(fake, mutate=None):
    levels, secrets, book = chain_fixture()
    if mutate:
        mutate(levels, secrets, book)
    old = bc.run_script
    bc.run_script = fake
    try:
        return bc.check_chain(levels, secrets, book)
    finally:
        bc.run_script = old


class LastNonempty(unittest.TestCase):
    def test_takes_last_non_blank_line(self):
        self.assertEqual(bc.last_nonempty("a\nb\n\n"), "b")

    def test_all_blank_is_empty(self):
        self.assertEqual(bc.last_nonempty("  \n\n"), "")

    def test_none_is_empty(self):
        self.assertEqual(bc.last_nonempty(None), "")


class ChainChecks(unittest.TestCase):
    def test_happy_path_all_pass(self):
        results = run_chain(make_runner())
        self.assertEqual([p for _, p in results if p], [])
        self.assertEqual(len(results), 3)

    def test_wrong_last_line_fails(self):
        results = run_chain(make_runner(wrong_pw={"0"}))
        problems = dict(results)["L00"]
        self.assertTrue(any("last line" in p for p in problems), problems)

    def test_pristine_verify_passing_fails(self):
        results = run_chain(make_runner(verify_always={"level1"}))
        problems = dict(results)["L01"]
        self.assertTrue(any("pristine" in p for p in problems), problems)

    def test_solution_error_fails(self):
        results = run_chain(make_runner(solution_rc={"1"}))
        problems = dict(results)["L01"]
        self.assertTrue(any("solution rc=1" in p for p in problems), problems)

    def test_missing_solution_entry_fails(self):
        def drop(levels, secrets, book):
            book["solutions"] = [s for s in book["solutions"] if s["id"] != 1]
        results = run_chain(make_runner(), drop)
        problems = dict(results)["L01"]
        self.assertTrue(any("no solution" in p for p in problems), problems)

    def test_graded_without_verify_fails(self):
        def strip(levels, secrets, book):
            levels[1].pop("verify")
        results = run_chain(make_runner(), strip)
        problems = dict(results)["L01"]
        self.assertTrue(any("no verify" in p for p in problems), problems)

    def test_missing_next_password_fails(self):
        def drop_secret(levels, secrets, book):
            secrets.pop(2)
        results = run_chain(make_runner(), drop_secret)
        problems = dict(results)["L01"]
        self.assertTrue(any("no password for level 2" in p for p in problems),
                        problems)

    def test_capstone_needs_no_next_password(self):
        def drop_secret(levels, secrets, book):
            secrets.pop(2)
        results = run_chain(make_runner(), drop_secret)
        self.assertEqual(dict(results)["L02"], [])

    def test_solution_env_carries_next_pw_and_home(self):
        fake = make_runner()
        run_chain(fake)
        solve0 = [c for c in fake.calls if c[0] == "solve-0"][0]
        self.assertEqual(solve0[3].get("NEXT_PW"), "pw1")
        self.assertEqual(solve0[2], "/home/level0")
        self.assertEqual(solve0[1], "level0")


class LabChecks(unittest.TestCase):
    def lab_fixture(self):
        labs = [{"id": "demo-lab", "setup": "x", "verify": "verify"}]
        book = {"version": 1, "solutions": [],
                "labs": [{"id": "demo-lab", "solution": "lab-solve"}]}
        return labs, book

    def run_labs(self, fake, mutate=None):
        labs, book = self.lab_fixture()
        if mutate:
            mutate(labs, book)
        old = bc.run_script
        bc.run_script = fake
        try:
            return bc.check_labs(labs, book)
        finally:
            bc.run_script = old

    def test_happy_path_passes(self):
        results = self.run_labs(make_runner())
        self.assertEqual([p for _, p in results if p], [])
        self.assertEqual(len(results), 1)

    def test_pristine_verify_passing_fails(self):
        results = self.run_labs(make_runner(verify_always={"intern"}))
        problems = dict(results)["LAB demo-lab"]
        self.assertTrue(any("pristine" in p for p in problems), problems)

    def test_solution_error_fails(self):
        results = self.run_labs(make_runner(solution_rc={"lab"}))
        problems = dict(results)["LAB demo-lab"]
        self.assertTrue(any("solution rc=1" in p for p in problems), problems)

    def test_missing_lab_solution_fails(self):
        def drop(labs, book):
            book["labs"] = []
        results = self.run_labs(make_runner(), drop)
        problems = dict(results)["LAB demo-lab"]
        self.assertTrue(any("no lab solution" in p for p in problems), problems)

    def test_lab_runs_as_intern_in_home(self):
        fake = make_runner()
        self.run_labs(fake)
        solve = [c for c in fake.calls if c[0] == "lab-solve"][0]
        self.assertEqual(solve[1], "intern")
        self.assertEqual(solve[2], "/home/intern")
        self.assertNotIn("NEXT_PW", solve[3])  # labs never touch passwords


if __name__ == "__main__":
    unittest.main(verbosity=2)
