#!/usr/bin/env python3
"""AUTHORING.md section 3 build-time solvability gate (validator stage ONLY).

Runs inside the Docker `validator` stage after `setup.py --target game|lab`
has baked every home directory. It is never copied into a runtime image.

Contract enforced per unit (AUTHORING section 3):

  chain level i   pristine verify (if present) must FAIL
               -> run `solution` as levelN, cwd=/home/levelN, env NEXT_PW
               -> last non-empty stdout line == secrets[i+1]
                  (skipped on the final capstone: no next password)
               -> verify (if present) must PASS
  lab             pristine verify must FAIL -> run lab solution as intern
               -> verify must PASS   (no password output requirement)

Output: one `PASS <tag>` / `FAIL <tag>: problems` line per unit plus a
summary. Exit code 0 only when every unit passed.
"""
import os
import subprocess
import sys
import tempfile

import yaml

GAME_DIR = "/opt/game"
SOLUTIONS_DIR = "/opt/solutions"
GRADED_TYPES = {"task", "boss", "capstone"}
RUN_TIMEOUT = 120


def load_yaml(path):
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def last_nonempty(text):
    """Last line of `text`, ignoring trailing blank/whitespace-only lines."""
    for line in reversed((text or "").splitlines()):
        if line.strip():
            return line.rstrip("\r")
    return ""


def tail(text, limit=300):
    text = (text or "").strip()
    return text[-limit:] if len(text) > limit else text


def run_script(script, user, home, env_pairs=()):
    """Run `script` as `user`, cwd=`home`, extra env as (k, v) pairs.

    The script is written to a world-readable temp file and invoked through
    `runuser ... env K=V bash file` so no value ever touches an argv that a
    shell would re-parse. Returns a CompletedProcess (rc 124 on timeout).
    """
    fd, path = tempfile.mkstemp(prefix="bc_", suffix=".sh")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(script)
        os.chmod(path, 0o644)
        argv = ["runuser", "-u", user, "--", "env",
                "HOME=%s" % home, "USER=%s" % user, "LOGNAME=%s" % user]
        argv += ["%s=%s" % (k, v) for k, v in env_pairs]
        argv += ["bash", path]
        try:
            return subprocess.run(argv, cwd=home, capture_output=True,
                                  text=True, timeout=RUN_TIMEOUT)
        except subprocess.TimeoutExpired:
            return subprocess.CompletedProcess(
                argv, 124, "", "timeout after %ds" % RUN_TIMEOUT)
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def _solution_map(book, key):
    return {e.get("id"): (e.get("solution") or "")
            for e in (book or {}).get(key) or []}


def check_chain(levels, secrets, book):
    """AUTHORING section 3 chain contract. Returns [(tag, problems), ...]."""
    sols = _solution_map(book, "solutions")
    results = []
    for i, lv in enumerate(levels):
        tag = "L%02d" % i
        problems = []
        user, home = "level%d" % i, "/home/level%d" % i
        verify = (lv.get("verify") or "").strip()
        sol = sols.get(i)
        is_last = i == len(levels) - 1

        if lv.get("type") in GRADED_TYPES and not verify:
            problems.append("graded type but no verify script")
        if sol is None:
            problems.append("no solution entry in solutionbook")
            sol = ""

        next_pw = secrets.get(i + 1)
        if not is_last and next_pw is None:
            problems.append("secrets.yaml has no password for level %d" % (i + 1))
            next_pw = ""

        if verify:
            proc = run_script(verify, user, home)
            if proc.returncode == 0:
                problems.append("pristine verify PASSED (must fail first)")
        if sol:
            proc = run_script(sol, user, home, [("NEXT_PW", next_pw or "")])
            if proc.returncode != 0:
                problems.append("solution rc=%s: %s"
                                % (proc.returncode, tail(proc.stderr)))
            elif not is_last and last_nonempty(proc.stdout) != next_pw:
                problems.append("last line %r != next password"
                                % last_nonempty(proc.stdout))
        if verify and sol:
            proc = run_script(verify, user, home)
            if proc.returncode != 0:
                problems.append("verify still fails after solution (rc=%s): %s"
                                % (proc.returncode, tail(proc.stderr)))
        results.append((tag, problems))
    return results


def check_labs(labs, book):
    """AUTHORING section 3 lab contract. Returns [(tag, problems), ...]."""
    sols = _solution_map(book, "labs")
    results = []
    for lab in labs:
        lid = str(lab.get("id", "?"))
        tag = "LAB %s" % lid
        problems = []
        verify = (lab.get("verify") or "").strip()
        sol = sols.get(lab.get("id"))

        if not verify:
            problems.append("lab has no verify script")
        if sol is None:
            problems.append("no lab solution entry in solutionbook")
            sol = ""

        if verify:
            proc = run_script(verify, "intern", "/home/intern")
            if proc.returncode == 0:
                problems.append("pristine verify PASSED (must fail first)")
        if sol:
            proc = run_script(sol, "intern", "/home/intern")
            if proc.returncode != 0:
                problems.append("solution rc=%s: %s"
                                % (proc.returncode, tail(proc.stderr)))
        if verify and sol:
            proc = run_script(verify, "intern", "/home/intern")
            if proc.returncode != 0:
                problems.append("verify still fails after solution (rc=%s): %s"
                                % (proc.returncode, tail(proc.stderr)))
        results.append((tag, problems))
    return results


def main(argv=None):
    levels_doc = load_yaml(os.path.join(GAME_DIR, "levels.yaml")) or {}
    secrets_doc = load_yaml(os.path.join(GAME_DIR, "secrets.yaml")) or {}
    book = load_yaml(os.path.join(SOLUTIONS_DIR, "solutionbook.yaml")) or {}
    levels = levels_doc.get("levels") or []
    labs = levels_doc.get("labs") or []
    secrets = {int(k): str(v)
               for k, v in (secrets_doc.get("passwords") or {}).items()}

    results = check_chain(levels, secrets, book) + check_labs(labs, book)
    if not results:
        print("BUILDCHECK FAILED: no levels/labs loaded", flush=True)
        return 1

    failed = 0
    for tag, problems in results:
        if problems:
            failed += 1
            print("FAIL %s: %s" % (tag, "; ".join(problems)), flush=True)
        else:
            print("PASS %s" % tag, flush=True)
    passed = len(results) - failed
    print("BUILDCHECK %s: %d/%d passed"
          % ("OK" if failed == 0 else "FAILED", passed, len(results)),
          flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
