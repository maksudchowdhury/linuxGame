#!/usr/bin/env python3
"""Repro of the ORIGINAL SYNC-10 deadlock, proving the new run_setup_script
is deadlock-proof.

The original setup.py used subprocess.run(capture_output=True) with no
timeout. A setup script that backgrounds a fifo writer with no reader would
block on open() forever AND hold the captured stdout/stderr pipes, so
subprocess.run never returned -> docker build hung.

The new run_setup_script routes child stdout/stderr to temp FILES (not OS
pipes), sets stdin=DEVNULL, and enforces a hard timeout with process-group
kill. This test backgrounds exactly such a writer and asserts we return
cleanly (rc 0) rather than hanging.
"""
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import setup as S  # noqa: E402


def test_backgrounded_fifo_writer_does_not_deadlock():
    # Backgrounded fifo writer, no reader: old code hung here forever.
    script = ('mkfifo tunnel; chmod 666 tunnel; '
              '( echo "$NEXT_PW" > tunnel & ); echo staged')
    home = tempfile.mkdtemp(prefix="deadlock_")
    env = dict(os.environ)
    env["NEXT_PW"] = "TESTPW24X"
    env["LEVEL_USER"] = "level24"
    env["HOME"] = home
    t0 = time.time()
    S.run_setup_script(script, home, env, "L24-repro", ["TESTPW24X"])
    elapsed = time.time() - t0
    assert elapsed < 10, "run_setup_script took %.1fs (should return near-instantly)" % elapsed
    print("OK: returned clean in %.1fs (no deadlock)" % elapsed)


def test_timeout_kills_runaway_setup():
    # A setup that sleeps forever must be killed by SETUP_TIMEOUT, not hang.
    old = os.environ.get("SETUP_TIMEOUT")
    os.environ["SETUP_TIMEOUT"] = "2"
    try:
        home = tempfile.mkdtemp(prefix="timeout_")
        env = dict(os.environ)
        env["NEXT_PW"] = "X"
        t0 = time.time()
        try:
            S.run_setup_script("sleep 60", home, env, "runaway", ["X"])
            raise AssertionError("runaway setup should have been killed")
        except SystemExit:
            pass
        elapsed = time.time() - t0
        assert elapsed < 15, "timeout kill took %.1fs (should be ~2s)" % elapsed
        print("OK: runaway killed in %.1fs" % elapsed)
    finally:
        if old is None:
            os.environ.pop("SETUP_TIMEOUT", None)
        else:
            os.environ["SETUP_TIMEOUT"] = old


if __name__ == "__main__":
    test_backgrounded_fifo_writer_does_not_deadlock()
    test_timeout_kills_runaway_setup()
    print("PASS setup.isolated (2/2)")
