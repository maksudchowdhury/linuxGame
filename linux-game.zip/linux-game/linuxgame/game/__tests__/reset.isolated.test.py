#!/usr/bin/env python3
"""Isolated tests for setup.py --level (per-level reset).

Host-safe: exercises wipe_home on a tempdir and the CLI validation paths
(--level with lab target, out-of-range --level). The full reset flow
(needs root + real level users) is covered by the container smoke gate.
"""
import contextlib
import io
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import setup as S  # noqa: E402

# Host checkout layout vs in-container mount layout
_CANDIDATES = [
    os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..",
                                 "linuxgame", "game", "levels.yaml")),
    "/opt/game/levels.yaml",
]
LEVELS_PATH = next((p for p in _CANDIDATES if os.path.isfile(p)),
                   _CANDIDATES[0])


def expect_die(fn, needle, label):
    captured = io.StringIO()
    try:
        with contextlib.redirect_stderr(captured):
            fn()
    except SystemExit as exc:
        assert exc.code != 0, "%s: die() must exit non-zero" % label
        err = captured.getvalue()
        assert needle in err, (
            "%s: expected %r in die output, got: %r" % (label, needle, err))
        print("OK: %s died as expected (exit %s): %s"
              % (label, exc.code, err.strip()))
        return
    raise AssertionError("%s: expected SystemExit" % label)


def test_wipe_home_removes_contents_keeps_dir():
    if os.name == "nt":
        print("SKIP: wipe content test (Windows host: WSL interop drops "
              "argv/env; container smoke gate covers it authoritatively)")
        return
    home = tempfile.mkdtemp(prefix="wipe_")
    os.mkdir(os.path.join(home, "dir"))
    open(os.path.join(home, "dir", "x"), "w").close()
    open(os.path.join(home, ".dotfile"), "w").close()
    open(os.path.join(home, "plain.txt"), "w").close()
    try:
        os.symlink("/nonexistent", os.path.join(home, "badlink"))
        link_case = True
    except OSError:
        link_case = False  # Windows without developer mode can't symlink
    S.wipe_home(home, "wipe-test", [])
    assert os.path.isdir(home), "home dir itself must survive the wipe"
    leftover = os.listdir(home)
    assert leftover == [], "wipe left behind: %r" % leftover
    print("OK: wipe_home removed contents+dotfiles%s, kept the dir"
          % ("+links" if link_case else " (link case skipped)"))


def test_level_with_lab_target_dies():
    expect_die(lambda: S.main(["--target", "lab", "--level", "0"]),
               "--target game only", "--level with --target lab")


def test_level_out_of_range_dies():
    os.environ["LEVELS_PATH"] = LEVELS_PATH
    try:
        expect_die(lambda: S.main(["--target", "game", "--level", "999"]),
                   "out of range (0..47)", "--level 999")
    finally:
        os.environ.pop("LEVELS_PATH", None)


def test_negative_level_dies():
    os.environ["LEVELS_PATH"] = LEVELS_PATH
    try:
        expect_die(lambda: S.main(["--target", "game", "--level", "-1"]),
                   "out of range (0..47)", "--level -1")
    finally:
        os.environ.pop("LEVELS_PATH", None)


if __name__ == "__main__":
    test_wipe_home_removes_contents_keeps_dir()
    test_level_with_lab_target_dies()
    test_level_out_of_range_dies()
    test_negative_level_dies()
    print("PASS reset.isolated (4/4)")
