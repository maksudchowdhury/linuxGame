#!/usr/bin/env python3
"""Build-time provisioning for Nimbus Casebook images (never learner runtime).

  python3 setup.py --target game   (default) create levelN accounts, set their
      passwords from secrets.yaml (passwords map, id 0 = begin), run each
      level's `setup` script under `bash -e -c` with cwd /home/levelN and env
      NEXT_PW/LEVEL_ID/LEVEL_USER/HOME, then lock each home down
      (chown -R levelN:levelN, chmod -R u+rwX,go-rwx) and create /var/lib/game
      (the Dockerfile tightens its permissions afterwards).
  python3 setup.py --target lab    run each lab's `setup` script (those that
      have one) under `bash -e -c` with cwd /home/intern and env
      NEXT_PW="", LEVEL_ID=<lab id>, LEVEL_USER=intern, then chown/chmod
      /home/intern. Idempotent.
  python3 setup.py --level N       reset ONE level: wipe /home/levelN's
      contents (incl. staged keys and learner junk; the home dir itself
      stays), re-run that level's `setup` script, restore chown/chmod and
      the password from secrets.yaml. Progress and scores are untouched
      (operator action, same trust level as `docker compose down`).

Overrides: LEVELS_PATH and SECREATIONS_PATH (alias SECRETS_PATH) environment
variables; defaults are the files beside this script.

Secrets only ever travel on chpasswd stdin / child env: they never reach
stdout/stderr (captured output is scrubbed as defense in depth) and the
summary line carries counts only.
"""
import argparse
import os
import subprocess
import sys

import yaml

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GAME_STATE_DIR = "/var/lib/game"
INTERN_USER = "intern"
INTERN_HOME = "/home/intern"


def die(msg, code=1):
    sys.stderr.write("setup.py: %s\n" % msg)
    raise SystemExit(code)


def scrub(text, secrets):
    """Replace every secret value with a placeholder (defense in depth)."""
    for s in secrets:
        if s:
            text = text.replace(s, "[redacted]")
    return text


def load_doc(path, kind):
    if not os.path.isfile(path):
        die("%s not found at %s" % (kind, path), 2)
    with open(path, encoding="utf-8") as fh:
        doc = yaml.safe_load(fh) or {}
    if not isinstance(doc, dict):
        die("%s is not a mapping: %s" % (kind, path), 2)
    return doc


def load_levels(path):
    doc = load_doc(path, "levels.yaml")
    levels = doc.get("levels")
    if not isinstance(levels, list) or not levels:
        die("levels.yaml has no non-empty levels list: %s" % path, 2)
    return doc


def load_passwords(path):
    doc = load_doc(path, "secrets.yaml")
    pw = doc.get("passwords")
    if not isinstance(pw, dict) or not pw:
        die("secrets.yaml has no passwords mapping: %s" % path, 2)
    return {int(k): str(v) for k, v in pw.items()}


def user_exists(name):
    import pwd
    try:
        pwd.getpwnam(name)
        return True
    except KeyError:
        return False


def run_checked(cmd, label, secrets, **kwargs):
    """subprocess.run(check=True); on failure report label + scrubbed stderr."""
    kwargs.setdefault("capture_output", True)
    kwargs.setdefault("text", True)
    try:
        subprocess.run(cmd, check=True, **kwargs)
    except subprocess.CalledProcessError as exc:
        sys.stderr.write("setup.py: %s failed (exit %s)\n"
                         % (label, exc.returncode))
        detail = (exc.stderr or "").strip()
        if detail:
            sys.stderr.write(scrub(detail, secrets).rstrip() + "\n")
        raise SystemExit(1)


def run_setup_script(script, cwd, env, label, secrets):
    """Run a setup script deadlock-proof (SYNC-10).

    Child stdout/stderr go to temp FILES, never OS pipes: a setup that
    backgrounds a blocked fifo writer can therefore never pin the capture
    (the writer's fds are /dev/null or the fifo itself, not our pipes).
    stdin is DEVNULL, hard timeout kills the whole process group.
    """
    import signal
    import tempfile
    timeout = int(os.environ.get("SETUP_TIMEOUT", "120"))
    with tempfile.TemporaryFile("w+", encoding="utf-8",
                                errors="replace") as outfh, \
            tempfile.TemporaryFile("w+", encoding="utf-8",
                                   errors="replace") as errfh:
        proc = subprocess.Popen(
            ["bash", "-e", "-c", script], cwd=cwd, env=env,
            stdin=subprocess.DEVNULL, stdout=outfh, stderr=errfh,
            start_new_session=True)
        try:
            rc = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                proc.kill()
            proc.wait()
            sys.stderr.write("setup.py: %s setup script timed out after %ds\n"
                             % (label, timeout))
            errfh.seek(0)
            detail = scrub(errfh.read(), secrets).strip()
            if detail:
                sys.stderr.write(detail.rstrip() + "\n")
            raise SystemExit(1)
        if rc != 0:
            sys.stderr.write("setup.py: %s setup script failed (exit %s)\n"
                             % (label, rc))
            errfh.seek(0)
            detail = scrub(errfh.read(), secrets).strip()
            if detail:
                sys.stderr.write(detail.rstrip() + "\n")
            raise SystemExit(1)


def chain_passwords(levels, passwords, secrets_path):
    """Per-level password, indexed like levels (validates BEFORE any mutation)."""
    out = []
    for i, lv in enumerate(levels):
        lid = lv.get("id", i)
        if lid not in passwords:
            die("no password for level id %r in secrets.yaml (%s)"
                % (lid, secrets_path))
        out.append(str(passwords[lid]))
    return out


def wipe_home(home, label, secrets):
    """Reset one home: delete its contents, keep the directory itself.

    The directory stays so the existing uid/mode remain valid; symlinks are
    removed as links (rm -rf never follows them). Runs inside the container
    (plain Linux), where direct find argv is exact.
    """
    if not os.path.isdir(home):
        return
    run_checked(["find", home, "-mindepth", "1", "-maxdepth", "1",
                 "-exec", "rm", "-rf", "{}", "+"],
                label + " wipe", secrets)


def provision_level(i, lv, secrets, home):
    """One level's full provisioning (used by build AND --level reset)."""
    user = "level%d" % i
    label = "level %d" % i
    if not user_exists(user):
        run_checked(["useradd", "-m", "-s", "/bin/bash", user],
                    label + " useradd", secrets)
    run_checked(["chpasswd"], label + " chpasswd", secrets,
                input="%s:%s\n" % (user, secrets[i]))
    script = lv.get("setup") or ""
    ran = 0
    if script.strip():
        env = dict(os.environ)
        env["NEXT_PW"] = secrets[i + 1] if i + 1 < len(secrets) else ""
        env["LEVEL_ID"] = str(lv.get("id", i))
        env["LEVEL_USER"] = user
        env["HOME"] = home
        run_setup_script(script, home, env, label, secrets)
        ran = 1
    run_checked(["chown", "-R", "%s:%s" % (user, user), home],
                label + " chown", secrets)
    run_checked(["chmod", "-R", "u+rwX,go-rwx", home],
                label + " chmod", secrets)
    return ran


def game_target(levels, passwords, secrets_path, only=None):
    secrets = chain_passwords(levels, passwords, secrets_path)
    os.makedirs(GAME_STATE_DIR, exist_ok=True)
    ran = 0
    done = 0
    for i, lv in enumerate(levels):
        if only is not None and i != only:
            continue
        home = "/home/level%d" % i
        if only is not None:
            wipe_home(home, "level %d" % i, secrets)
        ran += provision_level(i, lv, secrets, home)
        done += 1
    if only is not None:
        print("setup.py: level %d reset (wiped, setup re-run, "
              "ownership restored)" % only)
        return
    print("setup.py: game target ok - %d accounts, %d setup scripts run, "
          "state dir ready" % (done, ran))


def lab_target(doc):
    labs = doc.get("labs") or []
    runnable = [lab for lab in labs
                if isinstance(lab, dict) and (lab.get("setup") or "").strip()]
    os.makedirs(INTERN_HOME, exist_ok=True)
    ran = 0
    for lab in runnable:
        lid = lab.get("id", "?")
        env = dict(os.environ)
        env["NEXT_PW"] = ""
        env["LEVEL_ID"] = str(lid)
        env["LEVEL_USER"] = INTERN_USER
        env["HOME"] = INTERN_HOME
        run_setup_script(lab["setup"], INTERN_HOME, env, "lab %s" % lid, [])
        ran += 1
    run_checked(["chown", "-R", "%s:%s" % (INTERN_USER, INTERN_USER),
                 INTERN_HOME], "lab chown", [])
    run_checked(["chmod", "-R", "u+rwX,go-rwx", INTERN_HOME],
                "lab chmod", [])
    print("setup.py: lab target ok - %d labs, %d setup scripts run"
          % (len(labs), ran))


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Build-time provisioning for Nimbus Casebook "
                    "(game/lab images).")
    ap.add_argument("--target", choices=("game", "lab"), default="game",
                    help="game = level accounts + chain setup (default); "
                         "lab = practice-lab setups in /home/intern")
    ap.add_argument("--level", type=int, default=None, metavar="N",
                    help="reset ONE level (game target only): wipe its home, "
                         "re-run its setup script, restore ownership; "
                         "progress and scores untouched")
    args = ap.parse_args(argv)
    levels_path = (os.environ.get("LEVELS_PATH")
                   or os.path.join(BASE_DIR, "levels.yaml"))
    secrets_path = (os.environ.get("SECREATIONS_PATH")
                    or os.environ.get("SECRETS_PATH")
                    or os.path.join(BASE_DIR, "secrets.yaml"))
    if args.level is not None and args.target != "game":
        die("--level applies to --target game only; "
            "lab reset = docker compose up -d --force-recreate lab", 2)
    doc = load_levels(levels_path)
    if args.level is not None and not 0 <= args.level < len(doc["levels"]):
        die("--level %d out of range (0..%d)"
            % (args.level, len(doc["levels"]) - 1), 2)
    if args.target == "game":
        if not os.path.isfile(secrets_path):
            die("secrets.yaml not found at %s (required for --target game)"
                % secrets_path, 2)
        passwords = load_passwords(secrets_path)
        game_target(doc["levels"], passwords, secrets_path, only=args.level)
    else:
        lab_target(doc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
