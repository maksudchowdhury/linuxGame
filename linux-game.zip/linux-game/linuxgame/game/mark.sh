#!/bin/sh
# PAM hook (pam_exec): records the level account that opened a session in the
# root-owned progress file. Runs as root during pam_open_session; always exits
# 0 because the PAM rule is "optional". POSIX sh only.
[ "${PAM_TYPE:-}" = "open_session" ] || exit 0
case "${PAM_USER:-}" in
    level[0-9]|level[0-9][0-9]|level[0-9][0-9][0-9]) ;;
    *) exit 0 ;;
esac
mkdir -p /var/lib/game 2>/dev/null || :
PROGRESS=/var/lib/game/progress
[ -f "$PROGRESS" ] || { : > "$PROGRESS" 2>/dev/null || exit 0; }
# Dedupe consecutive repeats (su/pam double-fire) so "reached" stays stable.
last=$(tail -n 1 "$PROGRESS" 2>/dev/null) || last=
[ "$last" = "$PAM_USER" ] || printf '%s\n' "$PAM_USER" >> "$PROGRESS" 2>/dev/null || :
exit 0
