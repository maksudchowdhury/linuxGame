#!/usr/bin/env python3
"""Nimbus Casebook game server — full API per docs/API_CONTRACT.md.

Stdlib + PyYAML only. Offline / localhost only. Grading happens over local
ssh with sshpass -e (password in SSHPASS env — never argv/stdout/log/HTTP).
"""
import json
import os
import re
import shlex
import subprocess
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import yaml

try:
    import pwd
except ImportError:  # host-side unit tests on non-POSIX
    pwd = None

BASE = os.path.dirname(os.path.abspath(__file__))
PROGRESS = os.environ.get("GAME_PROGRESS", "/var/lib/game/progress")
SCORES_PATH = os.environ.get("GAME_SCORES", "/var/lib/game/scores.json")
SSH_PORT = os.environ.get("SSH_PORT", "2222")   # host-facing (browser)
LAB_PORT = os.environ.get("LAB_PORT", "2223")   # host-facing (browser)
# In-container sshd listens on 22 (compose maps host 2222->22). Grading uses 22.
GAME_SSH_PORT = int(os.environ.get("GAME_SSH_PORT", "22"))
LAB_HOST = os.environ.get("LAB_HOST", "lab")
LAB_SSH_PORT = int(os.environ.get("LAB_SSH_PORT", "22"))
LAB_PASSWORD = os.environ.get("LAB_PASSWORD", "learn")
MAX_BODY = 16384
GRADED = frozenset(("task", "boss", "capstone"))

_DATA = yaml.safe_load(open(os.path.join(BASE, "levels.yaml"), encoding="utf-8"))
META = _DATA.get("meta") or {}
LEVELS = _DATA["levels"]
INTERACTIVE = _DATA.get("interactive") or []
LABS = _DATA.get("labs") or []
_SECRETS_RAW = yaml.safe_load(
    open(os.path.join(BASE, "secrets.yaml"), encoding="utf-8"))["passwords"]
SECRETS = {int(k): str(v) for k, v in _SECRETS_RAW.items()}
HINT_COSTS = [
    int((META.get("hint_costs") or {}).get("nudge", 5)),
    int((META.get("hint_costs") or {}).get("direction", 15)),
    int((META.get("hint_costs") or {}).get("near", 30)),
]
RANKS = META.get("ranks") or [
    {"name": "Constable", "at": 0},
    {"name": "Detective", "at": 800},
    {"name": "Inspector", "at": 2000},
    {"name": "Chief", "at": 3500},
]
BASE_POINTS = META.get("base_points") or {
    "flag": 100, "evidence": 120, "task": 150,
    "breather": 80, "boss": 250, "capstone": 300,
}

# Act-5 finale board (STORY_BIBLE). Required clue ids ⊆ collected to convict.
DEDUCT_SUSPECT = "Dee Vider"
DEDUCT_REQUIRED = ("c-manifest", "c-tmux", "c-authorized", "c-backup")
BOARD_SUSPECTS = [
    {"name": "Milo", "blurb": "The intern. Over-helpful, speaks in bullet points."},
    {"name": "Dee Vider", "blurb": "Night shift ops. Talks in log lines and ratios."},
    {"name": "Ada Looper", "blurb": "Automation fanatic; it loops, it loops."},
    {"name": "Cache Money", "blurb": "Retired admin who still thinks he has root."},
    {"name": "The CFO", "blurb": "Only speaks in spreadsheet cells."},
]

_PUZZLE_POINTS = {p["id"]: int(p.get("points", 50)) for p in INTERACTIVE}
_LAB_BY_ID = {lab["id"]: lab for lab in LABS}
_PUZZLE_BY_ID = {p["id"]: p for p in INTERACTIVE}
_SCORE_LOCK = threading.Lock()
_COMMANDS_CACHE = None


def level_of(name):
    m = re.fullmatch(r"level(\d+)", name)
    return int(m.group(1)) if m and int(m.group(1)) < len(LEVELS) else None


def reached():
    """Highest level ever logged into (written by the PAM hook)."""
    best = 0
    try:
        with open(PROGRESS) as fh:
            for line in fh:
                n = level_of(line.strip())
                if n is not None:
                    best = max(best, n)
    except OSError:
        pass
    return best


def connected():
    """Level of the newest live terminal session (ssh or su), or None."""
    if pwd is None:
        return None
    try:
        pids = os.listdir("/proc")
    except OSError:
        return None
    best, best_start = None, -1
    for pid in pids:
        if not pid.isdigit():
            continue
        try:
            stat = open("/proc/%s/stat" % pid).read()
            f = stat[stat.rindex(")") + 2:].split()
            tty, start = int(f[4]), int(f[19])
            if tty == 0:
                continue
            uid = next(int(l.split()[1])
                       for l in open("/proc/%s/status" % pid)
                       if l.startswith("Uid:"))
            n = level_of(pwd.getpwuid(uid).pw_name)
            if n is not None and start > best_start:
                best, best_start = n, start
        except (OSError, KeyError, ValueError, IndexError, StopIteration):
            continue
    return best


def points_of(lv):
    if lv.get("points") is not None:
        return int(lv["points"])
    return int(BASE_POINTS.get(lv.get("type"), 100))


def empty_scores():
    return {
        "total": 0,
        "by_level": {},
        "puzzles": {},
        "labs": {},
        "deductions": {},
        "hints_used": {},
        "closed": False,
    }


def load_scores():
    try:
        with open(SCORES_PATH, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            sc = empty_scores()
            for key in ("by_level", "puzzles", "labs", "deductions", "hints_used"):
                if isinstance(data.get(key), dict):
                    sc[key] = data[key]
            sc["closed"] = bool(data.get("closed"))
            sc["total"] = compute_total(sc)
            return sc
    except (OSError, ValueError, TypeError):
        pass
    return empty_scores()


def compute_total(sc):
    t = sum(int(v) for v in (sc.get("by_level") or {}).values())
    t += sum(int(v) for v in (sc.get("labs") or {}).values())
    t += sum(int(v) for v in (sc.get("deductions") or {}).values())
    for pid, v in (sc.get("puzzles") or {}).items():
        if v:
            t += _PUZZLE_POINTS.get(pid, int(v) if isinstance(v, int) else 50)
    for indices in (sc.get("hints_used") or {}).values():
        for i in indices or []:
            if 0 <= int(i) < len(HINT_COSTS):
                t -= HINT_COSTS[int(i)]
    return t


def save_scores(sc):
    sc["total"] = compute_total(sc)
    directory = os.path.dirname(SCORES_PATH) or "."
    try:
        os.makedirs(directory, exist_ok=True)
        tmp = SCORES_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(sc, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, SCORES_PATH)
    except OSError:
        pass
    return sc


def award_level_points(sc, n):
    """Non-graded levels pay out once when they become 'done' (n < reached)."""
    lv = LEVELS[n]
    if lv.get("type") in GRADED:
        return False
    key = str(n)
    if key in sc.get("by_level", {}):
        return False
    sc.setdefault("by_level", {})[key] = points_of(lv)
    return True


def reconcile(sc, r):
    changed = False
    for i in range(len(LEVELS)):
        if i < r and award_level_points(sc, i):
            changed = True
    sc["total"] = compute_total(sc)
    return changed


def rank_of(total):
    name, at = RANKS[0]["name"], int(RANKS[0]["at"])
    nxt_name, nxt_at = None, None
    for i, rk in enumerate(RANKS):
        at_i = int(rk.get("at", 0))
        if total >= at_i:
            name, at = rk["name"], at_i
            if i + 1 < len(RANKS):
                nxt_name = RANKS[i + 1]["name"]
                nxt_at = int(RANKS[i + 1].get("at", 0))
    return {"name": name, "next": nxt_name, "next_at": nxt_at}


def clue_id_of(lv):
    cb = lv.get("casebook") or []
    return cb[0]["id"] if cb else None


def collected_clues(r):
    out = []
    for i, lv in enumerate(LEVELS):
        if i > r:
            break
        for c in lv.get("casebook") or []:
            out.append({
                "id": c.get("id"),
                "act": lv.get("act"),
                "level": i,
                "title": c.get("title", ""),
                "text": c.get("text", ""),
            })
    return out


def status_of(i, r, c):
    if i == c:
        return "connected"
    if i < r:
        return "done"
    if i == r:
        return "open"
    return "locked"


def state_payload():
    c, r = connected(), reached()
    if c is not None:
        r = max(r, c)
    with _SCORE_LOCK:
        sc = load_scores()
        if reconcile(sc, r):
            save_scores(sc)
        sc = dict(sc)
    levels = [{
        "n": i,
        "act": lv.get("act"),
        "type": lv.get("type"),
        "title": lv["title"] if i <= r else "locked",
        "status": status_of(i, r, c),
        "points": points_of(lv),
    } for i, lv in enumerate(LEVELS)]
    interactive = [{
        "id": p["id"],
        "act": p.get("act"),
        "title": p.get("title", ""),
        "requires": int(p.get("requires", 0)),
        "points": _PUZZLE_POINTS.get(p["id"], 50),
        "done": bool((sc.get("puzzles") or {}).get(p["id"])),
    } for p in INTERACTIVE]
    labs = [{
        "id": lab["id"],
        "act": lab.get("act"),
        "title": lab.get("title", ""),
        "requires": int(lab.get("requires", 0)),
        "points": int(lab.get("points", 150)),
        "done": bool((sc.get("labs") or {}).get(lab["id"])),
        "verified": bool((sc.get("labs") or {}).get(lab["id"])),
    } for lab in LABS]
    return {
        "connected": c,
        "reached": r,
        "total": len(LEVELS),
        "levels": levels,
        "interactive": interactive,
        "labs": labs,
        "scores": sc,
        "rank": rank_of(sc.get("total", 0)),
        "clues": [x["id"] for x in collected_clues(r)],
        "closed": bool(sc.get("closed")),
        "ssh_port": int(SSH_PORT),
        "lab_port": int(LAB_PORT),
        "start_password": SECRETS[0],
    }


def level_payload(n, r):
    """Chain-level detail for n <= reached. Never setup/verify/password."""
    lv = LEVELS[n]
    hints = lv.get("hints") or []
    with _SCORE_LOCK:
        sc = load_scores()
        revealed = len((sc.get("hints_used") or {}).get(str(n), []) or [])
    return {
        "n": n,
        "act": lv.get("act"),
        "type": lv.get("type"),
        "title": lv["title"].strip(),
        "story": (lv.get("story") or "").strip(),
        "goal": (lv.get("goal") or "").strip(),
        "commands": lv.get("commands") or [],
        "points": points_of(lv),
        "hint_count": len(hints),
        "hints": revealed,
        "clue": clue_id_of(lv),
        "lab": lv.get("lab"),
        "next_user": ("level%d" % (n + 1)) if n + 1 < len(LEVELS) else None,
    }


def puzzle_payload(pid):
    p = _PUZZLE_BY_ID[pid]
    return {
        "id": p["id"],
        "act": p.get("act"),
        "type": "puzzle",
        "kind": p.get("kind"),
        "title": p.get("title", ""),
        "requires": int(p.get("requires", 0)),
        "points": _PUZZLE_POINTS.get(pid, 50),
        "commands": p.get("commands") or [],
        "teach": (p.get("teach") or "").strip(),
        "data": p.get("data"),
    }


def _norm(x):
    if isinstance(x, str):
        return x.strip()
    if isinstance(x, list):
        return [_norm(i) for i in x]
    if isinstance(x, dict):
        return {k: _norm(v) for k, v in sorted(x.items())}
    return x


def check_puzzle_answer(p, answer):
    kind = p.get("kind")
    expected = p.get("answer")
    if kind == "match":
        want = {(str(a).strip(), str(b).strip())
                for a, b in (expected or {}).get("pairs", [])}
        got_raw = (answer or {}).get("pairs") if isinstance(answer, dict) else None
        if not isinstance(got_raw, list):
            return False
        try:
            got = {(str(a).strip(), str(b).strip()) for a, b in got_raw}
        except (TypeError, ValueError):
            return False
        return got == want and len(got) == len(want)
    if kind == "tree":
        return _norm(answer) == _norm(expected)
    if kind in ("order", "chmod", "scenario"):
        if not isinstance(answer, list):
            return False
        return _norm(answer) == _norm(expected)
    return _norm(answer) == _norm(expected)


def _parse_option(s):
    s = str(s).strip()
    for sep in (" \u2014 ", " — "):
        if sep in s:
            flag, meaning = s.split(sep, 1)
            return {"flag": flag.strip(), "meaning": meaning.strip()}
    return {"flag": s, "meaning": ""}


def _commands_path():
    candidates = [
        os.environ.get("COMMANDS_YAML", ""),
        os.path.join(BASE, "commands.yaml"),
        os.path.join(BASE, "commands", "commands.yaml"),
        os.path.join(BASE, "..", "commands", "commands.yaml"),
        "/opt/commands/commands.yaml",
    ]
    for path in candidates:
        if path and os.path.isfile(path):
            return path
    return None


def build_acts():
    acts = {}

    def add(act, name):
        key = str(act if act is not None else 1)
        lst = acts.setdefault(key, [])
        if name and name not in lst:
            lst.append(name)

    for lv in LEVELS:
        for name in lv.get("commands") or []:
            add(lv.get("act"), name)
    for p in INTERACTIVE:
        for name in p.get("commands") or []:
            add(p.get("act"), name)
    for lab in LABS:
        for name in lab.get("commands") or []:
            add(lab.get("act"), name)
    for key in acts:
        acts[key].sort()
    return acts


def commands_payload():
    global _COMMANDS_CACHE
    if _COMMANDS_CACHE is not None:
        return _COMMANDS_CACHE
    path = _commands_path()
    cmds = []
    if path:
        try:
            raw = yaml.safe_load(open(path, encoding="utf-8")) or {}
            for c in raw.get("commands") or []:
                entry = {
                    "name": c.get("name"),
                    "kind": c.get("kind"),
                    "group": c.get("group"),
                    "summary": c.get("summary", ""),
                    "syntax": c.get("syntax", ""),
                    "options": [_parse_option(o) for o in (c.get("options") or [])],
                    "examples": c.get("examples") or [],
                    "mistakes": [str(m) for m in (c.get("mistakes") or [])],
                    "learn_more": [str(m) for m in (c.get("learn_more") or [])],
                    "runtime": c.get("runtime"),
                }
                if c.get("image_only"):
                    entry["image_only"] = True
                cmds.append(entry)
        except (OSError, TypeError, ValueError, yaml.YAMLError):
            cmds = []
    payload = {"commands": cmds, "acts": build_acts()}
    _COMMANDS_CACHE = payload
    return payload


def casebook_payload():
    r = reached()
    c, r2 = connected(), r
    if c is not None:
        r = max(r, c)
    return {
        "clues": collected_clues(r),
        "board": {
            "suspects": BOARD_SUSPECTS,
            "locked": DEDUCT_SUSPECT,
        },
    }


def ssh_grade(user, host, port, password, script, stdin_data=None, timeout=15):
    """Run verify script over ssh. Password only via SSHPASS env (sshpass -e)."""
    env = dict(os.environ)
    env["SSHPASS"] = password
    cmd = [
        "sshpass", "-e", "ssh",
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "LogLevel=ERROR",
        "-o", "ConnectTimeout=5",
        "-o", "BatchMode=no",
        "-p", str(port),
        "%s@%s" % (user, host),
        "bash -e -c %s" % shlex.quote(script),
    ]
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            env=env, input=stdin_data)
        return p.returncode, p.stdout or "", p.stderr or ""
    except (subprocess.TimeoutExpired, OSError):
        return 124, "", "grader timeout"


def feedback_from(stdout, stderr, rc):
    lines = [ln for ln in (stdout or "").splitlines() if ln.strip()]
    if lines:
        return "\n".join(lines)
    if rc != 0:
        elines = [ln for ln in (stderr or "").splitlines()
                  if ln.strip() and "password" not in ln.lower()]
        if elines:
            return "\n".join(elines[:6])
        return "The grader found problems - check your work against the goal."
    return "OK"


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def send_bytes(self, body, ctype, code=200):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except OSError:
            pass

    def js(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_bytes(body, "application/json; charset=utf-8", code)

    def err(self, code, error):
        self.js({"error": error}, code)

    def read_json(self):
        ctype = (self.headers.get("Content-Type") or "").lower()
        if "application/json" not in ctype:
            return None
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return None
        if length <= 0 or length > MAX_BODY:
            return None
        try:
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
        except (OSError, ValueError, UnicodeDecodeError):
            return None
        return data if isinstance(data, dict) else None

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        qs = parse_qs(u.query)
        try:
            if path in ("/", "/index.html"):
                fp = os.path.join(BASE, "index.html")
                with open(fp, "rb") as fh:
                    self.send_bytes(fh.read(), "text/html; charset=utf-8")
                return
            if path == "/api/state":
                self.js(state_payload())
                return
            if path == "/api/level":
                raw = (qs.get("n") or [""])[0]
                if raw in _PUZZLE_BY_ID:
                    r = reached()
                    c = connected()
                    if c is not None:
                        r = max(r, c)
                    p = _PUZZLE_BY_ID[raw]
                    if r < int(p.get("requires", 0)):
                        self.err(403, "locked")
                        return
                    self.js(puzzle_payload(raw))
                    return
                try:
                    n = int(raw)
                except ValueError:
                    self.err(400, "bad_request")
                    return
                if not 0 <= n < len(LEVELS):
                    self.err(400, "bad_request")
                    return
                r = reached()
                c = connected()
                if c is not None:
                    r = max(r, c)
                if n > r:
                    self.err(403, "locked")
                    return
                self.js(level_payload(n, r))
                return
            if path == "/api/commands":
                self.js(commands_payload())
                return
            if path == "/api/casebook":
                self.js(casebook_payload())
                return
            if path == "/api/puzzle":
                pid = (qs.get("id") or [""])[0]
                if pid not in _PUZZLE_BY_ID:
                    self.err(404, "not_found")
                    return
                r = reached()
                c = connected()
                if c is not None:
                    r = max(r, c)
                if r < int(_PUZZLE_BY_ID[pid].get("requires", 0)):
                    self.err(403, "locked")
                    return
                self.js(puzzle_payload(pid))
                return
            if path == "/api/export":
                self.js(export_payload())
                return
            self.err(404, "not_found")
        except Exception:
            self.err(500, "server_error")

    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        try:
            if path == "/api/hint":
                self.handle_hint()
                return
            if path == "/api/verify":
                self.handle_verify()
                return
            if path == "/api/puzzle":
                self.handle_puzzle()
                return
            if path == "/api/labverify":
                self.handle_labverify()
                return
            if path == "/api/deduction":
                self.handle_deduction()
                return
            self.err(404, "not_found")
        except Exception:
            self.err(500, "server_error")

    def handle_hint(self):
        body = self.read_json()
        if body is None:
            self.err(400, "bad_request")
            return
        try:
            n = int(body.get("n"))
        except (TypeError, ValueError):
            self.err(400, "bad_request")
            return
        if not 0 <= n < len(LEVELS):
            self.err(400, "bad_request")
            return
        r = reached()
        c = connected()
        if c is not None:
            r = max(r, c)
        if n > r:
            self.err(403, "locked")
            return
        hints = LEVELS[n].get("hints") or []
        with _SCORE_LOCK:
            sc = load_scores()
            used = list((sc.get("hints_used") or {}).get(str(n), []) or [])
            idx = len(used)
            if idx >= len(hints):
                self.err(403, "no_more")
                return
            cost = HINT_COSTS[min(idx, len(HINT_COSTS) - 1)]
            total = compute_total(sc)
            if total < cost:
                self.err(409, "low_score")
                return
            used.append(idx)
            sc.setdefault("hints_used", {})[str(n)] = used
            save_scores(sc)
            total = sc["total"]
        hint = hints[idx]
        text = hint.get("text", "") if isinstance(hint, dict) else str(hint)
        self.js({"hint": text, "cost": cost, "total": total, "index": idx})

    def handle_verify(self):
        body = self.read_json()
        if body is None:
            self.err(400, "bad_request")
            return
        try:
            n = int(body.get("n"))
        except (TypeError, ValueError):
            self.err(400, "bad_request")
            return
        if not 0 <= n < len(LEVELS):
            self.err(400, "bad_request")
            return
        lv = LEVELS[n]
        if lv.get("type") not in GRADED:
            self.err(400, "bad_request")
            return
        r = reached()
        c = connected()
        if c is not None:
            r = max(r, c)
        if n > r:
            self.err(403, "locked")
            return
        script = (lv.get("verify") or "").strip()
        if not script:
            self.err(400, "bad_request")
            return
        next_pw = SECRETS.get(n + 1)
        stdin_data = (next_pw + "\n") if next_pw else ""
        if next_pw:
            remote = ("bash -e -c %s && umask 077 && tee ~/.cleared >/dev/null"
                      % shlex.quote(script))
            env = dict(os.environ)
            env["SSHPASS"] = SECRETS[n]
            cmd = [
                "sshpass", "-e", "ssh",
                "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null",
                "-o", "LogLevel=ERROR",
                "-o", "ConnectTimeout=5",
                "-p", str(GAME_SSH_PORT),
                "level%d@localhost" % n,
                remote,
            ]
            try:
                p = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=15,
                    env=env, input=stdin_data)
                rc, out, err = p.returncode, p.stdout or "", p.stderr or ""
            except (subprocess.TimeoutExpired, OSError):
                rc, out, err = 124, "", "grader timeout"
        else:
            rc, out, err = ssh_grade(
                "level%d" % n, "localhost", GAME_SSH_PORT, SECRETS[n],
                script)
        feedback = feedback_from(out, err, rc)
        clue = clue_id_of(lv)
        closed = lv.get("type") == "capstone"
        with _SCORE_LOCK:
            sc = load_scores()
            already = str(n) in (sc.get("by_level") or {})
            if rc == 0:
                if not already:
                    sc.setdefault("by_level", {})[str(n)] = points_of(lv)
                if closed:
                    sc["closed"] = True
                save_scores(sc)
                total = sc["total"]
            else:
                total = compute_total(sc)
        if rc == 0:
            payload = {
                "ok": True,
                "points": 0 if already else points_of(lv),
                "total": total,
                "clue": clue,
                "bonus": False,
                "feedback": feedback,
            }
            if closed:
                payload["closed"] = True
            self.js(payload)
        else:
            self.js({"ok": False, "feedback": feedback}, 400)

    def handle_puzzle(self):
        body = self.read_json()
        if body is None:
            self.err(400, "bad_request")
            return
        pid = body.get("id")
        if pid not in _PUZZLE_BY_ID:
            self.err(404, "not_found")
            return
        p = _PUZZLE_BY_ID[pid]
        r = reached()
        c = connected()
        if c is not None:
            r = max(r, c)
        if r < int(p.get("requires", 0)):
            self.err(403, "locked")
            return
        answer = body.get("answer")
        correct = check_puzzle_answer(p, answer)
        if not correct:
            self.js({"ok": False, "why": "Not quite - check each row against the manual."}, 400)
            return
        pts = _PUZZLE_POINTS.get(pid, 50)
        with _SCORE_LOCK:
            sc = load_scores()
            already = bool((sc.get("puzzles") or {}).get(pid))
            if not already:
                sc.setdefault("puzzles", {})[pid] = True
                save_scores(sc)
            total = sc["total"]
        self.js({"ok": True, "points": 0 if already else pts, "total": total})

    def handle_labverify(self):
        body = self.read_json()
        if body is None:
            self.err(400, "bad_request")
            return
        lid = body.get("id")
        if lid not in _LAB_BY_ID:
            self.err(404, "not_found")
            return
        lab = _LAB_BY_ID[lid]
        r = reached()
        c = connected()
        if c is not None:
            r = max(r, c)
        if r < int(lab.get("requires", 0)):
            self.err(403, "locked")
            return
        script = (lab.get("verify") or "").strip()
        if not script:
            self.err(400, "bad_request")
            return
        rc, out, err = ssh_grade(
            "intern", LAB_HOST, LAB_SSH_PORT, LAB_PASSWORD, script)
        feedback = feedback_from(out, err, rc)
        pts = int(lab.get("points", 150))
        with _SCORE_LOCK:
            sc = load_scores()
            already = bool((sc.get("labs") or {}).get(lid))
            if rc == 0 and not already:
                sc.setdefault("labs", {})[lid] = pts
                save_scores(sc)
            total = compute_total(sc)
        if rc == 0:
            self.js({
                "ok": True,
                "points": 0 if already else pts,
                "total": total,
                "clue": None,
                "bonus": False,
                "feedback": feedback,
            })
        else:
            self.js({"ok": False, "feedback": feedback}, 400)

    def handle_deduction(self):
        body = self.read_json()
        if body is None:
            self.err(400, "bad_request")
            return
        suspect = body.get("suspect")
        evidence = body.get("evidence")
        if not isinstance(evidence, list):
            self.err(400, "bad_request")
            return
        r = reached()
        c = connected()
        if c is not None:
            r = max(r, c)
        if r < 47:
            self.err(403, "locked")
            return
        with _SCORE_LOCK:
            sc = load_scores()
            if sc.get("closed") and (sc.get("deductions") or {}).get("L47"):
                self.js({
                    "ok": True,
                    "closed": True,
                    "points": 0,
                    "total": sc["total"],
                })
                return
        have = {x["id"] for x in collected_clues(r)}
        picked = {str(e).strip() for e in evidence if e}
        if suspect != DEDUCT_SUSPECT:
            self.js({"ok": False, "why": "The timeline doesn't point there yet."}, 400)
            return
        missing = [cid for cid in DEDUCT_REQUIRED if cid not in have or cid not in picked]
        if missing:
            self.js({
                "ok": False,
                "why": "The board needs more evidence before it will convict.",
            }, 400)
            return
        with _SCORE_LOCK:
            sc = load_scores()
            already = bool((sc.get("deductions") or {}).get("L47"))
            if not already:
                sc.setdefault("deductions", {})["L47"] = 300
                sc["closed"] = True
                save_scores(sc)
            total = sc["total"]
        self.js({
            "ok": True,
            "closed": True,
            "points": 0 if already else 300,
            "total": total,
        })


def export_payload():
    r = reached()
    c = connected()
    if c is not None:
        r = max(r, c)
    with _SCORE_LOCK:
        sc = load_scores()
        sc = dict(sc)
    levels = [{
        "n": i,
        "act": lv.get("act"),
        "type": lv.get("type"),
        "title": lv["title"] if i <= r else "locked",
        "status": status_of(i, r, c),
        "points": points_of(lv),
        "cleared": str(i) in (sc.get("by_level") or {}),
    } for i, lv in enumerate(LEVELS)]
    return {
        "profile": {
            "rank": rank_of(sc.get("total", 0)),
            "total": sc.get("total", 0),
            "reached": r,
        },
        "levels": levels,
        "puzzles": sc.get("puzzles") or {},
        "labs": sc.get("labs") or {},
        "clues": [x["id"] for x in collected_clues(r)],
        "hints_used": sc.get("hints_used") or {},
        "closed": bool(sc.get("closed")),
        "exported_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def main():
    ThreadingHTTPServer(("0.0.0.0", 9021), Handler).serve_forever()


if __name__ == "__main__":
    main()
