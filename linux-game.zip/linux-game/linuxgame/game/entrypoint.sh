#!/bin/bash
# Container main process: sshd for the learners, dashboard as an unprivileged user.
set -eu
mkdir -p /run/sshd
/usr/sbin/sshd -e
# sshd daemonizes, so verify it really accepts connections before handing over.
for i in $(seq 1 40); do
    if bash -c 'exec 3<>/dev/tcp/127.0.0.1/22' 2>/dev/null; then
        break
    fi
    if [ "$i" -eq 40 ]; then
        echo "entrypoint: sshd did not start listening on port 22" >&2
        exit 1
    fi
    sleep 0.25
done
# Per-level listener hooks: any executable /home/levelN/start_listener.sh runs
# in the background as levelN before the dashboard starts. A broken listener
# is noted on stderr but never takes the container down. A listener may stage
# the *next* level's password into a fifo in levelN's own home (that is the
# level's mechanic); it never runs as root and never touches another user's
# files.
for hook in /home/level*/start_listener.sh; do
    [ -x "$hook" ] || continue
    lvl=$(basename "$(dirname "$hook")")
    ( runuser -u "$lvl" -- "$hook" \
        || echo "entrypoint: listener ${lvl}/start_listener.sh exited non-zero" >&2 ) &
done
exec runuser -u gameserver -- python3 /opt/game/server.py
