# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Primary: a single learner (student or hobbyist) practicing real Linux skills —
filesystem navigation, permissions, pipes, processes, text tools — completely
offline, at their own pace, in a classroom lab, air-gapped room, or from a
USB pendrive deploy. Secondary: the instructor who resets the environment
(`docker compose down && up -d`, `reset.bat N`) between sessions and demos.

## Product Purpose

"Nimbus Casebook" turns Linux drill work into a story-driven detective
training console. 48 chain levels + 6 interactive puzzles + 5 practice labs:
each case is a mystery at whimsical Nimbus Corp; solving it with real shell
commands (over SSH, in the learner's own terminal) clears the case and stages
the next. Success = the learner finishes all five acts, closes the casebook
on the finale deduction board, and can actually use the commands in the wild.

## Positioning

A neighboring product could not truthfully copy: it runs with the network
cable cut — zero external assets, fonts, or calls; every image, texture, and
byte ships in the container. The chain is real progressive disclosure backed
by a PAM-hooked progress file and an sshpass grader: the next case's key is
physically staged in the learner's home only after the previous verify
passes. Passwords are never learner-visible; the dashboard is a story surface
above a real multi-user Linux box, not a simulation.

## Operating Context

- `docker compose up -d` on localhost; dashboard at http://localhost:9021;
  game ssh on 127.0.0.1:2222; practice-lab ssh on 127.0.0.1:2223.
- The learner reads the case in the dashboard, switches to a real terminal
  (`ssh levelN@localhost -p 2222`), works the files, returns to Verify.
- The dashboard is the console between cases: case file grid, command chips,
  casebook clues, puzzles, labs, hint economy, score/rank, export, and the
  act-5 deduction finale.
- Deployment is pendrive-friendly (`build.bat` → offline image tar + debs).

## Capabilities and Constraints

- 10 API endpoints (state, level, commands, casebook, export, hint, verify,
  puzzle, labverify, deduction); dashboard must keep all of them wired.
- HARD offline lock: zero external URLs, CDNs, webfonts, analytics — the
  dashboard must pass a "no external assets" gate.
- Single learner, localhost-only; playful English; LF line endings; vanilla
  HTML/CSS/JS single file served by Python stdlib http.server (no build
  step, no framework — existing codebase answers the stack).
- 5 acts; ranks; hint costs 5/15/30; replay verifies award 0 (anti-farming);
  per-level file reset (`reset.bat N`) keeps score; full reset wipes all.

## Brand Commitments

- Name: Nimbus Casebook. World: the delightfully mismanaged Nimbus Corp.
- Cast: Inspector Prompt (mentor voice) and Milo the over-helpful intern
  (bullet-point speech). Voice: warm, witty, playful English — never
  corporate-cold, never snarky at the learner.
- Core metaphor: detective case work — cases, evidence, casebook, clues,
  custody, the finale deduction board. The UI is the case file, not a "LMS".
- Accessibility floor already shipped and to be preserved: aria-live
  feedback, aria-labels, roles, skip link, keyboard operable.

## Evidence on Hand

- `docs/STORY_BIBLE.md`, `docs/AUTHORING.md`, `docs/API_CONTRACT.md`
- `game/levels.yaml` (all case stories/copy), `game/index.html` (incumbent UI)
- `README.txt`, `CHANGELOG.md`, test suites pinning behavior
- No photographic or illustrated assets exist yet; any imagery must be
  authored offline-safe (CSS/SVG, no external raster URLs).

## Product Principles

1. Offline is sacred — if it needs the network, it does not ship.
2. The terminal is truth; the dashboard frames the story and the next step.
3. The chain IS the plot — progress must always read as narrative momentum.
4. Playful beats preachy; the learner is a colleague, not a pupil.
5. "What do I do next?" is always answerable at a glance.

## Accessibility & Inclusion

Preserve and extend the shipped floor: keyboard operable, aria-live status
changes, labelled controls, visible focus, sufficient contrast, skip link,
reduced-motion respect. The dashboard is the only visual surface; it must
work at 390px through 1600px.
