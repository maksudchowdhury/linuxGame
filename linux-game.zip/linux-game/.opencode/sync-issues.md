# Sync Issues (Unresolved Only)

## SYNC-16 (NEW — act5 rework incomplete; blocks S2.4.5)
- Severity: HIGH (AUTHORING §3 gate 10/11 ≠ 11/11; solutionbook missing ids 37-47)
- Files: linuxgame/solutions/_act5.yaml ↔ linuxgame/levels/_act5.yaml ↔ tools/_merge_levels.py ↔ linuxgame/solutions/solutionbook.yaml
- Problem (state after 07:30:45 rewrite of solutions/_act5.yaml, 84 lines):
  1. **L47 gate FAIL** (Reviewer WSL-native AND Windows-host probes both 10/11):
     solution starts detached session `tmux new-session -d -s finale "cd $HOME && ./timeline.sh"`
     whose command exits in <1s → session + tmux server die → new `sleep 1; tmux ls || exit 1`
     lines then hit "no server running on /tmp/tmux-0/default" rc1 → exit 1. Genuine bug
     (reproduced in WSL /tmp ext4; fails in container too). Fix: keep session alive
     (e.g. `./timeline.sh; sleep 10`) or drop `tmux ls`; re-gate 11/11.
  2. **Merge schema drop**: file uses top-level `chain:` but _merge_levels.py reads
     `d.get('solutions', [])` (siblings _act1..4 use `solutions:`) → re-merge silently
     drops ids 37-47. solutionbook.yaml (07:14:32) still has ids 0-36 only. Fix: rename
     `chain:` → `solutions:` (simulate_chain accepts both; merge becomes consistent).
  3. **No unit-test record** in .opencode/unit-tests/ for the rework; no work-log entry.
- Fix: fix L47 + rename key → re-merge solutionbook (ids 0-47) → both gates 11/11 →
  write unit-test record. Reviewer evidence: work-log 07:35 FAIL section.
- Status: pending (original task_a9f4924e was phantom "(No output)" zero artifacts;
  rewrite done Commander-side 07:30 still fails gate)

## SYNC-13 (NEW — M3-C rework: buildcheck not wired)
- Severity: HIGH (AUTHORING §3 build-time solvability gate never runs)
- Files: linuxgame/Dockerfile ↔ linuxgame/solutions/_buildcheck.py ↔ docs/TEST_PLAN.md L75
- Problem: ses_m3c landed `_buildcheck.py` (+isolated test 17/17 PASS) but never touched the
  Dockerfile (2957 B, mtime 20:13 yesterday, zero diff vs HEAD). No `validator` stage exists,
  so the build-time gate is dead code. Also missing: unit-test record in .opencode/unit-tests/,
  isolated test file not deleted, SYNC-1 lab package (`software-properties-common`) not applied.
- Fix: add `validator` stage (after game/lab bake; run setup.py --target game|lab then
  `_buildcheck.py`; exit nonzero on FAIL; never part of runtime stages); add
  software-properties-common to lab stage; write unit-test record; delete isolated test;
  `docker compose build` exit 0 with validator green.
- Status: pending — evidence: work-log Reviewer results 07:24

## SYNC-12 (NEW — act2 phantom worker; blocks S2.4.2)
- Severity: HIGH (AUTHORING §3 solvability broken for act2; 4/10 levels fail, 1 false-pass)
- Files: linuxgame/solutions/_act2.yaml ↔ linuxgame/levels/_act2.yaml ↔ linuxgame/solutions/solutionbook.yaml
- Problem: worker task_d98dbe78 ("Act2 fix 5 failing levels", COMPLETED 189s, "(No output)")
  wrote NOTHING. Evidence: solutions/_act2.yaml mtime 10/10 21:53:36 and levels/_act2.yaml
  mtime 10/10 22:03:42 both predate the task; no unit-test record in .opencode/unit-tests/;
  no work-log entry; solutionbook.yaml ids 9-18 byte-identical to old _act2 content.
  Reviewer gate `python tools/simulate_chain.py --act 2`: **6/10** (L10 last='status: final',
  L13 last='denied', L16 last='stash.txt recorded...', L18 verify `[ -s nightwatcher.txt ]`
  passes on pristine home). Same phantom pattern as task_32fc77bd/task_36588f8e/task_fabb6bf7.
- Fix: re-dispatch act2 fix with artifact-gate: solutions L9/10/13/16 must end `echo "$NEXT_PW"`;
  L18 verify must be absent or fail on pristine home (nightwatcher.txt must not pre-exist, or
  verify a post-solution artifact); then re-merge solutionbook.yaml; gate must be 10/10;
  unit-test record required in .opencode/unit-tests/.
- Status: pending

## SYNC-14 (was mislabeled SYNC-13 — simulator false-pass; ID collision fixed by Reviewer 07:26)
- Severity: MEDIUM (masks act2 L9 failure; corrupts gate signal)
- Files: tools/simulate_chain.py L77
- Problem: capstone branch `if i == total - 1` compares the raw level id against the shard's
  LEVEL COUNT. For `--act 2` (ids 9-18, total=10) id 9 == total-1 -> L9 is treated as capstone
  and "PASSes" on rc0 regardless of its last line. Correct check: `i == max(ids in shard)`
  (or last id after sorting). Act1 id 8==8 is correct only by coincidence.
- Fix: replace with `if i == max(by_id)` (per-shard last id); re-run --act 1..5 gates.
- Status: pending

## SYNC-10 (REWORK ROUND 2 — KeyError FIXED, build now DEADLOCKS at level 24)
- Severity: CRITICAL (blocks build, M4, M5)
- Files: linuxgame/game/setup.py ↔ linuxgame/levels/_act3.yaml (L24) ↔ linuxgame/game/levels.yaml
- Problem (old, FIXED 07:05): `KeyError: 'password'` — setup.py now loads passwords from
  game/secrets.yaml; Reviewer unit re-run 10/10 PASS, chain gate (a)(b)(c) PASS.
- Problem (NEW, Reviewer 07:25): `docker compose build` HANGS indefinitely at `game 3/3`
  inside setup.py at level 24. L24 setup stages the fifo writer as
  `(echo "$NEXT_PW" > tunnel &)` — at build time no reader exists, so open() blocks
  forever while the background child holds setup.py's captured stdout/stderr PIPES;
  run_setup_script (capture_output=True, NO timeout) never returns.
  Evidence: build job_3580fcba stuck >5 min at step game 3/3 (all other setups = seconds);
  WSL repro: subprocess.run(["bash","-e","-c",script], capture_output=True, timeout=8)
  → `TimeoutExpired` CONFIRMED; file-redirect variant returns rc=0 (pipe-deadlock, not script logic).
  Escaped worker gates: unit test mocks subprocess; dry-run gate only `bash -n` (never executes);
  simulate_chain on Windows host passes L24 only because mkfifo fails there (setup aborts early).
- Fix (two-sided, BOTH needed):
  1. setup.py `run_setup_script`: stop using OS pipes for child I/O — redirect stdout/stderr
     to tempfile.TemporaryFile() (or DEVNULL + keep stderr file) AND add timeout (e.g. 120s)
     with process-group kill; read the temp file for redaction on failure. Any future setup
     that backgrounds a job must not be able to deadlock the runner.
  2. levels/_act3.yaml L24: stage the writer so it does not block the build — e.g. setup
     writes `/home/level24/start_listener.sh` (entrypoint hook already runs it as level24
     at container start), instead of backgrounding the blocked open() during setup.
- Status: PENDING REWORK — Reviewer unit review FAIL 07:25 (S3.2 stays [ ]; DO NOT merge
  more phases until `docker compose build` exits 0)

## SYNC-15 (NEW — base_test still reads removed password keys)
- Severity: HIGH (base suite crashes with KeyError → 0/21 once containers rebuild)
- Files: linuxgame/tests/base_test.py ↔ linuxgame/game/levels.yaml ↔ linuxgame/tests/ssh-runner/Dockerfile
- Problem: base_test.py L141/L165/L199 use `LEVELS[0]["password"]` / `LEVELS[1]["password"]`,
  but merged levels.yaml carries NO `password` key (AUTHORING contract; passwords live in
  game/secrets.yaml). server.py was fixed by S3.1 (`SECRETS[0]`, 07:13) but the test was not
  (only the /api/hint POST change landed 07:14). Tester image COPYs levels.yaml only, so the
  KeyError happens in-container at the first password check → `unhandled error` → exit 1.
- Fix: deliver secrets to the tester (e.g. compose profile `tests` env/file or docker cp of
  game/secrets.yaml to /opt/test/) and read `passwords[0]`/`passwords[1]` there; or drive
  level0/level1 logins from a secrets-backed loader. Then run-base-test.ps1 → 21/21.
- Status: pending (S3.1/test-suite scope; found by Reviewer during SYNC-10 unit review 07:22)

## SYNC-9 (fixed pending suite confirmation)
- Severity: HIGH → downgraded once suite runs
- Files: linuxgame/game/index.html ↔ linuxgame/tests/base_test.py L128
- Problem: base_test asserts literal `Welcome to Nimbus Corp` in GET / html; rewrite
  dropped it (20/21 at 21:59). Marker RESTORED in index.html (56804 B @ 22:05:14,
  verified present by grep) — but cannot confirm 21/21 until SYNC-10 build break is fixed.
- Fix: rebuild + run run-base-test.ps1 after SYNC-10 → if 21/21, DELETE this issue.
- Status: pending (blocked on SYNC-10)

## SYNC-1 (narrowed — shard side DONE 21:34)
- Severity: MEDIUM
- Files: linuxgame/commands/_shard4.yaml ↔ linuxgame/Dockerfile
- Problem: `add-apt-repository` chip is `runtime: lab` with 3 safe man-page examples,
  but the LAB image does not install `software-properties-common` yet, so those
  examples are dead inside linuxlab until Phase 4.
- Fix: M3/S3.3 Dockerfile: add `software-properties-common` to the lab stage; then
  re-run examples_run (M4) for the 3 safe examples.
- Status: pending (blocked on M3, not on any shard worker)

## SYNC-4 (environment)
- Severity: LOW
- Files: tooling
- Problem: `lsp_diagnostics` fails "Failed to write request to Rust tool process" on
  every call. Workaround in force: python yaml/py_compile gates + container probes.
- Fix: restart/repair language-server process.
- Status: pending

<!-- CLEARED 22:07 — SYNC-5 (kill kind=builtin verified in shard3 + merge 22:04),
     SYNC-7 (dict-mistakes cleared in shard2/4/5, all shards all-string 22:07:54)
     SYNC-11 (CLEARED 07:18 — act1 solutions re-authored by ses_a1s11; Reviewer
     independent probe 9/9 + L7/L8 verify, stderr clean, merge deterministic,
     VALIDATION OK, solutionbook ids 0-8 identical; record
     .opencode/unit-tests/2026-10-11-solutions_act1-rework.md)
     SYNC-8 (CLEARED 07:20 — all shards 0 <3-safe / 0 dup-safe / 0 hazard / 0 enum;
     21 chips re-authored to 3 distinct RC-0 safe examples; merge idempotent
     SHA256 EDEB8070…51E220; master coverage 149+ssh-keygen; VALIDATION OK;
     Reviewer independent docker probes RC=0; ses_s8t) -->
