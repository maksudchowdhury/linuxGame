# Ubuntu Manpage: killall - kill processes by name

> Source: https://manpages.ubuntu.com/manpages/noble/man1/killall.1.html
> Cached: 2026-10-10T14:50:32.769Z

---

## [SYNOPSIS](#synopsis)

**killall** [**-Z**,**&#x00A0;--context** *pattern*]
    [**-e**,**&#x00A0;--exact**]
    [**-g**,**&#x00A0;--process-group**]
    [**-i**,**&#x00A0;--interactive**] [**-n**,**&#x00A0;--ns**
    *PID*] [**-o**,**&#x00A0;--older-than** *TIME*]
    [**-q**,**&#x00A0;--quiet**] [**-r**,**&#x00A0;--regexp**]
    [**-s**,**&#x00A0;--signal**
    *SIGNAL*,&#x00A0;**-*******SIGNAL*]
    [**-u**,**&#x00A0;--user** *user*]
    [**-v**,**&#x00A0;--verbose**] [**-w**,**&#x00A0;--wait**]
    [**-y**,**&#x00A0;--younger-than** *TIME*]
    [**-I**,**&#x00A0;--ignore-case**]
    [**-V**,**&#x00A0;--version**] [**--**] *name* ...
  

  **killall** **-l**, **--list**
  

  **killall** **-V**,**&#x00A0;--version**

## [DESCRIPTION](#description)

**killall** sends a signal to all processes running any of the
    specified commands. If no signal name is specified, SIGTERM is sent.
Signals can be specified either by name (e.g. **-HUP** or
    **-SIGHUP**) or by number (e.g. **-1**) or by option **-s**.
If the command name is not regular expression (option **-r**)
    and contains a slash (**/**), processes executing that particular file
    will be selected for killing, independent of their name.
**killall** returns a zero return code if at least one process
    has been killed for each listed command, or no commands were listed and at
    least one process matched the **-u** and **-Z** search criteria.
    **killall** returns non-zero otherwise.
A **killall** process never kills itself (but may kill other
    **killall** processes).

## [OPTIONS](#options)

  [**-e**, **--exact**](#e)
  Require an exact match for very long names. If a command name is longer
      than 15 characters, the full name may be unavailable (i.e. it is swapped
      out). In this case, **killall** will kill everything that matches
      within the first 15 characters. With **-e**, such entries are skipped.
      **killall** prints a message for each skipped entry if **-v** is
      specified in addition to **-e**.
  **-I**,
    **--ignore-case**
  Do case insensitive process name match.
  **-g**,
    **--process-group**
  Kill the process group to which the process belongs. The kill signal is
      only sent once per group, even if multiple processes belonging to the same
      process group were found.
  **-i**,
    **--interactive**
  Interactively ask for confirmation before killing.
  [**-l**, **--list**](#l)
  List all known signal names.
  [**-n**, **--ns**](#n)
  Match against the PID namespace of the given PID. The default is to match
      against all namespaces.
  **-o**,
    **--older-than**
  Match only processes that are older (started before) the time specified.
      The time is specified as a float then a unit. The units are s,m,h,d,w,M,y
      for seconds, minutes, hours, days, weeks, months and years
    respectively.
  [**-q**, **--quiet**](#q)
  Do not complain if no processes were killed.
  [**-r**, **--regexp**](#r)
  Interpret process name pattern as a POSIX extended regular expression, per
      [**regex**(3)](/manpages/noble/man3/regex.3.html).
  **-s**, **--signal**,
    **-***SIGNAL*****
  Send this signal instead of SIGTERM.
  [**-u**, **--user**](#u)
  Kill only processes the specified user owns. Command names are
    optional.
  [**-v**, **--verbose**](#v)
  Report if the signal was successfully sent.
  [**-V**, **--version**](#V)
  Display version information.
  [**-w**, **--wait**](#w)
  Wait for all killed processes to die. **killall** checks once per
      second if any of the killed processes still exist and only returns if none
      are left. Note that **killall** may wait forever if the signal was
      ignored, had no effect, or if the process stays in zombie state.
  **-y**,
    **--younger-than**
  Match only processes that are younger (started after) the time specified.
      The time is specified as a float then a unit. The units are s,m,h,d,w,M,y
      for seconds, minutes, hours, days, weeks, Months and years
    respectively.
  [**-Z**, **--context**](#Z)
  Specify security context: kill only processes having security context that
      match with given extended regular expression pattern. Must precede other
      arguments on the command line. Command names are optional.

## [FILES](#files)

  /proc
  location of the proc file system

KNOWN
  BUGS
Killing by file only works for executables that are kept open
    during execution, i.e. impure executables can't be killed this way.
Be warned that typing **killall** *name* may not have the
    desired effect on non-Linux systems, especially when done by a privileged
    user.
**killall -w** doesn't detect if a process disappears and is
    replaced by a new process with the same PID between scans.
If processes change their name, **killall** may not be able to
    match them correctly.
**killall** has a limit of names that can be specified on the
    command line. This figure is the size of an unsigned long integer multiplied
    by 8. For most 32 bit systems the limit is 32 and similarly for a 64 bit
    system the limit is usually 64.

SEE
  ALSO
[**kill**(1)](/manpages/noble/man1/kill.1.html), [**fuser**(1)](/manpages/noble/man1/fuser.1.html), [**pgrep**(1)](/manpages/noble/man1/pgrep.1.html), [**pidof**(1)](/manpages/noble/man1/pidof.1.html),
    [**pkill**(1)](/manpages/noble/man1/pkill.1.html), [**ps**(1)](/manpages/noble/man1/ps.1.html), [**kill**(2)](/manpages/noble/man2/kill.2.html), [**regex**(3)](/manpages/noble/man3/regex.3.html).