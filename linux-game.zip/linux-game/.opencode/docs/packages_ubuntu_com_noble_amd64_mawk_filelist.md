# Ubuntu – File list of package mawk/noble/amd64

> Source: https://packages.ubuntu.com/noble/amd64/mawk/filelist
> Cached: 2026-10-10T15:03:18.934Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/amd64/) 

 » [mawk](/noble/mawk) 

 » [amd64](/noble/amd64/mawk) 

 » File list 

 

  # File list of package *mawk* in *noble* of architecture *amd64*

/usr/bin/mawk
/usr/share/doc/mawk/ACKNOWLEDGMENT
/usr/share/doc/mawk/README
/usr/share/doc/mawk/changelog.Debian.gz
/usr/share/doc/mawk/copyright
/usr/share/doc/mawk/examples/ct_length.awk
/usr/share/doc/mawk/examples/decl.awk
/usr/share/doc/mawk/examples/deps.awk
/usr/share/doc/mawk/examples/eatc.awk
/usr/share/doc/mawk/examples/gdecl.awk
/usr/share/doc/mawk/examples/hcal
/usr/share/doc/mawk/examples/hical
/usr/share/doc/mawk/examples/nocomment.awk
/usr/share/doc/mawk/examples/primes.awk
/usr/share/doc/mawk/examples/qsort.awk
/usr/share/man/man1/mawk.1.gz
/usr/share/man/man7/mawk-arrays.7.gz
/usr/share/man/man7/mawk-code.7.gz

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/amd64/mawk/filelist)

[Deutsch](/de/noble/amd64/mawk/filelist)

[suomi](/fi/noble/amd64/mawk/filelist)

[fran&ccedil;ais](/fr/noble/amd64/mawk/filelist)

[magyar](/hu/noble/amd64/mawk/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/amd64/mawk/filelist)

[Nederlands](/nl/noble/amd64/mawk/filelist)

[polski](/pl/noble/amd64/mawk/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/amd64/mawk/filelist)

[slovensky](/sk/noble/amd64/mawk/filelist)

[svenska](/sv/noble/amd64/mawk/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/amd64/mawk/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/amd64/mawk/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/amd64/mawk/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/amd64/mawk/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).