# Ubuntu – Details of package rename in noble

> Source: https://packages.ubuntu.com/noble/rename
> Cached: 2026-10-10T14:49:07.326Z

---

[ packages](/)

        Skip
             to content

package names
descriptions
source package names
package contents

[all options](/)
 

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble (24.04LTS)](/noble/) 

 » [perl](/noble/perl/) 

 » rename 

 

          [     [jammy](/jammy/rename)   ]
          [    **noble**   ]
          [     [questing](/questing/rename)   ]
          [     [resolute](/resolute/rename)   ]
          [     [stonking](/stonking/rename)   ]

  [ Source:    [rename](/source/noble/rename)   ]

Package: rename (2.02-1)
 [**universe**] 

## Links for rename

[](//screenshots.debian.net/package/rename)

### Ubuntu Resources:

- [Bug Reports](https://launchpad.net/ubuntu/+source/rename/+bugs)

- [Ubuntu Changelog](https://changelogs.ubuntu.com/changelogs/pool/universe/r/rename/rename_2.02-1/changelog)

- [Copyright File](https://changelogs.ubuntu.com/changelogs/pool/universe/r/rename/rename_2.02-1/copyright)

  Download Source Package [rename](/source/noble/rename):
  
    

    - [[rename_2.02-1.dsc]](http://archive.ubuntu.com/ubuntu/pool/universe/r/rename/rename_2.02-1.dsc)

    
  
    
    - [[rename_2.02.orig.tar.gz]](http://archive.ubuntu.com/ubuntu/pool/universe/r/rename/rename_2.02.orig.tar.gz)

    
  
    
    - [[rename_2.02-1.debian.tar.xz]](http://archive.ubuntu.com/ubuntu/pool/universe/r/rename/rename_2.02-1.debian.tar.xz)

    

  
  

  ### Maintainer:

  
	[Ubuntu MOTU Developers](mailto:ubuntu-motu@lists.ubuntu.com)
   ([Mail Archive](http://lists.ubuntu.com/archives/ubuntu-motu/))
	

Please consider [filing a bug](https://bugs.launchpad.net/ubuntu/+source/rename/+filebug) or [asking a question](https://answers.launchpad.net/ubuntu/+source/rename/+addquestion) via Launchpad before contacting the maintainer directly.

  ### Original Maintainers (usually from Debian):

  
	Debian Perl Group
   ([Mail Archive](http://lists.alioth.debian.org/pipermail/pkg-perl-maintainers/))
	
  
	Dominic Hargreaves
  
	

It should generally not be necessary for users to contact the original maintainer.

### External Resources:

- [Homepage](https://metacpan.org/release/File-Rename) [metacpan.org]

	
	### Similar packages:

	

	
	- [caja-rename](/caja-rename)

	

	
	- [nautilus-hide](/nautilus-hide)

	

	
	- [node-gulp-rename](/node-gulp-rename)

	

	
	- [libfile-util-perl](/libfile-util-perl)

	

	
	- [rename-flac](/rename-flac)

	

	
	- [libspreadsheet-xlsx-perl](/libspreadsheet-xlsx-perl)

	

	
	- [libsyntax-keyword-multisub-perl](/libsyntax-keyword-multisub-perl)

	

	
	- [libconfig-inihash-perl](/libconfig-inihash-perl)

	

	
	- [libfile-copy-recursive-perl](/libfile-copy-recursive-perl)

	

	
	- [tvnamer](/tvnamer)

	

	
	- [libtext-bibtex-perl](/libtext-bibtex-perl)

	

 

	
	## Perl extension for renaming multiple files

	
	

 

 

      
    ## Other Packages Related to rename

    
    
    
- depends

    
- recommends

    
- suggests

    
- enhances

    
    

  

  
    
    
      
      dep:
	[perl](/noble/perl)
	
                Larry Wall's Practical Extraction and Report Language
        
      
      
    
  
  

       

      
    ## Download rename

    
    
    Download for all available architectures
    Architecture
	
	Package Size
	Installed Size
	Files
    

[all](/noble/all/rename/download)

19.9 kB62.0 kB

  [[list of files](/noble/all/rename/filelist)]

      

     

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/rename)

[Deutsch](/de/noble/rename)

[suomi](/fi/noble/rename)

[fran&ccedil;ais](/fr/noble/rename)

[magyar](/hu/noble/rename)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/rename)

[Nederlands](/nl/noble/rename)

[polski](/pl/noble/rename)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/rename)

[slovensky](/sk/noble/rename)

[svenska](/sv/noble/rename)

[T&uuml;rk&ccedil;e](/tr/noble/rename)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/rename)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/rename)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/rename)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).