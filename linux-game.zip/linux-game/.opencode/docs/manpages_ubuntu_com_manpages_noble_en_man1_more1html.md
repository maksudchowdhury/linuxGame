# Ubuntu Manpage: more - display the contents of a file in a terminal

> Source: https://manpages.ubuntu.com/manpages/noble/en/man1/more.1.html
> Cached: 2026-10-10T14:48:47.241Z

---

## [SYNOPSIS](#synopsis)

**more** [options] *file* ...

## [DESCRIPTION](#description)

**more** is a filter for paging through text one screenful at a
    time. This version is especially primitive. Users should realize that
    [**less**(1)](/manpages/noble/man1/less.1.html) provides [**more**(1)](/manpages/noble/man1/more.1.html) emulation plus extensive
    enhancements.

## [OPTIONS](#options)

Options are also taken from the environment variable **MORE**
    (make sure to precede them with a dash (**-**)) but command-line options
    will override those.
**-d**, **--silent**

Prompt with "[Press space to continue, 'q' to
  quit.]", and display "[Press 'h' for instructions.]" instead of
  ringing the bell when an illegal key is pressed.
**-l**, **--logical**

Do not pause after any line containing a **^L** (form
  feed).
**-e**, **--exit-on-eof**

Exit on End-Of-File, enabled by default if
  POSIXLY_CORRECT environment variable is not set or if not executed on
  terminal.
**-f**, **--no-pause**

Count logical lines, rather than screen lines (i.e., long
  lines are not folded).
**-p**, **--print-over**

Do not scroll. Instead, clear the whole screen and then
  display the text. Notice that this option is switched on automatically if the
  executable is named **page**.
**-c**, **--clean-print**

Do not scroll. Instead, paint each screen from the top,
  clearing the remainder of each line as it is displayed.
**-s**, **--squeeze**

Squeeze multiple blank lines into one.
**-u**, **--plain**

Suppress underlining. This option is silently ignored as
  backwards compatibility.
**-n**, **--lines** *number*

Specify the *number* of lines per screenful. The
  *number* argument is a positive decimal integer. The **--lines**
  option shall override any values obtained from any other source, such as
  number of lines reported by terminal.
**-***number*

A numeric option means the same as **--lines** option
  argument.
**+***number*

Start displaying each file at line *number*.
**+**/*string*

The *string* to be searched in each file before
  starting to display it.
**-h**, **--help**

Display help text and exit.
**-V**, **--version**

Print version and exit.

## [COMMANDS](#commands)

Interactive commands for **more** are based on [**vi**(1)](/manpages/noble/man1/vi.1.html).
    Some commands may be preceded by a decimal number, called k in the
    descriptions below. In the following descriptions, **^X** means
    **control-X**.
**h** or **?**

Help; display a summary of these commands. If you forget
  all other commands, remember this one.
**SPACE**

Display next k lines of text. Defaults to current screen
  size.
**z**

Display next k lines of text. Defaults to current screen
  size. Argument becomes new default.
**RETURN**

Display next k lines of text. Defaults to 1. Argument
  becomes new default.
**d** or **^D**

Scroll k lines. Default is current scroll size, initially
  11. Argument becomes new default.
**q** or **Q** or **INTERRUPT**

Exit.
**s**

Skip forward k lines of text. Defaults to 1.
**f**

Skip forward k screenfuls of text. Defaults to 1.
**b** or **^B**

Skip backwards k screenfuls of text. Defaults to 1. Only
  works with files, not pipes.
**'**

Go to the place where the last search started.
**=**

Display current line number.
**/pattern**

Search for kth occurrence of regular expression. Defaults
  to 1.
**n**

Search for kth occurrence of last regular expression.
  Defaults to 1.
**!command** or **:!command**

Execute *command* in a subshell.
**v**

Start up an editor at current line. The editor is taken
  from the environment variable **VISUAL** if defined, or **EDITOR** if
  **VISUAL** is not defined, or defaults to [**vi**(1)](/manpages/noble/man1/vi.1.html) if neither
  **VISUAL** nor **EDITOR** is defined.
**^L**

Redraw screen.
**:n**

Go to kth next file. Defaults to 1.
**:p**

Go to kth previous file. Defaults to 1.
**:f**

Display current file name and line number.
**.**

Repeat previous command.

## [ENVIRONMENT](#environment)

The **more** command respects the following environment
    variables, if they exist:
**MORE**

This variable may be set with favored options to
  **more**.
**SHELL**

Current shell in use (normally set by the shell at login
  time).
**TERM**

The terminal type used by **more** to get the terminal
  characteristics necessary to manipulate the screen.
**VISUAL**

The editor the user prefers. Invoked when command key
  *v* is pressed.
**EDITOR**

The editor of choice when **VISUAL** is not
  specified.
**POSIXLY_CORRECT**

Disable exit-on-eof (see option **-e** for more
  details).

## [HISTORY](#history)

The **more** command appeared in 3.0BSD. This man page
    documents **more** version 5.19 (Berkeley 6/29/88), which is currently in
    use in the Linux community. Documentation was produced using several other
    versions of the man page, and extensive inspection of the source code.

## [AUTHORS](#authors)

Eric Shienbrood, UC Berkeley.

Modified by Geoff Peck, UCB to add underlining, single
  spacing.
Modified by John Foderaro, UCB to add -c and MORE environment
    variable.

SEE
  ALSO
[**less**(1)](/manpages/noble/man1/less.1.html), [**vi**(1)](/manpages/noble/man1/vi.1.html)

REPORTING
  BUGS
For bug reports, use the issue tracker at **
    <https://github.com/util-linux/util-linux/issues>.

## [AVAILABILITY](#availability)

The **more** command is part of the util-linux package which
    can be downloaded from *Linux Kernel Archive*
    <https://www.kernel.org/pub/linux/utils/util-linux/>.