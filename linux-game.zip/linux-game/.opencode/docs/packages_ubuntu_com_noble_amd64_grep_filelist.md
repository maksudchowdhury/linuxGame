# Ubuntu – File list of package grep/noble/amd64

> Source: https://packages.ubuntu.com/noble/amd64/grep/filelist
> Cached: 2026-10-10T15:02:02.907Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/amd64/) 

 » [grep](/noble/grep) 

 » [amd64](/noble/amd64/grep) 

 » File list 

 

  # File list of package *grep* in *noble* of architecture *amd64*

/usr/bin/egrep
/usr/bin/fgrep
/usr/bin/grep
/usr/bin/rgrep
/usr/share/doc/grep/AUTHORS
/usr/share/doc/grep/NEWS.Debian.gz
/usr/share/doc/grep/NEWS.gz
/usr/share/doc/grep/README
/usr/share/doc/grep/THANKS.gz
/usr/share/doc/grep/TODO.gz
/usr/share/doc/grep/changelog.Debian.gz
/usr/share/doc/grep/copyright
/usr/share/info/grep.info.gz
/usr/share/man/man1/egrep.1.gz
/usr/share/man/man1/fgrep.1.gz
/usr/share/man/man1/grep.1.gz
/usr/share/man/man1/rgrep.1.gz

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/amd64/grep/filelist)

[Deutsch](/de/noble/amd64/grep/filelist)

[suomi](/fi/noble/amd64/grep/filelist)

[fran&ccedil;ais](/fr/noble/amd64/grep/filelist)

[magyar](/hu/noble/amd64/grep/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/amd64/grep/filelist)

[Nederlands](/nl/noble/amd64/grep/filelist)

[polski](/pl/noble/amd64/grep/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/amd64/grep/filelist)

[slovensky](/sk/noble/amd64/grep/filelist)

[svenska](/sv/noble/amd64/grep/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/amd64/grep/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/amd64/grep/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/amd64/grep/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/amd64/grep/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).