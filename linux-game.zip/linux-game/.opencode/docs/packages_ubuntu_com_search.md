# Ubuntu – Package Contents Search Results -- bin/more

> Source: https://packages.ubuntu.com/search?keywords=bin%2Fmore&searchon=contents&suite=noble&section=all
> Cached: 2026-10-10T14:48:38.122Z

---

[ packages](/)

        Skip
             to content

package names
descriptions
source package names
package contents

[all options](/)
 

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » Package Contents Search Results 

 

[Search for *bin/more* within filenames](/search?suite=noble&mode=filename&searchon=contents&keywords=bin%2Fmore)

[Search exact filename *bin/more*](/search?suite=noble&mode=exactfilename&searchon=contents&keywords=bin%2Fmore)

Search in other suite:

	
	[[jammy](/search?suite=jammy&searchon=contents&keywords=bin%2Fmore)]
	

	
	[noble]
	

	
	[[questing](/search?suite=questing&searchon=contents&keywords=bin%2Fmore)]
	

	
	[[resolute](/search?suite=resolute&searchon=contents&keywords=bin%2Fmore)]
	

	
	[[stonking](/search?suite=stonking&searchon=contents&keywords=bin%2Fmore)]
	

Limit search to a specific architecture:
 [[amd64](/search?suite=noble&arch=amd64&searchon=contents&keywords=bin%2Fmore)] [[arm64](/search?suite=noble&arch=arm64&searchon=contents&keywords=bin%2Fmore)] [[armhf](/search?suite=noble&arch=armhf&searchon=contents&keywords=bin%2Fmore)] [[i386](/search?suite=noble&arch=i386&searchon=contents&keywords=bin%2Fmore)] [[ppc64el](/search?suite=noble&arch=ppc64el&searchon=contents&keywords=bin%2Fmore)] [[riscv64](/search?suite=noble&arch=riscv64&searchon=contents&keywords=bin%2Fmore)] [[s390x](/search?suite=noble&arch=s390x&searchon=contents&keywords=bin%2Fmore)]

You have searched for paths that end with *bin/more* in suite *noble*, all sections, and all architectures.

Found **1 results**.

	
	
	
	

	[File](/search?suite=noble&searchon=contents&keywords=bin%2Fmore&sort_by=file)
	[Packages](/search?suite=noble&searchon=contents&keywords=bin%2Fmore&sort_by=pkg)

	/usr/bin/more
        
        
	
	[util-linux](/noble/util-linux)
	
        

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/search?lang=bg&suite=noble&searchon=contents&keywords=bin%2Fmore)

[Deutsch](/search?lang=de&suite=noble&searchon=contents&keywords=bin%2Fmore)

[suomi](/search?lang=fi&suite=noble&searchon=contents&keywords=bin%2Fmore)

[fran&ccedil;ais](/search?lang=fr&suite=noble&searchon=contents&keywords=bin%2Fmore)

[magyar](/search?lang=hu&suite=noble&searchon=contents&keywords=bin%2Fmore)

[&#26085;&#26412;&#35486; (Nihongo)](/search?lang=ja&suite=noble&searchon=contents&keywords=bin%2Fmore)

[Nederlands](/search?lang=nl&suite=noble&searchon=contents&keywords=bin%2Fmore)

[polski](/search?lang=pl&suite=noble&searchon=contents&keywords=bin%2Fmore)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/search?lang=ru&suite=noble&searchon=contents&keywords=bin%2Fmore)

[slovensky](/search?lang=sk&suite=noble&searchon=contents&keywords=bin%2Fmore)

[svenska](/search?lang=sv&suite=noble&searchon=contents&keywords=bin%2Fmore)

[T&uuml;rk&ccedil;e](/search?lang=tr&suite=noble&searchon=contents&keywords=bin%2Fmore)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/search?lang=uk&suite=noble&searchon=contents&keywords=bin%2Fmore)

[&#20013;&#25991; (Zhongwen,&#31616;)](/search?lang=zh-cn&suite=noble&searchon=contents&keywords=bin%2Fmore)

[&#20013;&#25991; (Zhongwen,&#32321;)](/search?lang=zh-tw&suite=noble&searchon=contents&keywords=bin%2Fmore)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).