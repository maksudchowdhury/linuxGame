# Ubuntu – File list of package gzip/noble/amd64

> Source: https://packages.ubuntu.com/noble/amd64/gzip/filelist
> Cached: 2026-10-10T14:54:30.857Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/amd64/) 

 » [gzip](/noble/gzip) 

 » [amd64](/noble/amd64/gzip) 

 » File list 

 

  # File list of package *gzip* in *noble* of architecture *amd64*

/usr/bin/gunzip
/usr/bin/gzexe
/usr/bin/gzip
/usr/bin/uncompress
/usr/bin/zcat
/usr/bin/zcmp
/usr/bin/zdiff
/usr/bin/zegrep
/usr/bin/zfgrep
/usr/bin/zforce
/usr/bin/zgrep
/usr/bin/zless
/usr/bin/zmore
/usr/bin/znew
/usr/share/doc/gzip/NEWS.gz
/usr/share/doc/gzip/README.gz
/usr/share/doc/gzip/TODO
/usr/share/doc/gzip/changelog.Debian.gz
/usr/share/doc/gzip/copyright
/usr/share/info/gzip.info.gz
/usr/share/man/man1/gunzip.1.gz
/usr/share/man/man1/gzexe.1.gz
/usr/share/man/man1/gzip.1.gz
/usr/share/man/man1/uncompress.1.gz
/usr/share/man/man1/zcat.1.gz
/usr/share/man/man1/zcmp.1.gz
/usr/share/man/man1/zdiff.1.gz
/usr/share/man/man1/zegrep.1.gz
/usr/share/man/man1/zfgrep.1.gz
/usr/share/man/man1/zforce.1.gz
/usr/share/man/man1/zgrep.1.gz
/usr/share/man/man1/zless.1.gz
/usr/share/man/man1/zmore.1.gz
/usr/share/man/man1/znew.1.gz

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/amd64/gzip/filelist)

[Deutsch](/de/noble/amd64/gzip/filelist)

[suomi](/fi/noble/amd64/gzip/filelist)

[fran&ccedil;ais](/fr/noble/amd64/gzip/filelist)

[magyar](/hu/noble/amd64/gzip/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/amd64/gzip/filelist)

[Nederlands](/nl/noble/amd64/gzip/filelist)

[polski](/pl/noble/amd64/gzip/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/amd64/gzip/filelist)

[slovensky](/sk/noble/amd64/gzip/filelist)

[svenska](/sv/noble/amd64/gzip/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/amd64/gzip/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/amd64/gzip/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/amd64/gzip/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/amd64/gzip/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).