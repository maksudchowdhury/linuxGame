# Ubuntu – File list of package rename/noble/all

> Source: https://packages.ubuntu.com/noble/all/rename/filelist
> Cached: 2026-10-10T14:49:22.714Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/all/) 

 » [rename](/noble/rename) 

 » [all](/noble/all/rename) 

 » File list 

 

  # File list of package *rename* in *noble* of architecture *all*

/usr/bin/file-rename
/usr/bin/prename
/usr/share/doc/rename/CONTRIBUTING
/usr/share/doc/rename/NEWS.Developer.gz
/usr/share/doc/rename/changelog.Debian.gz
/usr/share/doc/rename/copyright
/usr/share/doc/rename/examples/rename.pl
/usr/share/doc/rename/examples/unsafe-rename
/usr/share/doc/rename/examples/using-options-code.pl
/usr/share/doc/rename/examples/using-options.pl
/usr/share/man/man1/file-rename.1p.gz
/usr/share/man/man1/prename.1p.gz
/usr/share/man/man3/File::File::Rename.3pm.gz
/usr/share/man/man3/File::File::Rename::Options.3pm.gz
/usr/share/man/man3/File::File::Rename::Unicode.3pm.gz
/usr/share/perl5/File/Rename.pm
/usr/share/perl5/File/Rename/Options.pm
/usr/share/perl5/File/Rename/Unicode.pm

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/all/rename/filelist)

[Deutsch](/de/noble/all/rename/filelist)

[suomi](/fi/noble/all/rename/filelist)

[fran&ccedil;ais](/fr/noble/all/rename/filelist)

[magyar](/hu/noble/all/rename/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/all/rename/filelist)

[Nederlands](/nl/noble/all/rename/filelist)

[polski](/pl/noble/all/rename/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/all/rename/filelist)

[slovensky](/sk/noble/all/rename/filelist)

[svenska](/sv/noble/all/rename/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/all/rename/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/all/rename/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/all/rename/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/all/rename/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).