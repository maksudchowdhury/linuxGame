# rename - renames multiple files - metacpan.org

> Source: https://metacpan.org/pod/rename
> Cached: 2026-10-10T14:49:22.139Z

---

**Contents**

  - [NAME](#NAME)

  - [SYNOPSIS](#SYNOPSIS)

  [DESCRIPTION](#DESCRIPTION)
    

      - [Examples (Larry Wall, 1992)](#Examples-(Larry-Wall%2C-1992))

      - [More examples (2020)](#More-examples-(2020))

    

  
  - [OPTIONS](#OPTIONS)

  - [ENVIRONMENT](#ENVIRONMENT)

  - [AUTHOR](#AUTHOR)

  - [SEE ALSO](#SEE-ALSO)

  - [DIAGNOSTICS](#DIAGNOSTICS)

  - [BUGS](#BUGS)

# NAME

rename - renames multiple files

# SYNOPSIS

**rename** [ **-h**|**-m**|**-V** ] [ **-v** ] [ **-0** ] [ **-n** ] [ **-f** ] [ **-d** ] [ **-u** [*enc*]] [ **-e**|**-E** *perlexpr*]*|*perlexpr* [ *files* ]

# DESCRIPTION

`rename` renames the filenames supplied according to the rule specified as the first argument. The *perlexpr* argument is a Perl expression which is expected to modify the `$_` string in Perl for at least some of the filenames specified. If a given filename is not modified by the expression, it will not be renamed. If no filenames are given on the command line, filenames will be read via standard input.

## Examples (Larry Wall, 1992)

For example, to rename all files matching `*.bak` to strip the extension, you might say

```
rename -- 's/\.bak$//' *.bak
```

To translate uppercase names to lower, you'd use

```
rename 'y/A-Z/a-z/' ./*
```

Examples rewritten to avoid globs which could inject options.

## More examples (2020)

You can also use rename to move files between directories, possibly at the same time as making other changes (but see **--filename**)

```
rename 'y/A-Z/a-z/;s/^/my_new_dir\//' ./*.*
```

You can also write the statements separately (see **-e**/**-E**)

```
rename -E 'y/A-Z/a-z/' -E 's/^/my_new_dir\//' -- *.*
```

You can use the predefined variables `$a, $b` in the code; for instance to create sequences of numbers

```
rename -e '$a++;s/\w+/file_$a/' -- *.*
```

# OPTIONS

**-v**, **--verbose**

Verbose: print names of files successfully renamed.

**-0**, **--null**

Use \0 as record separator when reading from STDIN.

**-n**, **--nono**

No action: print names of files to be renamed, but don't rename.

**-f**, **--force**

Over write: allow existing files to be over-written.

**--path**, **--fullpath**

Rename full path: including any directory component. DEFAULT

**-d**, **--filename**, **--nopath**, **--nofullpath**

Do not rename directory: only rename filename component of path.

**-h**, **--help**

Help: print SYNOPSIS and OPTIONS.

**-m**, **--man**

Manual: print manual page.

**-V**, **--version**

Version: show version number.

**-u**, **--unicode** [*encoding*]

Treat filenames as perl (unicode) strings when running the user-supplied code.

Decode/encode filenames using *encoding*, if present.

*encoding* is optional: if omitted, the next argument should be an option starting with '-', for instance **-e**.

**-e**

Expression: code to act on files name.

May be repeated to build up code (like `perl -e`). If no **-e**, the first argument is used as code.

**-E**

Statement: code to act on files name, as **-e** but terminated by ';'.

# ENVIRONMENT

No environment variables are used.

# AUTHOR

Larry Wall

# SEE ALSO

mv(1), perl(1)

# DIAGNOSTICS

If you give an invalid Perl expression you'll get a syntax error.

# BUGS

The original `rename` did not check for the existence of target filenames, so had to be used with care.

  
    
      
        #### Module Install Instructions

        
      
      
        To install File::Rename, copy and paste the appropriate command in to your terminal.

        [cpanm](/dist/App-cpanminus/view/bin/cpanm)

        ```
cpanm File::Rename
```

        [CPAN shell](/pod/CPAN)

        ```
perl -MCPAN -e shell
install File::Rename
```

        For more information on module installation, please visit [the detailed CPAN module installation guide](https://www.cpan.org/modules/INSTALL.html).

      
      
        Close