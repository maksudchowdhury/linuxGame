# Ubuntu – File list of package util-linux/noble/i386

> Source: https://packages.ubuntu.com/noble/util-linux/filelist
> Cached: 2026-10-10T14:49:51.019Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/) 

 » [util-linux](/noble/util-linux) 

 » [i386](/noble/util-linux) 

 » File list 

 

  # File list of package *util-linux* in *noble* of architecture *i386*

/etc/pam.d/runuser
/etc/pam.d/runuser-l
/etc/pam.d/su
/etc/pam.d/su-l
/usr/bin/addpart
/usr/bin/choom
/usr/bin/chrt
/usr/bin/delpart
/usr/bin/dmesg
/usr/bin/fallocate
/usr/bin/findmnt
/usr/bin/flock
/usr/bin/getopt
/usr/bin/hardlink
/usr/bin/i386
/usr/bin/ionice
/usr/bin/ipcmk
/usr/bin/ipcrm
/usr/bin/ipcs
/usr/bin/last
/usr/bin/lastb
/usr/bin/linux32
/usr/bin/linux64
/usr/bin/lsblk
/usr/bin/lscpu
/usr/bin/lsipc
/usr/bin/lslocks
/usr/bin/lslogins
/usr/bin/lsmem
/usr/bin/lsns
/usr/bin/mcookie
/usr/bin/mesg
/usr/bin/more
/usr/bin/mountpoint
/usr/bin/namei
/usr/bin/nsenter
/usr/bin/partx
/usr/bin/prlimit
/usr/bin/rename.ul
/usr/bin/resizepart
/usr/bin/rev
/usr/bin/setarch
/usr/bin/setpriv
/usr/bin/setsid
/usr/bin/setterm
/usr/bin/su
/usr/bin/taskset
/usr/bin/uclampset
/usr/bin/unshare
/usr/bin/utmpdump
/usr/bin/wdctl
/usr/bin/whereis
/usr/lib/mime/packages/util-linux
/usr/lib/systemd/system/fstrim.service
/usr/lib/systemd/system/fstrim.timer
/usr/sbin/agetty
/usr/sbin/blkdiscard
/usr/sbin/blkid
/usr/sbin/blkzone
/usr/sbin/blockdev
/usr/sbin/chcpu
/usr/sbin/chmem
/usr/sbin/ctrlaltdel
/usr/sbin/findfs
/usr/sbin/fsck
/usr/sbin/fsck.cramfs
/usr/sbin/fsck.minix
/usr/sbin/fsfreeze
/usr/sbin/fstrim
/usr/sbin/getty
/usr/sbin/isosize
/usr/sbin/ldattach
/usr/sbin/mkfs
/usr/sbin/mkfs.bfs
/usr/sbin/mkfs.cramfs
/usr/sbin/mkfs.minix
/usr/sbin/mkswap
/usr/sbin/pivot_root
/usr/sbin/readprofile
/usr/sbin/rtcwake
/usr/sbin/runuser
/usr/sbin/sulogin
/usr/sbin/swaplabel
/usr/sbin/switch_root
/usr/sbin/wipefs
/usr/sbin/zramctl
/usr/share/bash-completion/completions/addpart
/usr/share/bash-completion/completions/blkdiscard
/usr/share/bash-completion/completions/blkid
/usr/share/bash-completion/completions/blkzone
/usr/share/bash-completion/completions/blockdev
/usr/share/bash-completion/completions/chcpu
/usr/share/bash-completion/completions/chmem
/usr/share/bash-completion/completions/chrt
/usr/share/bash-completion/completions/ctrlaltdel
/usr/share/bash-completion/completions/delpart
/usr/share/bash-completion/completions/dmesg
/usr/share/bash-completion/completions/fallocate
/usr/share/bash-completion/completions/findfs
/usr/share/bash-completion/completions/findmnt
/usr/share/bash-completion/completions/flock
/usr/share/bash-completion/completions/fsck
/usr/share/bash-completion/completions/fsck.cramfs
/usr/share/bash-completion/completions/fsck.minix
/usr/share/bash-completion/completions/fsfreeze
/usr/share/bash-completion/completions/fstrim
/usr/share/bash-completion/completions/getopt
/usr/share/bash-completion/completions/hardlink
/usr/share/bash-completion/completions/ionice
/usr/share/bash-completion/completions/ipcmk
/usr/share/bash-completion/completions/ipcrm
/usr/share/bash-completion/completions/ipcs
/usr/share/bash-completion/completions/isosize
/usr/share/bash-completion/completions/last
/usr/share/bash-completion/completions/lastb
/usr/share/bash-completion/completions/ldattach
/usr/share/bash-completion/completions/lsblk
/usr/share/bash-completion/completions/lscpu
/usr/share/bash-completion/completions/lsipc
/usr/share/bash-completion/completions/lslocks
/usr/share/bash-completion/completions/lslogins
/usr/share/bash-completion/completions/lsmem
/usr/share/bash-completion/completions/lsns
/usr/share/bash-completion/completions/mcookie
/usr/share/bash-completion/completions/mesg
/usr/share/bash-completion/completions/mkfs
/usr/share/bash-completion/completions/mkfs.bfs
/usr/share/bash-completion/completions/mkfs.cramfs
/usr/share/bash-completion/completions/mkfs.minix
/usr/share/bash-completion/completions/mkswap
/usr/share/bash-completion/completions/more
/usr/share/bash-completion/completions/mountpoint
/usr/share/bash-completion/completions/namei
/usr/share/bash-completion/completions/nsenter
/usr/share/bash-completion/completions/partx
/usr/share/bash-completion/completions/pivot_root
/usr/share/bash-completion/completions/prlimit
/usr/share/bash-completion/completions/readprofile
/usr/share/bash-completion/completions/resizepart
/usr/share/bash-completion/completions/rev
/usr/share/bash-completion/completions/rtcwake
/usr/share/bash-completion/completions/runuser
/usr/share/bash-completion/completions/setarch
/usr/share/bash-completion/completions/setpriv
/usr/share/bash-completion/completions/setsid
/usr/share/bash-completion/completions/setterm
/usr/share/bash-completion/completions/su
/usr/share/bash-completion/completions/swaplabel
/usr/share/bash-completion/completions/taskset
/usr/share/bash-completion/completions/uclampset
/usr/share/bash-completion/completions/unshare
/usr/share/bash-completion/completions/utmpdump
/usr/share/bash-completion/completions/wdctl
/usr/share/bash-completion/completions/whereis
/usr/share/bash-completion/completions/wipefs
/usr/share/bash-completion/completions/zramctl
/usr/share/doc/util-linux/00-about-docs.txt
/usr/share/doc/util-linux/AUTHORS.gz
/usr/share/doc/util-linux/PAM-configuration.txt
/usr/share/doc/util-linux/README.Debian
/usr/share/doc/util-linux/blkid.txt
/usr/share/doc/util-linux/cal.txt
/usr/share/doc/util-linux/changelog.Debian.gz
/usr/share/doc/util-linux/col.txt
/usr/share/doc/util-linux/copyright
/usr/share/doc/util-linux/deprecated.txt
/usr/share/doc/util-linux/examples/getopt-example.bash
/usr/share/doc/util-linux/examples/getopt-example.tcsh
/usr/share/doc/util-linux/getopt.txt
/usr/share/doc/util-linux/getopt_changelog.txt
/usr/share/doc/util-linux/howto-build-sys.txt
/usr/share/doc/util-linux/howto-compilation.txt
/usr/share/doc/util-linux/howto-contribute.txt.gz
/usr/share/doc/util-linux/howto-debug.txt
/usr/share/doc/util-linux/howto-man-page.txt
/usr/share/doc/util-linux/howto-pull-request.txt.gz
/usr/share/doc/util-linux/howto-tests.txt
/usr/share/doc/util-linux/howto-usage-function.txt.gz
/usr/share/doc/util-linux/hwclock.txt
/usr/share/doc/util-linux/modems-with-agetty.txt
/usr/share/doc/util-linux/mount.txt
/usr/share/doc/util-linux/parse-date.txt.gz
/usr/share/doc/util-linux/pg.txt
/usr/share/doc/util-linux/poeigl.txt.gz
/usr/share/doc/util-linux/release-schedule.txt
/usr/share/doc/util-linux/releases/v2.13-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.14-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.15-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.16-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.17-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.18-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.19-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.20-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.21-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.22-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.23-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.24-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.25-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.26-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.27-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.28-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.29-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.30-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.31-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.32-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.33-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.34-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.35-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.36-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.37-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.38-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.39-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.39.1-ReleaseNotes.gz
/usr/share/doc/util-linux/releases/v2.39.2-ReleaseNotes
/usr/share/doc/util-linux/releases/v2.39.3-ReleaseNotes.gz
/usr/share/lintian/overrides/util-linux
/usr/share/man/man1/choom.1.gz
/usr/share/man/man1/chrt.1.gz
/usr/share/man/man1/dmesg.1.gz
/usr/share/man/man1/fallocate.1.gz
/usr/share/man/man1/flock.1.gz
/usr/share/man/man1/getopt.1.gz
/usr/share/man/man1/hardlink.1.gz
/usr/share/man/man1/ionice.1.gz
/usr/share/man/man1/ipcmk.1.gz
/usr/share/man/man1/ipcrm.1.gz
/usr/share/man/man1/ipcs.1.gz
/usr/share/man/man1/last.1.gz
/usr/share/man/man1/lastb.1.gz
/usr/share/man/man1/lscpu.1.gz
/usr/share/man/man1/lsipc.1.gz
/usr/share/man/man1/lslogins.1.gz
/usr/share/man/man1/lsmem.1.gz
/usr/share/man/man1/mcookie.1.gz
/usr/share/man/man1/mesg.1.gz
/usr/share/man/man1/more.1.gz
/usr/share/man/man1/mountpoint.1.gz
/usr/share/man/man1/namei.1.gz
/usr/share/man/man1/nsenter.1.gz
/usr/share/man/man1/prlimit.1.gz
/usr/share/man/man1/rename.ul.1.gz
/usr/share/man/man1/rev.1.gz
/usr/share/man/man1/runuser.1.gz
/usr/share/man/man1/setpriv.1.gz
/usr/share/man/man1/setsid.1.gz
/usr/share/man/man1/setterm.1.gz
/usr/share/man/man1/su.1.gz
/usr/share/man/man1/taskset.1.gz
/usr/share/man/man1/uclampset.1.gz
/usr/share/man/man1/unshare.1.gz
/usr/share/man/man1/utmpdump.1.gz
/usr/share/man/man1/whereis.1.gz
/usr/share/man/man5/adjtime_config.5.gz
/usr/share/man/man5/terminal-colors.d.5.gz
/usr/share/man/man8/addpart.8.gz
/usr/share/man/man8/agetty.8.gz
/usr/share/man/man8/blkdiscard.8.gz
/usr/share/man/man8/blkid.8.gz
/usr/share/man/man8/blkzone.8.gz
/usr/share/man/man8/blockdev.8.gz
/usr/share/man/man8/chcpu.8.gz
/usr/share/man/man8/chmem.8.gz
/usr/share/man/man8/ctrlaltdel.8.gz
/usr/share/man/man8/delpart.8.gz
/usr/share/man/man8/findfs.8.gz
/usr/share/man/man8/findmnt.8.gz
/usr/share/man/man8/fsck.8.gz
/usr/share/man/man8/fsck.cramfs.8.gz
/usr/share/man/man8/fsck.minix.8.gz
/usr/share/man/man8/fsfreeze.8.gz
/usr/share/man/man8/fstrim.8.gz
/usr/share/man/man8/getty.8.gz
/usr/share/man/man8/i386.8.gz
/usr/share/man/man8/isosize.8.gz
/usr/share/man/man8/ldattach.8.gz
/usr/share/man/man8/linux32.8.gz
/usr/share/man/man8/linux64.8.gz
/usr/share/man/man8/lsblk.8.gz
/usr/share/man/man8/lslocks.8.gz
/usr/share/man/man8/lsns.8.gz
/usr/share/man/man8/mkfs.8.gz
/usr/share/man/man8/mkfs.bfs.8.gz
/usr/share/man/man8/mkfs.cramfs.8.gz
/usr/share/man/man8/mkfs.minix.8.gz
/usr/share/man/man8/mkswap.8.gz
/usr/share/man/man8/partx.8.gz
/usr/share/man/man8/pivot_root.8.gz
/usr/share/man/man8/readprofile.8.gz
/usr/share/man/man8/resizepart.8.gz
/usr/share/man/man8/rtcwake.8.gz
/usr/share/man/man8/setarch.8.gz
/usr/share/man/man8/sulogin.8.gz
/usr/share/man/man8/swaplabel.8.gz
/usr/share/man/man8/switch_root.8.gz
/usr/share/man/man8/wdctl.8.gz
/usr/share/man/man8/wipefs.8.gz
/usr/share/man/man8/zramctl.8.gz
/usr/share/util-linux/logcheck/ignore.d.server/util-linux

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/util-linux/filelist)

[Deutsch](/de/noble/util-linux/filelist)

[suomi](/fi/noble/util-linux/filelist)

[fran&ccedil;ais](/fr/noble/util-linux/filelist)

[magyar](/hu/noble/util-linux/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/util-linux/filelist)

[Nederlands](/nl/noble/util-linux/filelist)

[polski](/pl/noble/util-linux/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/util-linux/filelist)

[slovensky](/sk/noble/util-linux/filelist)

[svenska](/sv/noble/util-linux/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/util-linux/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/util-linux/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/util-linux/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/util-linux/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).