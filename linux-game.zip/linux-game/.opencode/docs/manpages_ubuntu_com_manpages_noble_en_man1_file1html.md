# Ubuntu Manpage: file - determine file type

> Source: https://manpages.ubuntu.com/manpages/noble/en/man1/file.1.html
> Cached: 2026-10-10T14:56:01.041Z

---

## [SYNOPSIS](#synopsis)

  
    `file`
    [`-bcdEhiklLNnprsSvzZ0`]
      [`--apple`]
      [`--exclude-quiet`]
      [`--extension`]
      [`--mime-encoding`]
      [`--mime-type`]
      [`-e`&#x00A0;testname]
      [`-F`&#x00A0;separator]
      [`-f`&#x00A0;namefile]
      [`-m`&#x00A0;magicfiles]
      [`-P`&#x00A0;name=value]&#x00A0;file
      ...
  

  
    `file`
    `-C` [`-m`
      magicfiles]
  

  
    `file`
    [`--help`]
  

## [DESCRIPTION](#description)

This manual page documents version 5.45 of the
    `file` command.
`file` tests each argument in an
    attempt to classify it. There are three sets of tests, performed in this
    order: filesystem tests, magic tests, and language tests. The
    [*first*](#first) test that
    succeeds causes the file type to be printed.
The type printed will usually contain one of the words
    [*text*](#text) (the file
    contains only printing characters and a few common control characters and is
    probably safe to read on an `ASCII` terminal),
    [*executable*](#executable)
    (the file contains the result of compiling a program in a form
    understandable to some UNIX kernel or another), or
    [*data*](#data)
    meaning anything else (data is usually &#x201C;binary&#x201D; or
    non-printable). Exceptions are well-known file formats (core files, tar
    archives) that are known to contain binary data. When modifying magic files
    or the program itself, make sure to
    preserve
    these keywords. Users depend on knowing that all the readable files
    in a directory have the word &#x201C;text&#x201D; printed. Don't do as
    Berkeley did and change &#x201C;shell commands text&#x201D; to &#x201C;shell
    script&#x201D;.
The filesystem tests are based on examining the return from a
    [stat(2)](/manpages/noble/man2/stat.2.html) system call. The program checks to see if the file
    is empty, or if it's some sort of special file. Any known file types
    appropriate to the system you are running on (sockets, symbolic links, or
    named pipes (FIFOs) on those systems that implement them) are intuited if
    they are defined in the system header file
    `<sys/stat.h>`.
The magic tests are used to check for files with data in
    particular fixed formats. The canonical example of this is a binary
    executable (compiled program) `a.out` file, whose
    format is defined in
    `<elf.h>`,
    `<a.out.h>` and possibly
    `<exec.h>` in the standard
    include directory. These files have a &#x201C;magic number&#x201D; stored in
    a particular place near the beginning of the file that tells the UNIX
    operating system that the file is a binary executable, and which of several
    types thereof. The concept of a &#x201C;magic number&#x201D; has been
    applied by extension to data files. Any file with some invariant identifier
    at a small fixed offset into the file can usually be described in this way.
    The information identifying these files is read from /etc/magic and the
    compiled magic file /usr/share/misc/magic.mgc, or
    the files in the directory /usr/share/misc/magic if
    the compiled file does not exist. In addition, if
    $HOME/.magic.mgc or
    $HOME/.magic exists, it will be used in preference
    to the system magic files.
If a file does not match any of the entries in the magic file, it
    is examined to see if it seems to be a text file. ASCII, ISO-8859-x, non-ISO
    8-bit extended-ASCII character sets (such as those used on Macintosh and IBM
    PC systems), UTF-8-encoded Unicode, UTF-16-encoded Unicode, and EBCDIC
    character sets can be distinguished by the different ranges and sequences of
    bytes that constitute printable text in each set. If a file passes any of
    these tests, its character set is reported. ASCII, ISO-8859-x, UTF-8, and
    extended-ASCII files are identified as &#x201C;text&#x201D; because they
    will be mostly readable on nearly any terminal; UTF-16 and EBCDIC are only
    &#x201C;character data&#x201D; because, while they contain text, it is text
    that will require translation before it can be read. In addition,
    `file` will attempt to determine other characteristics
    of text-type files. If the lines of a file are terminated by CR, CRLF, or
    NEL, instead of the Unix-standard LF, this will be reported. Files that
    contain embedded escape sequences or overstriking will also be
  identified.
Once `file` has determined the
    character set used in a text-type file, it will attempt to determine in what
    language the file is written. The language tests look for particular strings
    (cf. `<names.h>`) that can
    appear anywhere in the first few blocks of a file. For example, the keyword
    [*.br*](#.br) indicates that
    the file is most likely a [troff(1)](/manpages/noble/man1/troff.1.html) input file, just as the
    keyword
    [*struct*](#struct)
    indicates a C program. These tests are less reliable than the previous two
    groups, so they are performed last. The language test routines also test for
    some miscellany (such as [tar(1)](/manpages/noble/man1/tar.1.html) archives, JSON files).
Any file that cannot be identified as having been written in any
    of the character sets listed above is simply said to be
    &#x201C;data&#x201D;.

## [OPTIONS](#options)

  [`--apple`](#apple)
  Causes the `file` command to output the file type
      and creator code as used by older MacOS versions. The code consists of
      eight letters, the first describing the file type, the latter the creator.
      This option works properly only for file formats that have the apple-style
      output defined.
  [`-b`](#b),
    `--brief`
  Do not prepend filenames to output lines (brief mode).
  [`-C`](#C),
    `--compile`
  Write a magic.mgc output file that contains a
      pre-parsed version of the magic file or directory.
  [`-c`](#c),
    `--checking-printout`
  Cause a checking printout of the parsed form of the magic file. This is
      usually used in conjunction with the `-m` option to
      debug a new magic file before installing it.
  [`-d`](#d)
  Prints internal debugging information to stderr.
  [`-E`](#E)
  On filesystem errors (file not found etc), instead of handling the error
      as regular output as POSIX mandates and keep going, issue an error message
      and exit.
  [`-e`](#e),
    `--exclude` testname
  Exclude the test named in testname from the list of
      tests made to determine the file type. Valid test names are:
    
      apptype
      [`EMX`](#EMX)
          application type (only on EMX).
      ascii
      Various types of text files (this test will try to guess the text
          encoding, irrespective of the setting of the &#x2018;encoding&#x2019;
          option).
      encoding
      Different text encodings for soft magic tests.
      tokens
      Ignored for backwards compatibility.
      cdf
      Prints details of Compound Document Files.
      compress
      Checks for, and looks inside, compressed files.
      csv
      Checks Comma Separated Value files.
      elf
      Prints ELF file details, provided soft magic tests are enabled and the
          elf magic is found.
      json
      Examines JSON (RFC-7159) files by parsing them for compliance.
      soft
      Consults magic files.
      simh
      Examines SIMH tape files.
      tar
      Examines tar files by verifying the checksum of the 512 byte tar
          header. Excluding this test can provide more detailed content
          description by using the soft magic method.
      text
      A synonym for &#x2018;ascii&#x2019;.
    
  
  [`--exclude-quiet`](#exclude-quiet)
  Like `--exclude` but ignore tests that
      `file` does not know about. This is intended for
      compatibility with older versions of `file`.
  [`--extension`](#extension)
  Print a slash-separated list of valid extensions for the file type
    found.
  [`-F`](#F),
    `--separator` separator
  Use the specified string as the separator between the filename and the
      file result returned. Defaults to &#x2018;:&#x2019;.
  [`-f`](#f),
    `--files-from` namefile
  Read the names of the files to be examined from
      namefile (one per line) before the argument list.
      Either namefile or at least one filename argument
      must be present; to test the standard input, use &#x2018;-&#x2019; as a
      filename argument. Please note that namefile is
      unwrapped and the enclosed filenames are processed when this option is
      encountered and before any further options processing is done. This allows
      one to process multiple lists of files with different command line
      arguments on the same `file` invocation. Thus if you
      want to set the delimiter, you need to do it before you specify the list
      of files, like: &#x201C;`-F` @
      `-f` namefile&#x201D;, instead
      of: &#x201C;`-f` namefile
      `-F` @&#x201D;.
  [`-h`](#h),
    `--no-dereference`
  This option causes symlinks not to be followed (on systems that support
      symbolic links). This is the default if the environment variable
      `POSIXLY_CORRECT` is not defined.
  [`-i`](#i),
    `--mime`
  Causes the `file` command to output mime type
      strings rather than the more traditional human readable ones. Thus it may
      say &#x2018;text/plain; charset=us-ascii&#x2019; rather than &#x201C;ASCII
      text&#x201D;.
  [`--mime-type`](#mime-type),
    `--mime-encoding`
  Like `-i`, but print only the specified
    element(s).
  [`-k`](#k),
    `--keep-going`
  Don't stop at the first match, keep going. Subsequent matches will be have
      the string &#x2018;\012- &#x2019; prepended. (If you want a newline, see
      the `-r` option.) The magic pattern with the highest
      strength (see the `-l` option) comes first.
  [`-l`](#l),
    `--list`
  Shows a list of patterns and their strength sorted descending by
      [magic(5)](/manpages/noble/man5/magic.5.html) strength which is used for the matching (see
      also the `-k` option).
  [`-L`](#L),
    `--dereference`
  This option causes symlinks to be followed, as the like-named option in
      [ls(1)](/manpages/noble/man1/ls.1.html) (on systems that support symbolic links). This is
      the default if the environment variable
      `POSIXLY_CORRECT` is defined.
  [`-m`](#m),
    `--magic-file` magicfiles
  Specify an alternate list of files and directories containing magic. This
      can be a single item, or a colon-separated list. If a compiled magic file
      is found alongside a file or directory, it will be used instead.
  [`-N`](#N),
    `--no-pad`
  Don't pad filenames so that they align in the output.
  [`-n`](#n),
    `--no-buffer`
  Force stdout to be flushed after checking each file. This is only useful
      if checking a list of files. It is intended to be used by programs that
      want filetype output from a pipe.
  [`-p`](#p),
    `--preserve-date`
  On systems that support [utime(3)](/manpages/noble/man3/utime.3.html) or
      [utimes(2)](/manpages/noble/man2/utimes.2.html), attempt to preserve the access time of files
      analyzed, to pretend that `file` never read
    them.
  [`-P`](#P),
    `--parameter` name=value
  Set various parameter limits.
    
      
        [**Name**](#Name)
        [**Default**](#Default)
        [**Explanation**](#Explanation)
      
      
        [`bytes`](#bytes)
        1M
        max number of bytes to read from file
      
      
        [`elf_notes`](#elf_notes)
        256
        max ELF notes processed
      
      
        [`elf_phnum`](#elf_phnum)
        2K
        max ELF program sections processed
      
      
        [`elf_shnum`](#elf_shnum)
        32K
        max ELF sections processed
      
      
        [`elf_shsize`](#elf_shsize)
        128MB
        max ELF section size processed
      
      
        [`encoding`](#encoding)
        65K
        max number of bytes to determine encoding
      
      
        [`indir`](#indir)
        50
        recursion limit for indirect magic
      
      
        [`name`](#name)
        50
        use count limit for name/use magic
      
      
        [`regex`](#regex)
        8K
        length limit for regex searches
      
    
  
  [`-r`](#r),
    `--raw`
  Don't translate unprintable characters to \ooo. Normally
      `file` translates unprintable characters to their
      octal representation.
  [`-s`](#s),
    `--special-files`
  Normally, `file` only attempts to read and determine
      the type of argument files which [stat(2)](/manpages/noble/man2/stat.2.html) reports are
      ordinary files. This prevents problems, because reading special files may
      have peculiar consequences. Specifying the `-s`
      option causes `file` to also read argument files
      which are block or character special files. This is useful for determining
      the filesystem types of the data in raw disk partitions, which are block
      special files. This option also causes `file` to
      disregard the file size as reported by [stat(2)](/manpages/noble/man2/stat.2.html) since on
      some systems it reports a zero size for raw disk partitions.
  [`-S`](#S),
    `--no-sandbox`
  On systems where libseccomp
      (https://github.com/seccomp/libseccomp) is
      available, the `-S` option disables sandboxing which
      is enabled by default. This option is needed for
      `file` to execute external decompressing programs,
      i.e. when the `-z` option is specified and the
      built-in decompressors are not available. On systems where sandboxing is
      not available, this option has no effect.
    [*Note:*](#Note:)
        This Debian version of file was built without seccomp support, so this
        option has no effect.
  
  [`-v`](#v),
    `--version`
  Print the version of the program and exit.
  [`-z`](#z),
    `--uncompress`
  Try to look inside compressed files.
  [`-Z`](#Z),
    `--uncompress-noreport`
  Try to look inside compressed files, but report information about the
      contents only not the compression.
  [`-0`](#0),
    `--print0`
  Output a null character &#x2018;\0&#x2019; after the end of the filename.
      Nice to [cut(1)](/manpages/noble/man1/cut.1.html) the output. This does not affect the
      separator, which is still printed.
    If this option is repeated more than once, then
        `file` prints just the filename followed by a NUL
        followed by the description (or ERROR: text) followed by a second NUL
        for each entry.
  
  [`--help`](#help)
  Print a help message and exit.

## [ENVIRONMENT](#environment)

The environment variable `MAGIC` can be used
    to set the default magic file name. If that variable is set, then
    `file` will not attempt to open
    $HOME/.magic. `file` adds
    &#x201C;.mgc&#x201D; to the value of this variable
    as appropriate. The environment variable
    `POSIXLY_CORRECT` controls (on systems that support
    symbolic links), whether `file` will attempt to follow

... [Content truncated]