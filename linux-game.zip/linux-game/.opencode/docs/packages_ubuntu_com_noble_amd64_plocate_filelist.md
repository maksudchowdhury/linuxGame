# Ubuntu – File list of package plocate/noble/amd64

> Source: https://packages.ubuntu.com/noble/amd64/plocate/filelist
> Cached: 2026-10-10T15:02:24.397Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/amd64/) 

 » [plocate](/noble/plocate) 

 » [amd64](/noble/amd64/plocate) 

 » File list 

 

  # File list of package *plocate* in *noble* of architecture *amd64*

/etc/cron.daily/plocate
/etc/updatedb.conf
/usr/bin/plocate
/usr/lib/systemd/system/plocate-updatedb.service
/usr/lib/systemd/system/plocate-updatedb.timer
/usr/sbin/plocate-build
/usr/sbin/updatedb.plocate
/usr/share/doc/plocate/changelog.Debian.gz
/usr/share/doc/plocate/copyright
/usr/share/man/man1/plocate.1.gz
/usr/share/man/man5/updatedb.conf.5.gz
/usr/share/man/man8/plocate-build.8.gz
/usr/share/man/man8/updatedb.plocate.8.gz
/var/lib/plocate/CACHEDIR.TAG

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/amd64/plocate/filelist)

[Deutsch](/de/noble/amd64/plocate/filelist)

[suomi](/fi/noble/amd64/plocate/filelist)

[fran&ccedil;ais](/fr/noble/amd64/plocate/filelist)

[magyar](/hu/noble/amd64/plocate/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/amd64/plocate/filelist)

[Nederlands](/nl/noble/amd64/plocate/filelist)

[polski](/pl/noble/amd64/plocate/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/amd64/plocate/filelist)

[slovensky](/sk/noble/amd64/plocate/filelist)

[svenska](/sv/noble/amd64/plocate/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/amd64/plocate/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/amd64/plocate/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/amd64/plocate/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/amd64/plocate/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).