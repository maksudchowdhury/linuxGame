# Ubuntu – File list of package zip/noble/i386

> Source: https://packages.ubuntu.com/noble/zip/filelist
> Cached: 2026-10-10T15:02:37.424Z

---

[ packages](/)

        Skip
             to content

     

 » [Ubuntu](https://www.ubuntu.com/)
 » [Packages](/)

 » [noble](/noble/) 

 » [zip](/noble/zip) 

 » [i386](/noble/zip) 

 » File list 

 

  # File list of package *zip* in *noble* of architecture *i386*

/usr/bin/zip
/usr/bin/zipcloak
/usr/bin/zipnote
/usr/bin/zipsplit
/usr/share/doc/zip/TODO
/usr/share/doc/zip/WHATSNEW
/usr/share/doc/zip/changelog.Debian.gz
/usr/share/doc/zip/changelog.gz
/usr/share/doc/zip/copyright
/usr/share/man/man1/zip.1.gz
/usr/share/man/man1/zipcloak.1.gz
/usr/share/man/man1/zipnote.1.gz
/usr/share/man/man1/zipsplit.1.gz

 
 

This page is also available in the following languages:

[&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; (B&#601;lgarski)](/bg/noble/zip/filelist)

[Deutsch](/de/noble/zip/filelist)

[suomi](/fi/noble/zip/filelist)

[fran&ccedil;ais](/fr/noble/zip/filelist)

[magyar](/hu/noble/zip/filelist)

[&#26085;&#26412;&#35486; (Nihongo)](/ja/noble/zip/filelist)

[Nederlands](/nl/noble/zip/filelist)

[polski](/pl/noble/zip/filelist)

[&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russkij)](/ru/noble/zip/filelist)

[slovensky](/sk/noble/zip/filelist)

[svenska](/sv/noble/zip/filelist)

[T&uuml;rk&ccedil;e](/tr/noble/zip/filelist)

[&#1091;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072; (ukrajins'ka)](/uk/noble/zip/filelist)

[&#20013;&#25991; (Zhongwen,&#31616;)](/zh-cn/noble/zip/filelist)

[&#20013;&#25991; (Zhongwen,&#32321;)](/zh-tw/noble/zip/filelist)

Content Copyright &copy; 2026 [Canonical Ltd.](https://www.canonical.com/); See [license terms](https://www.ubuntu.com/legal). Ubuntu is a [trademark](https://www.ubuntu.com/aboutus/trademarkpolicy) of Canonical Ltd.
 [Learn more about this site](/about/).

[Report a bug on this site](https://bugs.launchpad.net/pkg-website/+filebug).