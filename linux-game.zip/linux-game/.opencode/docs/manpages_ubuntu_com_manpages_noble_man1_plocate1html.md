# Ubuntu Manpage: plocate - find files by name, quickly

> Source: https://manpages.ubuntu.com/manpages/noble/man1/plocate.1.html
> Cached: 2026-10-10T15:02:01.908Z

---

## [SYNOPSIS](#synopsis)

**plocate** *[OPTION]...* *PATTERN...*

## [DESCRIPTION](#description)

**plocate** finds all files on the system matching the given
    pattern (or all of the patterns if multiple are given). It does this by
    means of an index made by [**updatedb**(8)](/manpages/noble/man8/updatedb.8.html) or (less commonly) converted
    from another index by [**plocate-build**(8)](/manpages/noble/man8/plocate-build.8.html).
plocate is largely argument-compatible with [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html), but
    is significantly faster. In particular, it rarely needs to scan through its
    entire database, unless the pattern is very short (less than three bytes) or
    you want to search for a regular expression. It does not try to maintain
    compatibility with BSD locate, or non-UTF-8 filenames and locales. Most I/O
    is done asynchronously, but the results are synchronized so that output
    comes in the same order every time.
When multiple patterns are given, **plocate** will search for
    files that match *all* of them. This is the main incompatibility with
    [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html), which searches for files that match one or more patterns,
    unless the -A option is given.
By default, patterns are taken to be substrings to search for. If
    at least one non-escaped globbing metacharacter (*, ? or []) is given, that
    pattern is instead taken to be a glob pattern (which means it needs to start
    and end in * for a substring match). If **--regexp** is given, patterns
    are instead taken to be (non-anchored) POSIX basic regular expressions, and
    if **--regex** is given, patterns are taken to be POSIX extended regular
    expressions. All of this matches [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html) behavior.
Like [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html), **plocate** shows all files visible to
    the calling user (by virtue of having read and execute permissions on all
    parent directories), and none that are not, by means of running with the
    setgid bit set to access the index (which is built as root), but by testing
    visibility as the calling user.

EXIT
  STATUS
**plocate** exits with 0 to indicate that a match was found or
    that **--help** or **--version** were passed. Otherwise,
    **plocate** exits with status code 1, indicating that an error occurred
    or that no matches were found.

## [OPTIONS](#options)

  [**-A**, **--all**](#A)
  Ignored for compatibility with [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html).
    

  
  **-b**,
    **--basename**
  Match only against the file name portion of the path name, ie., the
      directory names will be excluded from the match (but still printed). This
      does not speed up the search, but can suppress uninteresting matches.
    

  
  [**-c**, **--count**](#c)
  Do not print each match. Instead, count them, and print out a total number
      at the end.
    

  
  **-d**, **--database**
    *DBPATH*
  Find matches in the given database, instead of
      **/var/lib/plocate/plocate.db**. This argument can be given multiple
      times, to search multiple databases. It is also possible to give multiple
      databases in one argument, separated by **:**. (Any character,
      including : and \, can be escaped by prepending a \.)
    

  
  **-e**,
    **--existing**
  Print only entries that refer to files existing at the time **locate**
      is run. Note that unlike [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html), symlinks are not followed by
      default (and indeed, there is no option to change this).
    

  
  **-i**,
    **--ignore-case**
  Do a case-insensitive match as given by the current locale (default is
      case-sensitive, byte-by-byte match). Note that **plocate** does not
      support the full range of Unicode case folding rules; in particular,
      searching for *&#x00DF;* will not give you matches on *ss* even
      in a German locale. Also note that this option will be somewhat slower
      than a case-sensitive match, since it needs to generate more candidates
      for searching the index.
    

  
  **-p**,
    **--ignore-spaces**
  Ignore punctuation and spaces when matching patterns.
    

  
  **-l**, **--limit**
    *LIMIT*
  Stop searching after *LIMIT* matches have been found. If
      **--count** is given, the number printed out will be at most
      *LIMIT*.
    

  
  [**-N**, **--literal**](#N)
  Print entry names without quoting. Normally, **plocate** will escape
      special characters in filenames, so that they are safe for consumption by
      typical shells (similar to the GNU coreutils *shell-escape-always*
      quoting style), unless printing to a pipe, but this options will turn off
      such quoting.
    

  
  **-0**, **--null**
  Instead of writing a newline after every match, write a NUL (ASCII 0).
      This is useful for creating unambiguous output when it is to be processed
      by other tools (like [**xargs**(1)](/manpages/noble/man1/xargs.1.html)), as filenames are allowed to contain
      embedded newlines.
    

  
  [**-r**, **--regexp**](#r)
  Patterns are taken to be POSIX basic regular expressions. See
      [**regex**(7)](/manpages/noble/man7/regex.7.html) for more information. Note that this forces a linear scan
      through the entire database, which is slow.
    

  
  [**--regex**](#regex)
  Like **--regexp**, but patterns are instead taken to be POSIX
      *extended* regular expressions.
    

  
  **-w**,
    **--wholename**
  Match against the entire path name. This is the default, so unless
      **-b** is given first (see above), it will not do anything. This option
      thus exists only as compatibility with [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html).
    

  
  [**--help**](#help)
  Print out usage information, then exit successfully.
    

  
  [**--version**](#version)
  Print out version information, then exit successfully.
    

  

## [ENVIRONMENT](#environment)

  [**LOCATE_PATH**](#LOCATE_PATH)
  If given, appended after the list of **--database** paths (whether an
      explicit is given or the default is used). Colon-delimiting and character
      escaping follows the same rules as for **--database**.
    

  

## [AUTHOR](#author)

Steinar H. Gunderson <steinar+plocate@gunderson.no>

SEE
  ALSO
[**plocate-build**(8)](/manpages/noble/man8/plocate-build.8.html), [**mlocate**(1)](/manpages/noble/man1/mlocate.1.html), [**updatedb**(8)](/manpages/noble/man8/updatedb.8.html)