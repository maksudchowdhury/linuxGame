# Mission: Nimbus Casebook — full offline Linux detective-CTF trainer

## M1: Phase 0 — audit & baseline | status: completed
- [x] S0.1: Full repo audit → docs/PHASE0_AUDIT.md (11 defects fixed, 6 risks, 10 assumptions)
- [x] S0.2: Test harness green (21/21 + PAM check, both containers healthy)
- [x] S0.3: README/CHANGELOG/.gitattributes updated, git history clean

## M2: Phase 1 — schema, commands, points | status: content-complete (validator OK 22:03; Reviewer sign-off pending)
### T2.1: Docs & schemas | agent:Commander
- [x] S2.1.1: docs/AUTHORING.md (levels.yaml/interactive/labs schema + contracts)
- [x] S2.1.2: docs/STORY_BIBLE.md (48 levels + 6 puzzles + 5 labs outline)
- [x] S2.1.3: docs/API_CONTRACT.md (server↔dashboard JSON shapes)
- [x] S2.1.4: .opencode/context.md + work-log.md project state

### T2.2: Command chips library (150 cmds) | agent:Commander
- [x] S2.2.1: shard1 file/nav/text (33) → commands/_shard1.yaml — Reviewer verified: kinds (builtin 5/binary 28 match container), runtime image 33/33, 33/33 ≥3 safe examples, 0 dict-mistakes (record: normalize-shards-1-3-4.md)
- [x] S2.2.4: shard4 perms/proc/sys/network/packages (32) → commands/_shard4.yaml — Reviewer PASS 07:20 (ses_s8t): SYNC-7/SYNC-1 previously fixed; SYNC-8 cleared — 15 chips re-authored to 3 distinct RC-0-verified safe examples each (man-literacy for lab, --help/-V/whatis for image); 0 <3-safe, 0 dup-safe, 0 hazard, enums clean
- [x] S2.2.2: shard2 search/text-fu (33) → commands/_shard2.yaml — Reviewer PASS 07:20 (ses_s8t): SYNC-7 fixed earlier; SYNC-8 residual (join) audited — already 3 distinct safe examples; 0 <3-safe, 0 dup-safe across all 33
- [x] S2.2.3: shard3 system/process (29) → commands/_shard3.yaml — Reviewer PASS 07:20 (ses_s8t): kill kind/runtime/options previously fixed; SYNC-8 cleared — 6 chips (uname/free/fg/nohup/nice/tmux) re-authored to 3 distinct RC-0 safe examples; 0 <3-safe, 0 dup-safe, 0 hazard
- [x] S2.2.5: shard5 shell/archive (23) → commands/_shard5.yaml — Reviewer PASS 22:04: 0 dict-mistakes, 0 <3-safe, enum/keys clean; record shard5-rework.md (container RC 3/3); merged at 150-union
- [x] S2.2.6: Merge shards → commands/commands.yaml (150 cmds) + validate + coverage — Reviewer PASS 07:20 (ses_s8t): re-merged from clean shards; parity exact (150=union, 0 missing/extra), master 149 covered + ssh-keygen, merge idempotent (SHA256 identical on re-run), VALIDATION OK; no SYNC-8 inheritance

### T2.3: Secrets & validation tooling | agent:Commander
- [x] S2.3.1: tools/gen_secrets.py → game/secrets.yaml (id0=begin, others 16-char alnum) — ran, 48 passwords written
- [x] S2.3.2: tools/validate_levels.py (structure, chips exist, act gates, pw chain, budgets, coverage) — authored, VALIDATION OK on merged levels.yaml

### T2.4: Level content | agent:Commander
- [x] S2.4.1: Act 1 L0–L8 — simulate_chain --act 1 → 9/9 PASS
- [x] S2.4.2: Act 2 L9–L18 — fixed by Commander 07:30 (solutions L9/10/13/16/18 + L18 verify) → 10/10 PASS
- [x] S2.4.3: Act 3 L19–L25 — fixed by Commander 07:38 (L21 custody.txt, L25 report+room_key) → 7/7 PASS
- [x] S2.4.4: Act 4 L26–L36 — 11/11 PASS (no changes needed)
- [x] S2.4.5: Act 5 L37–L47 — re-authored by Commander 07:30/07:38 (37–46 extract hidden files, L47 no-tmux) → 11/11 PASS
- [x] S2.4.6: Merge + gates — FULL SIM 48/48 PASS 07:39; validate_levels.py → VALIDATION OK; solutionbook 48+5

### T2.5: Dashboard UI | agent:Commander
- [x] S2.5.1: game/index.html full rewrite (case file, chips, casebook, puzzles, export, a11y) — Reviewer PASS 08:22: file is a COMPLETE 1415-line/36.8KB dashboard, not a stub. JS syntax OK (node --check); all 10 API endpoints wired; all 12 /api/state fields consumed; sections present (levelGrid=case file, drawer=command chips, casebook, puzzleGrid, labGrid, exportBtn, deduction+boardSec=finale board, actBar); a11y present (aria-live, 15 aria-label, role=, skip link, lang=). No rewrite needed.

### T2.6: Fix round completion | agent:Commander
- [x] FIX-S1a: Re-author Act 1 — DONE & Reviewer-verified 07:18 (solutions/_act1.yaml re-authored 72 lines; independent probe 9/9 incl. L7/L8 verify; merge+validator green; SYNC-11 CLEARED; record .opencode/unit-tests/2026-10-11-solutions_act1-rework.md)
- [x] FIX-S1b: Re-author Act 2 — DONE (levels+solutions written, validated)
- [x] FIX-S1c: Re-author Act 3 — DONE (stories replaced, validated)
- [x] FIX-S2a: Re-author Act 4 — DONE (levels+labs+solutions written, validated)
- [x] FIX-S2b: Re-author Act 5 — DONE (levels+lab+solutions written, validated)
- [x] FIX-S3: tools/gen_secrets.py + tools/validate_levels.py + game/secrets.yaml — DONE (gen ran, validator green)
- [x] FIX-S4: linuxgame/game/index.html full rewrite — DONE (same as S2.5.1; already complete, verified 08:22)
- [x] FIX-S5: commands/_shard5.yaml (24 cmds) — DONE (authored, merged, validated)

## M3: Phase 4 — server & lab engine | status: completed
- [x] S3.1: game/server.py rework — Reviewer PASS 07:28: 30468 B/939 LF, isolated 16/16 re-run green (record 2026-10-11-server_rework.md), AST 10 paths/11 branches match API_CONTRACT, sshpass -e env-only, no shell=True/debug prints, payloads secret-free, base_test POST /api/hint confirmed; minor non-blockers logged in work-log (unclosed file L434, dead var L460, ssh-block dup L714); docker-build runtime check pending M5
- [x] S3.2: game/setup.py + mark.sh + entrypoint.sh — **Reviewer PASS 08:20**: SYNC-10 round-2 FIXED (setup.py file-based child I/O + SETUP_TIMEOUT + killpg; L24 stages start_listener.sh + null-fd backgrounded writer). Repro test setup.isolated 2/2 (deadlock clean 0.0s, runaway killed 2.0s); act3 7/7; FULL sim 48/48; validate OK; **validator docker build exit 0, BUILDCHECK OK 53/53** (record 2026-10-11-setup-deadlock-L24-fix.md). SYNC-15 also fixed (base_test reads secrets.yaml; tester COPYs it). SYNC-10 CLEARED.
- [x] S3.3: Dockerfile + compose — validator stage GREEN (exit 0, 53/53): game+lab setup both run in validator so _buildcheck lab checks pass (intern `-G sudo`+pw learn). 5 stages (base/game/validator/labbuild/lab); compose build verified separately under S5.1.

## M4: Phase 5 — test suites | status: completed
- [x] S4.1: pragmatic combined suite `tests/e2e_suite.py` — **Commander-run 08:58: 41/41 PASS exit 0**: API smoke+abuse (locked 403, bad n 400, oversized body, traversal), secrets-leak HTTP sweep (no pw in any response), L0–L7 solve flow through REAL ssh grader (verify pass + points + ~/.cleared staging + replay=0), PAM walk to L19, hint economics (cost deducted), isolation (homes 700, cross-user read denied, loopback-only peers), offline statics (no external assets/outbound calls), labverify first-users ok, reset guardrail. (Solve-all = validator BUILDCHECK 53/53; examples-run = shard container checks.)
- [x] S4.2: Existing base suite still green (21/21 + PAM) — Reviewer PASS 08:39: 21/21 + host PAM, exit 0. Fixed a real Dockerfile bug found en route: progress file was root:root 640 so the gameserver process couldn't read it (reached() silently returned 0, "reached stays 1" failed). Now chown root:gameserver /var/lib/game/progress. Also SYNC-15 (secrets.yaml) verified working in-container.

## M5: Phase 6 — build & fix loop | status: completed
- [x] S5.1: compose build exit 0 (linux-game + linux-lab); full loop green 08:58: validator build exit 0 (BUILDCHECK 53/53), base test 21/21+PAM, e2e 41/41; runtime images verified free of solutions/solutionbook/_buildcheck (docker run find = clean).

## M6: Phase 7 — docs, export, final verification | status: completed
- [x] S6.1: README.txt expanded (game overview, progression/how keys work, e2e test line, docs pointers); CHANGELOG entry for Phases 1–7
- [x] S6.2: Export bundle = build.bat (images tar + compose + debs pendrive) unchanged and builds; /api/export exercised 200 in e2e
- [x] S6.3: FULL SYSTEM VERIFICATION — Commander-direct (Reviewer agent infra-failure: 3 corrupted outputs, ~10s no-tool-call each; substituted full tool-based evidence). Post-reboot fresh runs ALL GREEN: validate_levels VALIDATION OK; simulate_chain 48/48; base test 21/21+PAM exit 0; e2e_suite 41/41 exit 0; solve_all ALL CHECKS PASSED (validator rebuild exit 0, BUILDCHECK 53/53); abuse 23/23; offline 17/17; secrets_leak 12/12 (lockdown, /proc, logs, scores, image env+history all secret-free); runtime images contain no solutionbook/_buildcheck//opt/solutions; LF CRLF=0 in key files; secrets.yaml untracked+gitignored. FINAL REPORT delivered 09:18.
- [x] S6.4: per-level reset feature (user-requested) - setup.py `--target game --level N` wipes one level home + re-provisions (progress/scores untouched); Dockerfile lab banner corrected (recreate not restart); README+CHANGELOG updated. Commander-direct gates ALL GREEN: reset.isolated 4/4 host+container; setup.isolated 2/2; validator rebuild exit 0 BUILDCHECK 53/53; compose build exit 0; container smoke 8/8 (level3 evidence restored, junk removed, owner 700, progress untouched, --level 99 rc2, --target lab --level 0 rc2); base 21/21+PAM; e2e 42/42 (isolation check fixed: host loopback-binding + gateway-aware peers after Chrome dashboard tab caused false flake); sim 48/48; validate OK.

