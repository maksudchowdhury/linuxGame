import yaml, sys
with open(r'E:\linux-game\linuxgame\game\levels.yaml') as f:
    d = yaml.safe_load(f)
levels = {lv['id']: lv for lv in d['levels']}
ids = [int(x) for x in sys.argv[1:]]
for i in ids:
    lv = levels[i]
    print('='*60)
    print('=== L%d id=%s user=%s type=%s' % (i, lv.get('id'), lv.get('user'), lv.get('type')))
    print('SETUP:')
    print(lv.get('setup',''))
    print('VERIFY:')
    print(lv.get('verify','') or '(none)')
