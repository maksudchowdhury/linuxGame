# UT-normalize — Unit test record: normalize shard1 kinds + shard3 runtime + shard4 add-apt-repository (task_5ce9e7bd, SYNC-1/2/5)

- Date: 2026-10-10T21:45
- Reviewer verification of the normalize unit; scope = the three assigned SYNC fixes only.
- Note: task_5ce9e7bd reported COMPLETED with "(No output)"; artifacts were verified directly
  on disk. shard4's fix landed via the terminal (Commander-as-worker) write at 21:34:07.

## Checks run (evidence)

1. **YAML parse gate** (workaround for broken lsp_diagnostics, SYNC-4):
   `_shard1.yaml` 33 entries OK · `_shard3.yaml` 29 OK · `_shard4.yaml` 31 OK.
2. **SYNC-5 / shard1 kinds**: pwd/cd/pushd/popd/dirs = `builtin`; counts builtin 5 + binary 28;
   runtime image 33/33. Container cross-check `docker exec linuxgame bash -lc 'type -t <cmd>'`
   for all 62 shard1+shard3 names: 0 missing, 51 file, 10 builtin, 1 keyword (`time` → builtin OK).
   **Residual mismatch: shard3 `kill` declared binary, `type -t` = builtin.**
3. **SYNC-2 / shard3 runtime**: 29/29 entries carry `runtime`, all `image`, enum-valid. 0 missing.
4. **SYNC-1 / shard4 add-apt-repository**: `runtime: lab` (was `theory`), kind binary,
   3 safe man-page-literacy examples (`man …|head -30`, `--help`, `whatis`).
   Runtime enum now image 21 / lab 10, 0 `theory` anywhere. Matches Commander decision 21:26.
   (Phase-4 Dockerfile must still install `software-properties-common` in LAB — tracked in todo M3/S3.3.)
5. **Contract sweeps** (all 3 shards): no external URLs in learn_more; learn_more = list of
   terminal lines; runtime/kind enums valid vs API_CONTRACT.md L49-52 (`kind: binary|builtin`,
   `group` optional, `runtime: image|lab`, learn_more array).
6. **Spot execution** (game container): first safe example of 12 shard1 cmds — 10/12 exit 0.
   2 "failures" are fixture-dependent (`mv /tmp/clue.txt …`, `rm -i /tmp/clue.txt` — need the
   examples_run fixture set + tty-skip list, tests/examples_run.py in M4). No content defect.
7. **Safe-example counts**: shard1 33/33 have ≥3 safe examples (original FAIL criterion fixed,
   was: cp 0/3 + 8 cmds <3).

## Defects found outside assigned scope, inside touched files (tracked, NOT fixed here)

- shard3 `kill`: kind binary → should be `builtin` (SYNC-5 residue, one-line fix).
- shard3: ~27/29 entries have <3 safe examples (opencode_prompt: "3 safe, copy-pasteable
  examples"); bg/fg 0/2, jobs/nohup/kill/killall 1/2, pkill 0/2 — blocks S2.2.3 completion.
- shard4: `mistakes` contains dict items (not strings) in apt-cache, dpkg, dig, rsync →
  violates API_CONTRACT `"mistakes":["..."]` — blocks S2.2.4 completion.

## Verdict

- shard1 normalization: **PASS**.
- shard3 runtime: **PASS** (SYNC-2 resolved).
- shard4 add-apt-repository: **PASS** (SYNC-1 shard-side resolved).
- S2.2.1 (shard1): all original defects resolved + this record → mark [x].
- S2.2.3 / S2.2.4: remain open with the residual lists above.

## Addendum 21:48 — re-verification after the 21:42–21:44 rework round

The terminal session rewrote all shards and produced the merge after this review's first
pass, so every scope claim was re-run against the CURRENT files:

- `_shard1.yaml` (48146 B @ 21:42:48): 33 entries; builtins still exactly
  pwd/cd/pushd/popd/dirs; runtime image 33/33; 0 enum violations; 0 dict-mistakes;
  0 cmds with <3 safe examples. **shard1 normalization still PASS.**
- `_shard3.yaml` (28670 B @ 21:44:33): runtime 29/29 image (SYNC-2 holds);
  `kill` kind STILL `binary` although `type -t kill` = builtin → SYNC-5 residue persists
  after two rework rounds (one-line fix, then re-merge).
- `_shard4.yaml` (46345 B @ 21:44:33): add-apt-repository runtime=lab with 3 safe
  man-literacy examples (SYNC-1 shard side holds); runtime enum lab 10 / image 21;
  BUT dict-mistakes persist in apt-cache, dpkg, dig, rsync (SYNC-7) and 21/31 cmds
  still have <3 safe examples.
- `commands/commands.yaml` (192008 B, 149 cmds) parses; it has INHERITED the kill=binary
  defect — re-merge required after the SYNC-5 fix.
- Systemic contract gap (opencode_prompt "3 safe, copy-pasteable examples"):
  shard2 12 cmds <3 + 6 dict-mistakes; shard3 27 cmds <3; shard4 21 cmds <3;
  shard5 2 cmds <3 + 3 dict-mistakes → recorded as SYNC-8, blocks S2.2.2/3/4/5 + S2.2.6.

## Final gate re-run 21:58–22:01 (unit-review round 2; files unchanged since 21:52:33)
- Consolidated contract gate: **10/10 PASS** — shard1 kinds/runtime image 33/33/≥3-safe/
  no-dict-mistakes; shard3 runtime 29/29 image/required-keys/options 2-5; shard4
  add-apt-repository runtime=lab/3-safe/enum-clean (31 entries).
- Container probe: 62/62 shard1+shard3 names present in `linuxgame` via `type -t`;
  kind ground truth re-confirms shard1 builtins 5/5 correct (pwd cd pushd popd dirs)
  and the shard3 `kill` residue (declared binary, container builtin → SYNC-5, plus
  `time` = keyword in container vs contract vocabulary binary|builtin — accepted as
  binary, no contract enum for keyword).
- `tests/run-base-test.ps1`: **20/21 — 1 FAIL** "dashboard shows welcome screen":
  base_test.py L128 asserts literal `Welcome to Nimbus Corp` in GET / html, but the
  rewritten index.html (56793 B @ 21:55:22) has 0 matches for Welcome/welcome
  (verified by grep) → recorded as SYNC-9 (dashboard rewrite regression; outside
  this unit's data scope, blocks green-suite gate).
- `_act4.yaml` transient parse break (line 336, unindented block in `setup: |`) seen
  at 21:57 was repaired by its worker at 22:00:06 (re-parses OK, 11 levels) — no
  issue retained.
- lsp_diagnostics: still unusable (SYNC-4); python yaml gates + container probes used.
- Verdict: **PASS** — assigned fixes (shard1 kinds / shard3 runtime / shard4
  add-apt-repository) all verified green on current files; residuals tracked in
  .opencode/sync-issues.md (SYNC-5/7/8/9).
