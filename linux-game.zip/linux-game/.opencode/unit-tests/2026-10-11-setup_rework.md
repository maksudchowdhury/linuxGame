# Unit Test Record: game/setup.py (+ entrypoint.sh, mark.sh gates)

## Session
ses_m3b (M3-B / SYNC-10 rework)

## Target Files
- `E:\linux-game\linuxgame\game\setup.py` (rework: secrets.yaml passwords, --target game|lab)
- `E:\linux-game\linuxgame\game\entrypoint.sh` (listener hooks added)
- `E:\linux-game\linuxgame\game\mark.sh` (POSIX sh, dedupe, create-if-absent, exit 0)

## Test File (DELETED)
`E:\linux-game\linuxgame\game\__tests__\setup.isolated.test.py`

## Test Code (Preserved)

```python
#!/usr/bin/env python3
"""ISOLATED unit test for linuxgame/game/setup.py (session ses_m3b, SYNC-10).

WARNING: THIS FILE WILL BE DELETED AFTER IT PASSES.
Test code preserved in: .opencode/unit-tests/2026-10-11-setup_rework.md

Imports ONLY setup.py. All external effects (subprocess, user lookup, state
dir, /home/intern) are mocked or redirected to a temp dir. No real users are
created, no real passwords are used.
"""
import contextlib
import importlib.util
import io
import os
import subprocess as real_subprocess
import tempfile
import unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
SETUP_PY = os.path.abspath(os.path.join(HERE, os.pardir, "setup.py"))

LEVELS_YAML = """version: 1
levels:
  - id: 0
    setup: 'echo hi > readme.txt'
  - id: 1
    setup: 'printf %s "$NEXT_PW" > .next'
  - id: 2
    setup: ''
  - id: 3
    setup: 'echo last > done.txt'
labs:
  - id: alpha-lab
    setup: 'echo lab > note.txt'
  - id: beta-lab
    title: no setup key
"""

SECRETS_YAML = """version: 1
passwords:
  0: begin
  1: aaaabbbbccccdddd
  2: eeeeffffgggghhhh
  3: iiiijjjjkkkkllll
"""

SECRET_VALUES = ["begin", "aaaabbbbccccdddd", "eeeeffffgggghhhh", "iiiijjjjkkkkllll"]


def load_module():
    spec = importlib.util.spec_from_file_location("setup_under_test", SETUP_PY)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class Call(object):
    def __init__(self, cmd, kwargs):
        self.cmd = list(cmd)
        self.kwargs = kwargs


class Recorder(object):
    def __init__(self, fail_on=None, stderr=""):
        self.calls = []
        self.fail_on = fail_on
        self.stderr = stderr

    def __call__(self, cmd, **kwargs):
        self.calls.append(Call(cmd, kwargs))
        if self.fail_on and self.fail_on in cmd[0]:
            raise real_subprocess.CalledProcessError(
                returncode=2, cmd=list(cmd), stderr=self.stderr)

        class R(object):
            returncode, stdout, stderr = 0, "", ""
        return R()

    def cmds(self):
        return [c.cmd for c in self.calls]


def write_fixture(tmp, with_secrets=True):
    levels = os.path.join(tmp, "levels.yaml")
    secrets = os.path.join(tmp, "secrets.yaml")
    with open(levels, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(LEVELS_YAML)
    if with_secrets:
        with open(secrets, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(SECRETS_YAML)
    env = {"LEVELS_PATH": levels}
    if with_secrets:
        env["SECREATIONS_PATH"] = secrets
    return env


def run_main(mod, argv, env_extra, rec, user_exists=False,
             intern_home=None, state_dir=None):
    out, err = io.StringIO(), io.StringIO()
    patches = [
        mock.patch.object(mod.subprocess, "run", rec),
        mock.patch.object(mod, "user_exists", lambda name: user_exists),
        mock.patch.dict(os.environ, env_extra, clear=False),
    ]
    if state_dir is not None:
        patches.append(mock.patch.object(mod, "GAME_STATE_DIR", state_dir))
    if intern_home is not None:
        patches.append(mock.patch.object(mod, "INTERN_HOME", intern_home))
    code = None
    for p in patches:
        p.start()
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                code = mod.main(argv)
            except SystemExit as exc:
                code = exc.code
    finally:
        for p in reversed(patches):
            p.stop()
    return code, out.getvalue(), err.getvalue()


def bash_calls(rec):
    return [c for c in rec.calls if c.cmd and c.cmd[0] == "bash"]


class GameTarget(unittest.TestCase):
    def setUp(self):
        self.mod = load_module()
        self.tmp = tempfile.mkdtemp(prefix="setup-iso-")

    def test_game_builds_accounts_and_runs_setups(self):
        env = write_fixture(self.tmp)
        rec = Recorder()
        state = os.path.join(self.tmp, "state")
        code, out, err = run_main(self.mod, ["--target", "game"], env, rec,
                                  state_dir=state)
        self.assertEqual(code, 0, err)
        cmds = rec.cmds()
        for i in range(4):
            self.assertIn(["useradd", "-m", "-s", "/bin/bash", "level%d" % i], cmds)
        self.assertEqual(len(bash_calls(rec)), 3)  # level 2 has empty setup
        self.assertTrue(os.path.isdir(state))      # /var/lib/game created
        # chown + chmod per level, homes locked down
        for i in range(4):
            self.assertIn(["chown", "-R", "level%d:level%d" % (i, i),
                           "/home/level%d" % i], cmds)
            self.assertIn(["chmod", "-R", "u+rwX,go-rwx",
                           "/home/level%d" % i], cmds)
        # no secrets anywhere in output
        for s in SECRET_VALUES:
            self.assertNotIn(s, out)
            self.assertNotIn(s, err)

    def test_env_contract_next_pw_chain(self):
        env = write_fixture(self.tmp)
        rec = Recorder()
        code, out, err = run_main(self.mod, [], env, rec,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 0, err)
        by_cwd = {c.kwargs.get("cwd"): c for c in bash_calls(rec)}
        e0 = by_cwd["/home/level0"].kwargs["env"]
        self.assertEqual(e0["NEXT_PW"], SECRET_VALUES[1])
        self.assertEqual(e0["LEVEL_ID"], "0")
        self.assertEqual(e0["LEVEL_USER"], "level0")
        self.assertEqual(e0["HOME"], "/home/level0")
        e1 = by_cwd["/home/level1"].kwargs["env"]
        self.assertEqual(e1["NEXT_PW"], SECRET_VALUES[2])
        e3 = by_cwd["/home/level3"].kwargs["env"]
        self.assertEqual(e3["NEXT_PW"], "")  # last level: empty chain tail
        # bash -e -c contract
        c0 = by_cwd["/home/level0"]
        self.assertEqual(c0.cmd[:3], ["bash", "-e", "-c"])
        self.assertEqual(c0.cmd[3], "echo hi > readme.txt")

    def test_chpasswd_passwords_from_secrets(self):
        env = write_fixture(self.tmp)
        rec = Recorder()
        code, out, err = run_main(self.mod, [], env, rec,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 0, err)
        inputs = [c.kwargs.get("input") for c in rec.calls
                  if c.cmd and c.cmd[0] == "chpasswd"]
        self.assertEqual(inputs, ["level0:begin\n", "level1:%s\n" % SECRET_VALUES[1],
                                  "level2:%s\n" % SECRET_VALUES[2],
                                  "level3:%s\n" % SECRET_VALUES[3]])

    def test_existing_user_skips_useradd(self):
        env = write_fixture(self.tmp)
        rec = Recorder()
        code, out, err = run_main(self.mod, [], env, rec, user_exists=True,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 0, err)
        self.assertNotIn("useradd", [c.cmd[0] for c in rec.calls])

    def test_missing_secret_aborts_before_mutation(self):
        env = write_fixture(self.tmp)
        # remove password for id 2
        with open(env["SECREATIONS_PATH"], "w", encoding="utf-8", newline="\n") as fh:
            fh.write("version: 1\npasswords:\n  0: begin\n  1: pw1\n  3: pw3\n")
        rec = Recorder()
        code, out, err = run_main(self.mod, [], env, rec,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 1)
        self.assertIn("secrets.yaml", err)
        self.assertEqual(rec.calls, [])  # nothing ran

    def test_missing_secrets_file_names_it(self):
        env = write_fixture(self.tmp, with_secrets=False)
        env["SECREATIONS_PATH"] = os.path.join(self.tmp, "nope.yaml")
        rec = Recorder()
        code, out, err = run_main(self.mod, [], env, rec,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 2)
        self.assertIn("secrets.yaml", err)
        self.assertEqual(rec.calls, [])

    def test_setup_failure_reports_level_and_redacts(self):
        env = write_fixture(self.tmp)
        rec = Recorder(fail_on="bash",
                       stderr="line 1: boom %s\n" % SECRET_VALUES[1])
        code, out, err = run_main(self.mod, [], env, rec,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 1)
        self.assertIn("level 0", err)
        self.assertIn("[redacted]", err)
        for s in SECRET_VALUES:
            self.assertNotIn(s, err)

    def test_default_target_is_game(self):
        env = write_fixture(self.tmp)
        rec = Recorder()
        code, out, err = run_main(self.mod, [], env, rec,
                                  state_dir=os.path.join(self.tmp, "state"))
        self.assertEqual(code, 0, err)
        self.assertIn("useradd", [c.cmd[0] for c in rec.calls])


class LabTarget(unittest.TestCase):
    def setUp(self):
        self.mod = load_module()
        self.tmp = tempfile.mkdtemp(prefix="setup-iso-lab-")

    def test_lab_runs_only_setups_and_uses_intern_env(self):
        env = write_fixture(self.tmp)
        rec = Recorder()
        intern_home = os.path.join(self.tmp, "intern")
        code, out, err = run_main(self.mod, ["--target", "lab"], env, rec,
                                  intern_home=intern_home)
        self.assertEqual(code, 0, err)
        calls = bash_calls(rec)
        self.assertEqual(len(calls), 1)  # beta-lab has no setup
        c = calls[0]
        self.assertEqual(c.cmd[:3], ["bash", "-e", "-c"])
        self.assertEqual(c.kwargs["cwd"], intern_home)
        e = c.kwargs["env"]
        self.assertEqual(e["NEXT_PW"], "")
        self.assertEqual(e["LEVEL_ID"], "alpha-lab")
        self.assertEqual(e["LEVEL_USER"], "intern")
        self.assertEqual(e["HOME"], intern_home)
        cmds = rec.cmds()
        self.assertIn(["chown", "-R", "intern:intern", intern_home], cmds)
        self.assertIn(["chmod", "-R", "u+rwX,go-rwx", intern_home], cmds)
        self.assertNotIn("useradd", [x[0] for x in cmds])
        self.assertNotIn("chpasswd", [x[0] for x in cmds])
        self.assertTrue(os.path.isdir(intern_home))


class Scrub(unittest.TestCase):
    def test_scrub_redacts_secrets(self):
        mod = load_module()
        self.assertEqual(mod.scrub("x begin y", ["begin"]), "x [redacted] y")
        self.assertEqual(mod.scrub("nothing", ["begin"]), "nothing")


if __name__ == "__main__":
    unittest.main(verbosity=2)
```

## Test Result
- Status: pass (10/10, `Ran 10 tests ... OK`, EXIT=0)
- Red first: 10/10 errors against the old prototype (no main/user_exists/scrub)
- Session: ses_m3b
- Timestamp: 2026-10-11T07:07:04Z

## Shell/Help Gates (post-implementation)
```
COMPILE_OK
BASH_OK
SH_OK
```
- `python -m py_compile linuxgame/game/setup.py` → COMPILE_OK
- `bash -n linuxgame/game/entrypoint.sh` (Git bash) → BASH_OK
- `sh -n linuxgame/game/mark.sh` (Git sh) → SH_OK
- `python setup.py --help` → usage shows `--target {game,lab}` default game

## Dry-Run Simulation Gate (no docker)
```
(a) 48 levels, non-empty secret each: PASS (n=48, missing=0)
(b) NEXT_PW(i) == secrets[i+1] for all i: PASS (mismatches=[])
(c) bash -n on sample setups [0, 28, 47]: PASS ([])
(bonus) bash -n on 5 lab setups: PASS ([])
DRY-RUN GATE: PASS
```
Script: C:\Users\dmax\AppData\Local\Temp\opencode\dryrun_sync10.py (loads real
levels.yaml + secrets.yaml; secret values never printed)

## mark.sh behavior notes (POSIX sh)
- Matches `^level[0-9]{1,3}$` via case arms; anything else exits 0
- Creates /var/lib/game and the progress file if absent
- Dedupes consecutive repeats (tail -n 1 compare)
- Always exits 0 (append failure swallowed)
