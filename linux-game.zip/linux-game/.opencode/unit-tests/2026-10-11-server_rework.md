# Unit Test Record: server.py (Nimbus Casebook API rework)

## Target File
`linuxgame/game/server.py` (rework: 3775 B prototype → full API per docs/API_CONTRACT.md)

## Test File (DELETED after pass)
`linuxgame/game/__tests__/server.isolated.test.py`

## Test Code (Preserved)
```python
"""ISOLATED unit test for linuxgame/game/server.py pure helpers.

Imports only server.py. No ssh, no HTTP bind, no /var/lib writes
(GAME_PROGRESS/GAME_SCORES pointed at a temp dir before import).
"""
import json
import os
import sys
import tempfile
import unittest

_TMP = tempfile.mkdtemp(prefix="srvtest-")
os.environ["GAME_PROGRESS"] = os.path.join(_TMP, "progress")
os.environ["GAME_SCORES"] = os.path.join(_TMP, "scores.json")
_cmd = os.path.abspath(os.path.join(
    os.path.dirname(__file__), "..", "..", "commands", "commands.yaml"))
if os.path.isfile(_cmd):
    os.environ["COMMANDS_YAML"] = _cmd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import server  # noqa: E402


class ServerPure(unittest.TestCase):
    def test_secrets_chain(self):
        self.assertEqual(server.SECRETS[0], "begin")
        self.assertEqual(len(server.SECRETS), 48)
        for i in range(1, 48):
            self.assertEqual(len(server.SECRETS[i]), 16)

    def test_levels_shape(self):
        self.assertEqual(len(server.LEVELS), 48)
        self.assertEqual(len(server.INTERACTIVE), 6)
        self.assertEqual(len(server.LABS), 5)
        self.assertEqual(server.HINT_COSTS, [5, 15, 30])

    def test_points_by_type(self):
        self.assertEqual(server.points_of(server.LEVELS[0]), 100)   # flag
        self.assertEqual(server.points_of(server.LEVELS[9]), 120)  # evidence
        self.assertEqual(server.points_of(server.LEVELS[7]), 150)  # task
        self.assertEqual(server.points_of(server.LEVELS[8]), 250)  # boss
        self.assertEqual(server.points_of(server.LEVELS[47]), 300)  # capstone

    def test_rank_thresholds(self):
        self.assertEqual(server.rank_of(0)["name"], "Constable")
        self.assertEqual(server.rank_of(800)["name"], "Detective")
        self.assertEqual(server.rank_of(2000)["name"], "Inspector")
        self.assertEqual(server.rank_of(3500)["name"], "Chief")
        self.assertEqual(server.rank_of(799)["next"], "Detective")
        self.assertEqual(server.rank_of(799)["next_at"], 800)

    def test_scores_roundtrip_and_total(self):
        path = server.SCORES_PATH
        sc = server.empty_scores()
        sc["by_level"]["0"] = 100
        sc["puzzles"]["match-1"] = True
        sc["labs"]["first-users"] = 150
        sc["deductions"]["L47"] = 300
        sc["hints_used"]["2"] = [0, 1]
        server.save_scores(sc)
        self.assertTrue(os.path.isfile(path))
        back = server.load_scores()
        # 100 + 50 + 150 + 300 - 5 - 15 = 580
        self.assertEqual(back["total"], 580)
        self.assertEqual(back["by_level"]["0"], 100)

    def test_load_scores_tolerates_garbage(self):
        old = server.SCORES_PATH
        try:
            server.SCORES_PATH = os.path.join(_TMP, "missing.json")
            sc = server.load_scores()
            self.assertEqual(sc["total"], 0)
            server.SCORES_PATH = os.path.join(_TMP, "bad.json")
            with open(server.SCORES_PATH, "w") as fh:
                fh.write("{not json")
            sc = server.load_scores()
            self.assertEqual(sc["total"], 0)
        finally:
            server.SCORES_PATH = old

    def test_reached_and_connected_absent_progress(self):
        old = server.PROGRESS
        try:
            server.PROGRESS = os.path.join(_TMP, "no-progress")
            self.assertEqual(server.reached(), 0)
            with open(server.PROGRESS, "w") as fh:
                fh.write("level0\nlevel3\nnot-a-user\nlevel2\n")
            self.assertEqual(server.reached(), 3)
        finally:
            server.PROGRESS = old

    def test_award_level_points_once(self):
        sc = server.empty_scores()
        self.assertTrue(server.award_level_points(sc, 0))
        self.assertFalse(server.award_level_points(sc, 0))
        self.assertEqual(sc["by_level"]["0"], 100)
        # graded levels never auto-award
        self.assertFalse(server.award_level_points(sc, 7))

    def test_clue_ids(self):
        self.assertEqual(server.clue_id_of(server.LEVELS[0]), "c-sticky")
        self.assertEqual(server.clue_id_of(server.LEVELS[47]), "c-culprit")
        self.assertIsNone(server.clue_id_of(server.LEVELS[2]))
        clues = server.collected_clues(0)
        self.assertEqual([c["id"] for c in clues], ["c-sticky"])
        clues47 = server.collected_clues(47)
        self.assertIn("c-tmux", [c["id"] for c in clues47])
        self.assertIn("c-manifest", [c["id"] for c in clues47])

    def test_check_puzzle_answers(self):
        match = next(p for p in server.INTERACTIVE if p["id"] == "match-1")
        self.assertTrue(server.check_puzzle_answer(match, {
            "pairs": [["walk into a folder", "cd"],
                      ["print the folder you are standing in", "pwd"],
                      ["list the files around you", "ls"],
                      ["read a text file out loud", "cat"]]}))
        self.assertFalse(server.check_puzzle_answer(match, {
            "pairs": [["walk into a folder", "ls"]]}))
        tree = next(p for p in server.INTERACTIVE if p["id"] == "tree-1")
        self.assertTrue(server.check_puzzle_answer(
            tree, "/home/level5/archive/2026/ledger.txt"))
        self.assertFalse(server.check_puzzle_answer(
            tree, "/home/level5/archive/2024/note.txt"))
        order = next(p for p in server.INTERACTIVE if p["id"] == "order-1")
        self.assertTrue(server.check_puzzle_answer(order, list(order["answer"])))
        self.assertFalse(server.check_puzzle_answer(
            order, list(reversed(order["answer"]))))
        chmod = next(p for p in server.INTERACTIVE if p["id"] == "chmod-1")
        self.assertTrue(server.check_puzzle_answer(chmod, ["644", "755", "600", "400"]))
        self.assertFalse(server.check_puzzle_answer(chmod, ["644", "755", "600", "777"]))
        scen = next(p for p in server.INTERACTIVE if p["id"] == "scenario-1")
        self.assertTrue(server.check_puzzle_answer(scen, ["du", "ss", "ps", "df"]))
        self.assertFalse(server.check_puzzle_answer(scen, ["df", "ss", "ps", "du"]))

    def test_level_payload_strips_secrets(self):
        r = server.reached()
        p = server.level_payload(0, r)
        for banned in ("setup", "verify", "password", "solution", "learned"):
            self.assertNotIn(banned, p)
        self.assertEqual(p["n"], 0)
        self.assertEqual(p["hint_count"], 3)
        self.assertEqual(p["clue"], "c-sticky")
        self.assertEqual(p["next_user"], "level1")
        # never a secret password except start (checked separately)
        blob = json.dumps(p)
        for i in range(1, 48):
            self.assertNotIn(server.SECRETS[i], blob)

    def test_puzzle_payload_no_answer(self):
        for p in server.INTERACTIVE:
            payload = server.puzzle_payload(p["id"])
            self.assertNotIn("answer", payload)
            self.assertEqual(payload["kind"], p["kind"])
            self.assertIn("data", payload)

    def test_commands_payload_shape(self):
        # commands.yaml sits next to repo commands/; may be absent in isolation
        data = server.commands_payload()
        self.assertIn("commands", data)
        self.assertIn("acts", data)
        self.assertIsInstance(data["commands"], list)
        if data["commands"]:
            c = data["commands"][0]
            for key in ("name", "kind", "group", "summary", "syntax",
                        "options", "examples", "mistakes", "learn_more",
                        "runtime"):
                self.assertIn(key, c)
            self.assertIsInstance(c["learn_more"], list)
            self.assertIsInstance(c["options"], list)
            if c["options"]:
                self.assertIn("flag", c["options"][0])
                self.assertIn("meaning", c["options"][0])

    def test_casebook_board(self):
        cb = server.casebook_payload()
        self.assertEqual(cb["board"]["locked"], "Dee Vider")
        names = [s["name"] for s in cb["board"]["suspects"]]
        self.assertIn("Dee Vider", names)
        self.assertIn("Milo", names)

    def test_feedback_first_line(self):
        self.assertEqual(server.feedback_from("a\nb\n", "", 1), "a\nb")
        self.assertIn("problems", server.feedback_from("", "", 1))
        self.assertEqual(server.feedback_from("ok\n", "", 0), "ok")

    def test_export_has_no_passwords(self):
        blob = json.dumps(server.export_payload())
        for i in range(1, 48):
            self.assertNotIn(server.SECRETS[i], blob)
        # start password 'begin' is public but should not appear in export either
        data = server.export_payload()
        self.assertIn("profile", data)
        self.assertIn("exported_at", data)
        self.assertNotIn("start_password", data)


if __name__ == "__main__":
    unittest.main(verbosity=2)
```

## Test Result
- Status: **pass** — `Ran 16 tests in 0.608s` → `OK`
- One benign `ResourceWarning` (unclosed file in commands path probe, server.py L434) — not a failure
- Session: ses_srv1 (terminal worker)
- Timestamp: 2026-10-11T07:16:09

## Literal Gates (final re-run after test)
- `COMPILE_OK` (py_compile)
- `AST_OK` + `['/api/casebook', '/api/commands', '/api/deduction', '/api/export', '/api/hint', '/api/labverify', '/api/level', '/api/puzzle', '/api/state', '/api/verify']`
- server.py: 30468 bytes / **939 lines** (ReadAllLines/LF count authoritative; earlier Measure-Object 858 was wrong)
- base_test.py: 9201 bytes / 207 lines

## Endpoint → Line Map
| Method | Path | Line |
|--------|------|------|
| GET | /api/state | 560 |
| GET | /api/level | 563 |
| GET | /api/commands | 593 |
| GET | /api/casebook | 596 |
| GET | /api/puzzle | 599 |
| GET | /api/export | 613 |
| POST | /api/hint | 624 |
| POST | /api/verify | 627 |
| POST | /api/puzzle | 630 |
| POST | /api/labverify | 633 |
| POST | /api/deduction | 636 |
