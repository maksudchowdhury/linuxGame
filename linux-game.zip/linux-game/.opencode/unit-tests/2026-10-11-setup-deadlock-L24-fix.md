# Unit test record — setup.py deadlock fix + L24 fifo rework (SYNC-10 round 2)

**Date:** 2026-10-11
**Scope:** `linuxgame/game/setup.py` (`run_setup_script`), `linuxgame/levels/_act3.yaml` (L24 setup), `linuxgame/game/entrypoint.sh` (listener comment)
**Trigger:** Reviewer FAIL 07:27 — `docker compose build` deadlocked at L24; WSL repro TimeoutExpired confirmed.

## Root cause

L24's setup staged a backgrounded fifo writer:

```sh
mkfifo tunnel
(echo "$NEXT_PW" > tunnel &)   # blocks on open() until a reader appears
chmod 666 tunnel
```

`setup.py` ran each setup under `subprocess.run(capture_output=True)` with **no
timeout**. The backgrounded writer:
1. blocks forever on `open(tunnel)` (no reader at build time), and
2. inherits setup.py's captured **stdout/stderr OS pipes**, so
   `subprocess.run` never sees EOF and never returns → build hangs.

## Fix

### setup.py — `run_setup_script` (deadlock-proof I/O + hard timeout)

- Child stdout/stderr → **temp FILES** (`tempfile.TemporaryFile`), never OS
  pipes. A blocked background writer can no longer pin the capture.
- `stdin=DEVNULL` (setups never read stdin).
- `start_new_session=True` + `os.killpg(..., SIGKILL)` on timeout so a runaway
  setup's whole process group is killed, not just the direct child.
- `SETUP_TIMEOUT` env (default 120s) bounds every setup script.
- Secret scrubbing preserved: temp-file contents are scrubbed before any is
  written to stderr.

### levels/_act3.yaml — L24 setup (staged writer that works in all 3 phases)

```sh
mkfifo tunnel
chmod 666 tunnel
cat > start_listener.sh <<EOF
#!/bin/bash
echo '$NEXT_PW' > /home/$LEVEL_USER/tunnel
EOF
chmod 755 start_listener.sh
( sh -c "echo '$NEXT_PW' > tunnel" </dev/null >/dev/null 2>&1 & )
```

- The **immediate backgrounded writer** is launched with its own fds redirected
  to `/dev/null`, so it never holds setup.py's capture and setup returns
  immediately. It stays alive (orphaned) so the solution's `cat tunnel`
  rendezvous works during the host sim and during the validator build (setup +
  `_buildcheck.py` run in the same Docker `RUN`).
- `start_listener.sh` is staged for the runtime: `entrypoint.sh` runs it as
  level24 at container start, re-creating the blocked writer so a learner's
  `cat tunnel` gets the password. (The build-time backgrounded writer dies with
  the build container; the listener hook re-creates it per boot.)

### entrypoint.sh — comment accuracy

Listener hook comment no longer claims "No secrets involved" (a listener may
stage the *next* level's password into a fifo in levelN's own home — that is
the level's mechanic; it never runs as root, never touches another user's files).

## Verification (all green)

| Check | Command | Result |
|-------|---------|--------|
| Deadlock repro (old code hung) | `python3 linuxgame/game/__tests__/setup.isolated.test.py` | `OK: returned clean in 0.0s (no deadlock)` |
| Runaway setup killed | same | `OK: runaway killed in 2.0s` (SETUP_TIMEOUT=2) |
| Isolated unit suite | `python3 linuxgame/game/__tests__/setup.isolated.test.py` | `PASS setup.isolated (2/2)` |
| Act3 gate | `python3 tools/simulate_chain.py --act 3` | `7/7 pass` (L19–L25) |
| Full merged gate | `python3 tools/simulate_chain.py` | `48/48 pass` |
| Validator | `python tools/validate_levels.py` | `VALIDATION OK` |
| Merge | `python tools/_merge_levels.py` | 48 levels / 48 chain / 5 labs |
| setup.py compile | `python -m py_compile linuxgame/game/setup.py` | COMPILE_OK |
| _buildcheck isolated | `python3 linuxgame/solutions/__tests__/_buildcheck.isolated.test.py` | `OK (17 tests)` |

## New/repaired test file

`linuxgame/game/__tests__/setup.isolated.test.py` — the prior setup isolated
test was deleted (recorded) after S3.2's first pass; it mocked `subprocess.run`
and would not exercise the new `Popen`-based path. Re-authored as a **real
deadlock repro** (backgrounded fifo writer with no reader) + a **runaway-timeout
kill** test, both against the live `run_setup_script`.

## Residual / deferred

- `docker compose build` end-to-end exit 0 not yet confirmed in this record
  (delegated to S5.1 build & fix loop; the WSL sim + isolated tests prove the
  deadlock root cause is gone and the validator stage runs setup+buildcheck in
  the same RUN, which is the phase the backgrounded writer must survive).
