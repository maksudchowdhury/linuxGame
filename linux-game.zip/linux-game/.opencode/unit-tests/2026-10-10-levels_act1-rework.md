# Unit Test Record — levels/_act1.yaml + solutions/_act1.yaml ("Resume act1 authoring")

- Date: 2026-10-10T22:10+06:00
- Reviewer: Reviewer (Unit Review, ses_s1a rework claim)
- Worker claim: ses_s1a "done 21:57; gates ACT1 LEVELS OK + ACT1 SOLUTIONS OK; sizes 19539/1455"
- Spec: docs/STORY_BIBLE.md Act 1 (L0–L8 + match-1/tree-1), schema/contracts per docs/AUTHORING.md §1b/§3

## ⚠ Race note (files changed DURING this review)

| File | as claimed 21:57 | at review start 22:00 | at verdict 22:10 |
|------|------------------|----------------------|------------------|
| levels/_act1.yaml | 19539 B | 19539 B (block style, `chain:`-era content) | **19117 B @ 22:03:42** (yaml round-trip by merge/chip pipeline: `_merge_levels.py`/`_place_chips.py`; +6 coverage chips more/tac/mktemp/rm/rmdir/shred) |
| solutions/_act1.yaml | 1455 B, correct paths, `echo "$NEXT_PW"` | same @ 22:00:29 | **882 B @ 22:02:01 — REGRESSED to stale stub** (unlogged writer) |

The levels file evolved (still valid); the solutions file was **clobbered back to a stale
draft** after the worker declared done. All verdicts below are on the CURRENT on-disk state.

## Gates run

| # | Gate | Result |
|---|------|--------|
| 1 | lsp_diagnostics | tool broken (SYNC-4, "Failed to write request to Rust tool process") — workaround: python gates + container probe |
| 2 | YAML parse, CRLF, forbidden keys (`solution`/`password`) in levels | PASS (CRLF 0, no forbidden keys) |
| 3 | Structure vs AUTHORING §1b: 9 levels ids 0–8, act=1, required keys, hints tiers nudge/direction/near ×3, verify ONLY on task(L7)/boss(L8) | PASS |
| 4 | Types/points vs STORY_BIBLE: flag 100 (L3=110, L6=120), breather 80, task 150, boss 250 | PASS (exact match) |
| 5 | Casebook clues = bible (c-sticky/c-scratch/c-moved/c-path/c-deskplate) | PASS |
| 6 | interactive: match-1 (requires 0, 4 pairs, answer≡data), tree-1 (requires 5, answer∈options); labs [] | PASS |
| 7 | Chips ⊆ commands.yaml names (25 chips incl. 6 coverage chips added 22:03:42 by `_place_chips.py`) | PASS (0 missing) |
| 8 | `tools/validate_levels.py` (merged levels.yaml) → act1 lines | PASS (0 problems for L0–L8; only L39/coverage failed at run time — act5/merge scope, since fixed by other workers) |
| 9 | Solutions contract (AUTHORING §3: last stdout line == next password, paths must match setups) | **FAIL 9/9 static**: no solution ends `echo "$NEXT_PW"`; 7/9 reference nonexistent paths |
| 10 | **Container probe** (linuxgame): run each setup + solution, `NEXT_PW=probePW123abc` | **FAIL: 2/9 pass** |
| 11 | Container verify contract (L7 task, L8 boss: pristine FAIL → solution → PASS) | **L7 OK; L8 FAIL (after=1)** — solution never produces case/badge.txt |
| 12 | Merged `solutions/solutionbook.yaml` (re-merged 22:08:24) still contains broken act1 entries | CONFIRMED (id0 last=`cat readme.txt`, id8 last=`cat final_key.txt`) |
| 13 | Unit-test record by worker for this rework in .opencode/unit-tests/ | **ABSENT** (only stale FAIL record 2026-10-10-levels_act1.md @ 21:33) |

## Container probe transcript (abridged, docker exec linuxgame bash)

```
L0 FAIL rc=1 last=[]        cat: readme.txt: No such file or directory   (actual: welcome/readme.txt)
L1 FAIL rc=1 last=[]        cat: .vault: Is a directory                  (actual: .vault/combination.txt)
L2 PASS (last=probePW123abc)
L3 FAIL rc=1 last=[]        cat: case/memo1.txt: No such file or directory (actual: memo_a/memo_b/invoice.png/form.pdf/ledger.txt)
L4 PASS (last=probePW123abc)
L5 FAIL rc=1 last=[]        cat: maze/records/bigfile.txt: No such file... (actual: archive/2026/ledger.txt)
L6 FAIL rc=1 last=[a1p]     cd: north/attic/vault: No such directory     (actual: hallway/west/wing/office/desk/drawer)
L7 FAIL rc=1 last=[]        cat: .next_key: No such file or directory    (verify OK, but no pw output)
L8 FAIL rc=1 last=[]        cd: lobby/cabinet/inner: No such directory   (actual: desk/drawers/badge.txt)
L8 VERIFY BAD pristine=1 after=1
RESULT pass=2 fail=8
```

## Verdict: **FAIL**

Levels half is solid; solutions half is a REGRESSION:
1. solutions/_act1.yaml clobbered at 22:02:01 with a stale draft that contradicts the
   current setups — 7/9 solutions error out, 0/9 satisfy the password-output contract,
   L8 boss verify never passes → the whole act1 chain is unsolvable at runtime.
2. Broken content already propagated into `solutions/solutionbook.yaml` (merge artifact).
3. No worker unit-test record exists for this rework (rework requirement #3 from the
   21:32 FAIL record was not met).

## Required rework (send back via Commander)

1. Restore/re-author `solutions/_act1.yaml` so every entry matches its level's current
   `setup` paths AND ends with `echo "$NEXT_PW"` (the 21:57 version, 1455 B, was correct —
   if still recoverable, restore it; else rewrite per current setups).
2. Re-run merge (`tools/_merge_levels.py`) so `solutionbook.yaml` picks up the fix.
3. Worker writes a unit-test record (parse gate + static contract check) before claiming DONE.
4. Re-verify with the same container probe (script: temp opencode/act1_probe.sh, generator
   gen_probe.py) → required: 9/9 contract pass, L7/L8 verify pristine-fail→post-pass.
