# UT-shard4 — Unit test record: linuxgame/commands/_shard4.yaml

- Date: 2026-10-10T21:15
- Session: task_fabba36e (Worker) / verified by Reviewer
- Result: **FAIL (1 HIGH content defect + missing worker self-check record)**

## Test content (Reviewer-run, scripts in %TEMP%\opencode)

1. `verify_shard4.py` (structural): YAML parse, UTF-8, LF-only, required keys
   (name/kind/summary/explain/syntax/options/examples/mistakes/learn_more/runtime),
   kind enum, runtime enum vs API_CONTRACT, option format, >=2 examples with
   cmd/note/safe bool, learn_more self-help nudge, no dupes, no external URLs/hosts,
   no TODO/FIXME/lorem, cross-shard duplicate check vs shard1/2/3/5.
2. `run_safe_shard4.py` (behavioral): executes every `safe: true` example inside the
   live `linuxgame` container (`docker exec linuxgame timeout 15 bash -c <cmd>`).
3. Binary presence: `command -v <name>` for all 31 names in `linuxgame` and `linuxlab`.

## Results

- Structure: 31/31 entries, 0 issues (count matches todo S2.2.4 = 31).
- Safe examples: **37/37 rc=0** (incl. apt-cache with cleaned apt lists,
  curl/wget localhost:9021, nc/ping 127.0.0.1, ip/ifconfig/netstat/ss).
- Security: no destructive command marked safe; no external hosts (only
  localhost/127.0.0.1); no passwords, no placeholders.
- **FAIL-1 (HIGH)**: `add-apt-repository` binary MISSING in game AND lab images
  (`software-properties-common` not installed) → dead examples/`man` reference;
  also `runtime: theory` not in API_CONTRACT enum (`image|lab`). → SYNC-1.
- Cross-shard: shard3 missing `runtime` key on all 29 entries → SYNC-2;
  shard2 YAML parse error line 190 → SYNC-3.
- Tooling: `lsp_diagnostics` broken (Rust tool process write failure, 3 tries) → SYNC-4.

## Worker self-check status
- `.opencode/unit-tests/` had no record for this unit ("self-check pending" in work-log);
  worker's temp `verify_shard4.py` existed but was never recorded/run to green.
  Reviewer ran the full suite instead (this file is the evidence).
