# Unit Test Record: linuxgame/solutions/_act1.yaml (SYNC-11 rework)

## Target File
`E:\linux-game\linuxgame\solutions\_act1.yaml` (was: stale 882 B draft, container probe 2/9)

## Session / Timestamp
- Session: ses_a1s11
- Timestamp: 2026-10-11T07:07Z
- Issue: SYNC-11
- Environment note: Docker Desktop engine DOWN (`docker version` → pipe not found), so the
  mandated NON-destructive mktemp simulation was run on host **WSL Kali** (has `file`,
  `tree`, `cmp`, `stat`, `tac`, bash 5.2.37) instead of a container. TESTPW placeholder
  used everywhere; real secrets never printed or read into logs.

## Test Files (created in temp harness, not in repo)
- `C:\Users\dmax\AppData\Local\Temp\opencode\sync11\gate123.py` (host python 3.12, pyyaml 6.0.3)
  — gates 1 (path audit), 2 (structure), 3 (end markers) + extraction of
  `setup.sh`/`solution.sh`/`verify.sh` per id under `sync11\sim\level_<i>\`
- `C:\Users\dmax\AppData\Local\Temp\opencode\sync11\sim\probe.sh` (gate 4, runs in WSL Kali)
  (both remain in temp only; nothing added to the repo except the record + work-log)

## Result
- Status: **pass**
- Session: ses_a1s11
- Timestamp: 2026-10-11T07:07Z

---

## GATE 2 — structure (yaml.safe_load both files, ids exact, 9 entries)

```
GATE2 level ids    : [0, 1, 2, 3, 4, 5, 6, 7, 8]
GATE2 solution ids : [0, 1, 2, 3, 4, 5, 6, 7, 8]
GATE2 OK: ids 0..8 exact both sides; entries 9
```

## GATE 1 — path audit (cwd-aware: models cd/pushd stack + mv/cp produced files)

```
GATE1 path audit (solution refs vs setup-created set, cwd-aware):
  id 0: OK
  id 1: OK
  id 2: OK
  id 3: OK  [produced: ['case/memo_a.txt', 'case/memo_b.txt', 'case/invoice.png', 'case/form.pdf', 'case/ledger.txt']]
  id 4: OK
  id 5: OK
  id 6: OK
  id 7: OK  [produced: ['report.txt', 'report.bak']]
  id 8: OK  [produced: ['case/badge.txt']]
GATE1 OK: every cat/grep/ls/tree/stat/tail/head/file/cd/pushd/mv/cp path exists in its setup (or is solution-produced)
```

Per-id path audit table:

| id | solution reads (paths) | path source in levels/_act1.yaml setup | audit |
|----|------------------------|----------------------------------------|-------|
| 0 | welcome/readme.txt | `printf … > welcome/readme.txt` (+sticky.txt) | OK |
| 1 | .vault/dust.txt, .vault/combination.txt (after `cd .vault`) | `.vault/` mkdir + dust.txt + combination.txt | OK |
| 2 | notes.txt (decoy), "my secret notes.txt" (quoted) | `> notes.txt`, `> "my secret notes.txt"` | OK |
| 3 | memo_a.txt, memo_b.txt, invoice.png, form.pdf, ledger.txt → case/ | loose files at HOME; solution mkdir+mv+file+cat | OK |
| 4 | letter.txt (wc, tail) | 39-line loop `done > letter.txt` + NEXT_PW line | OK |
| 5 | archive/{2024/note.txt,2025/memo.txt,2026/ledger.txt} | `mkdir -p archive/2024 2025 2026` + printf each | OK |
| 6 | pushd hallway→west→wing→office→desk→drawer; key.txt | `mkdir -p hallway/west/wing/office/desk/drawer` + key.txt at drawer | OK |
| 7 | source.txt → report.txt/report.bak + notes/ | `printf … > source.txt`; verify checks the three artifacts | OK |
| 8 | desk/photo.png, desk/drawers/badge.txt → case/ | `mkdir -p desk/plates desk/drawers` + badge.txt | OK |

## GATE 3 — end-marker audit

```
GATE3 id 0: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 1: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 2: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 3: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 4: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 5: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 6: final line = 'echo "$NEXT_PW"' -> OK
GATE3 id 7: final line = 'echo "$NEXT_PW"' -> OK
GATE3 OK: ids 0..7 each end with echo "$NEXT_PW"
GATE3 id 8 (boss, no echo requirement): final line = 'cat case/badge.txt'
```

## GATE 4 — runtime probe (WSL Kali mktemp simulation, NEXT_PW=TESTPW everywhere)

For ids 0..6: fresh `mktemp -d` HOME → `bash -e setup.sh` → `bash solution.sh` →
assert last non-empty stdout line == TESTPW.
id 7: + pristine `verify.sh` must FAIL, then solution, then verify must PASS.
id 8: + pristine `verify.sh` must FAIL, then solution (badge cat last line TESTPW), verify PASS.

```
PROBE HOST: Linux 6.18.40.1-microsoft-standard-WSL2 x86_64 bash=5.2.37(1)-release
L0 PROBE PASS (last non-empty stdout line == TESTPW)
L1 PROBE PASS (last non-empty stdout line == TESTPW)
L2 PROBE PASS (last non-empty stdout line == TESTPW)
L3 PROBE PASS (last non-empty stdout line == TESTPW)
L4 PROBE PASS (last non-empty stdout line == TESTPW)
L5 PROBE PASS (last non-empty stdout line == TESTPW)
L6 PROBE PASS (last non-empty stdout line == TESTPW)
L7 PROBE PASS (last==TESTPW, pristine verify FAIL, post verify PASS)
L8 PROBE PASS (badge cat ends on TESTPW, pristine verify FAIL, post verify PASS)
PROBE RESULT: 9 levels -> PASS=9 FAIL=0
PROBE_EXIT=0
```

Probe result: **9/9 PASS** (was 2/9 in the Reviewer's container probe of the stale draft).

## GATE 5 — re-merge + validator (run from repo root E:\linux-game)

```
WROTE linuxgame\game\levels.yaml: 48 levels, 6 puzzles, 5 labs
WROTE linuxgame\solutions\solutionbook.yaml: 37 chain solutions, 5 lab solutions
MERGE_EXIT=0
VALIDATION OK
VALID_EXIT=0
```

Post-merge content check (solutionbook.yaml):

```
n solutions 37
id0 last: echo "$NEXT_PW"
id8 last: cat case/badge.txt
id6 has pushd hallway: True
stale marker present (readme.txt bare): False
```

## Test code (probe.sh, preserved)

```bash
#!/bin/bash
# SYNC-11 gate 4 — mktemp simulation probe (WSL Kali; docker engine down).
# TESTPW placeholder only — real secrets are never printed or used here.
set -u
BASE="$(cd "$(dirname "$0")" && pwd)"
echo "PROBE HOST: $(uname -srm) bash=$BASH_VERSION"
PASS=0; FAIL=0

last_nonempty() { awk 'NF{l=$0} END{print l}'; }

for i in 0 1 2 3 4 5 6; do
  H=$(mktemp -d)
  if (
    cd "$H" || exit 1
    export HOME="$H"
    NEXT_PW=TESTPW bash -e "$BASE/level_$i/setup.sh" >/tmp/l$i-setup.log 2>&1 || { echo "  L$i setup FAILED"; cat /tmp/l$i-setup.log; exit 1; }
    out=$(NEXT_PW=TESTPW bash "$BASE/level_$i/solution.sh" 2>/tmp/l$i-sol.err)
    last=$(printf '%s\n' "$out" | last_nonempty)
    [ "$last" = "TESTPW" ] || { echo "  L$i last-line BAD: [$last]"; cat /tmp/l$i-sol.err; exit 1; }
    exit 0
  ); then echo "L$i PROBE PASS (last non-empty stdout line == TESTPW)"; PASS=$((PASS+1)); else echo "L$i PROBE FAIL"; FAIL=$((FAIL+1)); fi
  rm -rf "$H"
done

# id 7 (task): password last + pristine verify FAIL + post-solution verify PASS
H=$(mktemp -d)
if (
  cd "$H" || exit 1
  export HOME="$H"
  NEXT_PW=TESTPW bash -e "$BASE/level_7/setup.sh" >/dev/null 2>&1 || exit 1
  if NEXT_PW=TESTPW bash "$BASE/level_7/verify.sh" >/dev/null 2>&1; then echo "  L7 pristine verify unexpectedly PASSED"; exit 1; fi
  out=$(NEXT_PW=TESTPW bash "$BASE/level_7/solution.sh" 2>/tmp/l7.err)
  last=$(printf '%s\n' "$out" | last_nonempty)
  [ "$last" = "TESTPW" ] || { echo "  L7 last-line BAD: [$last]"; cat /tmp/l7.err; exit 1; }
  NEXT_PW=TESTPW bash "$BASE/level_7/verify.sh" >/dev/null 2>&1 || { echo "  L7 post-solution verify FAILED"; exit 1; }
  exit 0
); then echo "L7 PROBE PASS (last==TESTPW, pristine verify FAIL, post verify PASS)"; PASS=$((PASS+1)); else echo "L7 PROBE FAIL"; FAIL=$((FAIL+1)); fi
rm -rf "$H"

# id 8 (boss): pristine verify FAIL + post-solution verify PASS
H=$(mktemp -d)
if (
  cd "$H" || exit 1
  export HOME="$H"
  NEXT_PW=TESTPW bash -e "$BASE/level_8/setup.sh" >/dev/null 2>&1 || { echo "  L8 setup FAILED"; exit 1; }
  if NEXT_PW=TESTPW bash "$BASE/level_8/verify.sh" >/dev/null 2>&1; then echo "  L8 pristine verify unexpectedly PASSED"; exit 1; fi
  out=$(NEXT_PW=TESTPW bash "$BASE/level_8/solution.sh" 2>/tmp/l8.err) || { echo "  L8 solution errored"; cat /tmp/l8.err; exit 1; }
  last=$(printf '%s\n' "$out" | last_nonempty)
  [ "$last" = "TESTPW" ] || { echo "  L8 last-line BAD: [$last]"; cat /tmp/l8.err; exit 1; }
  NEXT_PW=TESTPW bash "$BASE/level_8/verify.sh" >/dev/null 2>&1 || { echo "  L8 post-solution verify FAILED"; exit 1; }
  exit 0
); then echo "L8 PROBE PASS (badge cat ends on TESTPW, pristine verify FAIL, post verify PASS)"; PASS=$((PASS+1)); else echo "L8 PROBE FAIL"; FAIL=$((FAIL+1)); fi
rm -rf "$H"

echo "PROBE RESULT: $((PASS+FAIL)) levels -> PASS=$PASS FAIL=$FAIL"
[ "$FAIL" -eq 0 ]
```

gate123.py logic (structure/paths/end-markers + extraction):

```python
# ids: yaml.safe_load both files -> level ids == solution ids == range(9), 9 entries
# paths: per setup, regex-collect `mkdir -p X` dirs + `> file`/`>> file` files;
#   per solution line, resolve cat/grep/ls/tree/stat/tail/head/file/cd/pushd/mv/cp
#   path args against a cwd stack (cd/pushd push, popd/.. pop), drop flags and
#   `stat -c FORMAT`/`tail -n N` args, expand `case/*` globs, register mv/cp
#   produced destinations; every ref must be in setup-created or produced set
# end markers: ids 0..7 last non-empty line == 'echo "$NEXT_PW"'
# extraction: dump setup/solution/verify strings to sim/level_<i>/*.sh (LF)
```

## Deviations from instructions (documented, deliberate)

1. **Docker probe replaced by WSL Kali mktemp simulation** — mandated fallback: the
   docker engine was not running (`docker version` → named-pipe not found), and the
   standing linuxgame image predates the current setups anyway. Instruction said
   "PREFER the mktemp simulation on your host … and say so" — done.
2. **id 8 has no `echo "$NEXT_PW"`** — per instruction ("boss, no next"). Its final
   `cat case/badge.txt` nevertheless prints the next password as the last line, because
   the L8 setup writes `$NEXT_PW` into badge.txt — so AUTHORING §3's "last line ==
   next password" also holds for id 8 without an explicit echo, and L8 verify
   (`case/badge.txt` exists, non-empty) passes in the probe.
3. Act-1 shard has no labs (levels/_act1.yaml `labs: []`), so no `labs:` block was
   added to solutions/_act1.yaml — mirrors `_act2.yaml` shape (`solutions:` list of
   `{id, solution}`).
4. `lsp_diagnostics` not usable (SYNC-4, broken language-server process) — yaml/py_compile
   gates used per standing workaround; the YAML parses on both host python and WSL.

## Files changed by this unit
- `linuxgame/solutions/_act1.yaml` — re-authored (60 lines, LF)
- `linuxgame/game/levels.yaml` + `linuxgame/solutions/solutionbook.yaml` — regenerated
  by `tools/_merge_levels.py` (deterministic dump; levels shard untouched)
