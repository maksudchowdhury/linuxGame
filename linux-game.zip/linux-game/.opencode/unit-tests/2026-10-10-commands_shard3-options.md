# Unit Test Record: commands/_shard3.yaml (options gaps)

## Target File
`E:\linux-game\linuxgame\commands\_shard3.yaml`

## Assignment
- Gap 1: six entries (whoami, printenv, bg, fg, nohup, sleep) missing/undersized `options`
  (2-5 items, `flag — meaning` sibling format).
- Gap 2: coverage — add any unassigned shard3-family (system/archives/networking) names
  from `commands-to-incorporate.txt` not yet present in any `_shard*.yaml`.

## Findings on arrival
- Concurrent session (mtime 21:44:33) had already appended `options:` + `group:` keys to
  the six named entries (appended at entry end, after `learn_more`/`group`).
- Residual defects: `whoami` options = 1 item; `time` options = 1 item (spec: 2-5).
- Gap 2: ZERO unassigned names — master list 149 = 33+33+29+31+23 (shard5 parsed defensively, OK).

## Test Code (validation gate — the Commander gate verbatim)

```
python -c "import yaml;d=yaml.safe_load(open(r'E:\linux-game\linuxgame\commands\_shard3.yaml',encoding='utf-8'));cs=d['commands'];req={'name','kind','summary','explain','syntax','options','examples','mistakes','learn_more','runtime'};bad=[c['name'] for c in cs if req-set(c) or not c['options']];assert not bad,bad;assert all(c['runtime'] in ('image','lab') for c in cs);print('SHARD3 OK',len(cs))"
```

## Additional sweep (2-5 options, kind/safe/list-types, LF, uniqueness)

```
python -c "
import yaml
raw=open(r'E:\linux-game\linuxgame\commands\_shard3.yaml','rb').read()
d=yaml.safe_load(raw.decode('utf-8')); cs=d['commands']
req={'name','kind','summary','explain','syntax','options','examples','mistakes','learn_more','runtime'}
probs=[]
for c in cs:
    if req-set(c): probs.append((c['name'],'missing',sorted(req-set(c))))
    if not (2<=len(c['options'])<=5): probs.append((c['name'],'optcount',len(c['options'])))
    if c['runtime'] not in ('image','lab'): probs.append((c['name'],'runtime',c['runtime']))
    if c['kind'] not in ('builtin','binary'): probs.append((c['name'],'kind',c['kind']))
    if not c['examples'] or not any(e.get('safe') is True for e in c['examples']): probs.append((c['name'],'safe-example'))
    if not isinstance(c['mistakes'],list) or not isinstance(c['learn_more'],list): probs.append((c['name'],'list-types'))
names=[c['name'] for c in cs]
print('entries',len(cs),'| unique',len(set(names)),'| CRLF',raw.count(b'\r\n'),'| violations:',probs)
"
```

## Changes made by this session
- `whoami.options`: 1 -> 2 items (`--help — print the built-in help text`,
  `No other flags — just print the effective user name`; `whoami --help` verified in game container).
- `time.options`: 1 -> 2 items (added `COMMAND — the command you want to time`).
- No entries added (Gap 2 leftovers = none).

## Test Result
- Gate: `SHARD3 OK 29`
- Sweep: `entries 29 | unique 29 | CRLF 0 | violations: []`
- Coverage: `master 149 assigned 149 | UNASSIGNED: [] | DUPES: {}`
- Status: pass
- Session: ses_s3opt
- Timestamp: 2026-10-10T21:52:38+06:00
