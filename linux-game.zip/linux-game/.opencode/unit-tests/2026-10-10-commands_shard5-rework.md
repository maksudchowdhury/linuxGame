# Unit Test Record: commands/_shard5.yaml (SYNC-7 dicts + SYNC-8 safe-examples + coverage)

## Target File
`E:\linux-game\linuxgame\commands\_shard5.yaml` (23 entries)

## Assignment (Commander 21:54)
1. SYNC-7: `export`, `seq`, `zip` dict items inside `mistakes` → plain strings.
2. SYNC-8: `unalias` (2 safe) and `clear` (2 safe) → top up to >=3 safe:true each;
   every new example must be RC 0 in `docker exec linuxgame bash -lc "<cmd>"`.
3. Coverage: NO new entries; confirm section 11 (echo..yes) of
   `commands-to-incorporate.txt` is present across shards (report only).

## Findings on arrival (diagnostic, step 6)
```
entries: 23
DICT-MISTAKES export [{'Using export after the equals sign': 'export = NAME is a syntax error.'}]
SAFE_LT3 unalias 2
SAFE_LT3 clear 2
DICT-MISTAKES seq [{'Getting the argument order wrong': 'seq STEP FIRST LAST is not a thing.'}]
DICT-MISTAKES zip [{'Forgetting -r and getting "zip warning': 'name not matched" on a directory.'}]
```
Root cause: plain YAML scalars containing `": "` parse as mappings (export/seq colon
after a word; zip colon inside `zip warning: name ...`).

Container probes (pre-fix):
- `clear` (plain, exec, TERM unset) → `TERM environment variable not set.` RC=1
- `TERM=xterm clear` → RC=0
- `clear --help | head -3` → RC=0 but prints `invalid option -- '-'` (misleading example)
- existing unalias example `alias ll="ls -l"; unalias ll; type ll` → `type: ll: not found` RC=1
  (violates safe=RC 0 → fixed in this round)
- `alias cls="clear"; unalias cls` → RC=0; `unalias -a` (existing) → RC=0

## Changes applied
1. Single-quoted the three offending mistakes scalars (meaning preserved verbatim,
   quotes match this file's existing scalar style):
   - export: `- 'Using export after the equals sign: export = NAME is a syntax error.'`
   - seq: `- 'Getting the argument order wrong: seq STEP FIRST LAST is not a thing.'`
   - zip: `- 'Forgetting -r and getting "zip warning: name not matched" on a directory.'`
2. unalias: added 3rd safe example `- cmd: 'alias cls="clear"; unalias cls'`
   (note: Removes an alias right after defining it — alias's undo button in one line.)
3. clear: added 3rd safe example `- cmd: TERM=xterm clear`
   (note: Sets the terminal type for this one command, so clear works even where TERM
   is not exported.) — `clear --help` rejected: ncurses clear treats `--help` as invalid option.
4. unalias existing example hardened: `type ll || echo "ll is gone"` so it exits 0
   (was RC 1; safe contract = non-destructive AND RC 0).
5. No entries added/removed (count stays 23; header comment untouched).

## Test Code (isolated python gate — the literal Gate A command)
```bash
python -c "import yaml;d=yaml.safe_load(open(r'E:\linux-game\linuxgame\commands\_shard5.yaml',encoding='utf-8'));cs=d['commands'];bad=[c['name'] for c in cs if any(isinstance(m,dict) for m in c['mistakes'])];assert not bad,bad;uns=[(c['name'],sum(1 for e in c['examples'] if e.get('safe') is True)) for c in cs if sum(1 for e in c['examples'] if e.get('safe') is True)<3];assert not uns,uns;req={'name','kind','summary','explain','syntax','options','examples','mistakes','learn_more','runtime'};bad2=[c['name'] for c in cs if req-set(c)];assert not bad2,bad2;assert all(c['runtime'] in ('image','lab') for c in cs);print('SHARD5 OK',len(cs))"
```

## Test Results (pasted outputs)

### Gate A (literal)
```
SHARD5 OK 23
```

### Gate B — CRLF 0, yaml parses, count unchanged (23)
```
CRLF count: 0 LF: 797
entries: 23 unique: 23
all mistakes str: True
safe counts unalias/clear: [('unalias', 3), ('clear', 3)]
```

### Gate C — new/changed examples in container (run count: 3)
```
$ docker exec linuxgame bash -lc 'alias cls="clear"; unalias cls; echo RC=$?'
RC=0
$ docker exec linuxgame bash -lc 'TERM=xterm clear; echo RC=$?'
^[[H^[[2J^[[3JRC=0
$ docker exec linuxgame bash -lc 'alias ll="ls -l"; unalias ll; type ll || echo "ll is gone"; echo RC=$?'
ll is gone
RC=0
(bash: line 1: type: ll: not found  — stderr of the expected failing type, masked by ||)
```
New-example docker run count: 3/3 RC=0.

### Coverage confirmation (report only — no entries added)
```
section 11 names: 13 ['echo', 'printf', 'read', 'export', 'source', 'alias', 'unalias', 'history', 'clear', 'seq', 'true', 'false', 'yes']
per-shard counts: {'_shard1.yaml': 33, '_shard2.yaml': 33, '_shard3.yaml': 29, '_shard4.yaml': 31, '_shard5.yaml': 23} total unique: 149
section 11 MISSING from all shards: []
section 11 present in shard5: 13 / 13
```

### Post-fix content spot-check
```
export mistakes:
    'Forgetting export and wondering why a child process cannot see your variable.'
    'Using export after the equals sign: export = NAME is a syntax error.'
seq mistakes:
    'Getting the argument order wrong: seq STEP FIRST LAST is not a thing.'
    'Forgetting that seq prints to stdout - pipe it or redirect it to be useful in scripts.'
zip mistakes:
    "Using -P on the command line - the password shows up in history and process lists; prefer -e's interactive prompt."
    'Forgetting -r and getting "zip warning: name not matched" on a directory.'
```

## Status
- Status: pass
- Session: ses_sh5r
- Timestamp: 2026-10-10T22:01+06:00
- Note: lsp_diagnostics broken (SYNC-4) — workaround gates = python yaml + container probes.
- Residual (NOT this file's scope): plain `clear` example is RC 1 only when TERM is unset
  (interactive ssh sets TERM; examples_run M4 may need a TERM preset in its exec wrapper).
