#!/bin/bash
set -e
h=$(mktemp -d)
cd "$h"
export NEXT_PW='TESTPW21X'
export HOME="$h"
export LEVEL_ID=21
export LEVEL_USER=level21

# setup
mkdir -p evidence
echo "custody notes" > evidence/chain.txt
echo "final report" > report.txt
printf '%s\n' "$NEXT_PW" > .next_hint
cat > check.sh <<'EOF'
#!/bin/bash
stat -c '%a %n' evidence report.txt check.sh
EOF
chmod 777 evidence report.txt check.sh

echo "=== after setup:"
ls -la
stat -c '%a' evidence
stat -c '%a' report.txt
stat -c '%a' check.sh

echo "=== pristine verify:"
e=$(stat -c '%a' evidence)
r=$(stat -c '%a' report.txt)
c=$(stat -c '%a' check.sh)
echo "e=$e r=$r c=$c"

echo "=== solution:"
chmod 700 evidence
chmod 640 report.txt
chmod 755 check.sh

echo "=== post solution:"
e=$(stat -c '%a' evidence)
r=$(stat -c '%a' report.txt)
c=$(stat -c '%a' check.sh)
echo "e=$e r=$r c=$c"

if [ "$e" = "700" ] && [ "$r" = "640" ] && [ "$c" = "755" ]; then
    echo VERIFY_OK
else
    echo VERIFY_FAIL
fi
