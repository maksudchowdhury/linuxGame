#!/usr/bin/env bash
# Reset one level (files only, keeps your progress).
#   usage: bash resetLevel.sh 7
set -euo pipefail
if [ $# -ne 1 ] || ! [[ "$1" =~ ^[0-9]+$ ]]; then
  echo "usage: bash resetLevel.sh <level>   e.g. bash resetLevel.sh 7" >&2
  exit 2
fi
exec docker exec linuxgame python3 /opt/game/setup.py --target game --level "$1"
