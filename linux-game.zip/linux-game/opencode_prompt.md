# OPENCODE PROMPT: "Nimbus Casebook", an offline Linux detective-CTF trainer

Paste everything below into opencode from the root of the `linuxgame` repo.
Fill every `[FILL: ...]` first. Anything left unfilled, ask me before assuming.

---

## 0. Your role

You are a senior Linux architect and instructional designer. You are teaching complete beginners Linux through a game that feels like a detective story, a CTF, and a Red Hat style lab. You also act as the lead engineer: the game must be reliable, safe, and testable. A broken game wastes a learner's time, so correctness beats feature count.

## 1. Project parameters (I fill these in)

- Learners: [FILL: how many, prior Linux experience, job role]
- Time budget: [FILL: hours per week, total weeks, target number of levels]
- Must-teach skills / certification target: [FILL: e.g. RHCSA/LFCS topics, workplace topics such as reading access logs and config files]
- Story language and tone: [FILL: English / other; serious, witty, or mixed]
- Scoring: [FILL: single learner or several with a scoreboard? instructor view? yes/no]
- Host machine (offline runtime): [FILL: Linux Mint version, Docker version, free RAM and disk]
- Build machine (online): [FILL: Windows version, Docker Desktop or WSL2, CPU architecture (assume linux/amd64)]
- Network exposure: [FILL: localhost only, or other PCs on the LAN may connect?]
- Existing material to reuse: [FILL: cheat sheets, SOPs, favourite commands]
- Sudo/root labs: [FILL: OK to run in the separate `lab` container? y/n]

## 2. First step: read the repo, then audit. Write no new features yet.

The repo already contains a working design (I tested the dashboard logic; Docker/SSH paths were NOT yet tested end to end):

- `docker-compose.yml` with two services: `game` (SSH on host 2222, dashboard on host 9021) and `lab` (SSH on host 2223, user `intern` with sudo, no secrets).
- `Dockerfile`: multi-stage (`base` full Ubuntu 24.04 via `unminimize`, `game`, `lab`).
- `game/levels.yaml`: single source of truth. `game/setup.py` creates users `levelN`, passwords, and hidden files at build time.
- `game/mark.sh`: PAM hook (`pam_exec seteuid`) on `sshd`, `su`, `su-l`. Appends the logged-in user to a root-owned progress file.
- `game/server.py`: stdlib HTTP server run as the unprivileged `gameserver` user. It reads the progress file ("reached") and scans `/proc` for the newest live tty session owned by a `levelN` user ("connected").
- `game/index.html`: dashboard. It shows a welcome screen if nobody is connected, jumps to the connected level's tab, lets the learner reread unlocked levels, and keeps locked levels hidden (the server returns 403).
- Flow: images are built on Windows with internet, exported with `docker save`, carried on a pendrive, and loaded with `docker load` on an OFFLINE Mint machine, then started with `docker compose up -d`.

Deliver Phase 0 first (section 9): a short written audit listing bugs, risks, and untested assumptions (SSH under Docker default capabilities, PAM hook firing for `sshd`, `unminimize` behaviour, man pages working, image size), plus the fixes.

## 3. Hard guardrails (never violate; every change must respect them)

**Runtime is offline.**
- No CDN, no web fonts, no external images/scripts, no `pip`/`apt`/`npm` at runtime. Everything is baked into the image at build time. System font stacks only.
- The dashboard must work with zero internet.

**Secrets never leak.**
- Passwords and flags exist only in the image at build time. Never in story text, goals, hints, command help, API responses, HTML, logs, or error messages.
- `/api/*` returns only what the learner is allowed to see. The only password ever sent is the public level0 starting password.
- Level users must not read other levels' homes, `/opt/game`, `/var/lib/game`, or the scoring data. Level files are `chmod 600/700`, owned by the matching user.
- Level users have NO sudo, no setuid extras, no docker socket, no writable path to the dashboard, scores, or progress.
- Scores and progress are written only by server-side code running as root or `gameserver`. The browser can never POST a score.

**Container safety.**
- No `privileged`, no host networking, no host volume mounts, no Docker socket.
- Keep `mem_limit`, `pids_limit`, and add `ulimit nproc/nofile` for level users so a fork bomb cannot hurt the host.
- Bind ports to `127.0.0.1` by default; LAN exposure is an explicit opt-in documented in the README.
- sshd: password auth only for `level*` (and `intern` in lab), no root login, no port forwarding, `MaxAuthTries` low.
- The game must survive a learner running `rm -rf ~`, `rm -rf /*`, or a fork bomb: `docker compose down && up -d` must always restore a perfect state, and the host must be unaffected.

**Do not break what works.**
- Keep the repo buildable at every commit. One logical change per commit with a clear message.
- Keep `levels.yaml` as the single source: users, passwords, setup, story, hints, scoring, and dashboard data must all derive from it. No duplicated level data anywhere.
- Backward compatible: if you change the schema, write a migration and update the validator.
- Line endings are LF everywhere (the build machine is Windows). Add `.gitattributes` and make the Dockerfile strip `\r` from copied scripts.
- Pin or document every base image and package source. Build must be reproducible on `linux/amd64`.
- No new dependency unless justified in writing. Prefer Python stdlib and plain HTML/CSS/JS.

**Teaching safety.**
- Every exercise must be doable inside the container with only what it provides (offline, no root for game levels).
- No level may require destructive actions on anything but the learner's own sandbox files.
- Never a dead end: a learner who deletes their own clue file can `exit` and reconnect to a restored state, or the level provides a documented recovery path.

## 4. Product vision

### 4.1 Story: "The Case of the Vanished Sysadmin"

Write a detailed, original detective story (classic detective-fiction inspired, no copyrighted text). Nimbus Corp's lead sysadmin vanished the night before a big migration. The server is full of clues. The learner is the new junior investigator. A mentor persona (the "Inspector") appears in short notes and teaches by asking questions, never by lecturing. Plan 5 acts, each with a recurring cast, red herrings, and a mid-act twist:

1. **The Empty Desk**: orientation: `pwd ls cd cat file head tail less`, hidden files, quoting. Very gentle.
2. **The Paper Trail**: search and text: `find grep wc sort uniq cut tr`, pipes, redirects, `diff`.
3. **The Locked Rooms**: users, groups, permissions: `chmod chown umask id groups ls -l`, links, `stat`, special files.
4. **The Night Shift**: processes, logs, time, scheduling: `ps top kill jobs bg fg`, `cron`-style reading, `journal`-style log reading from plain files, `ss/ip` basics, archives `tar gzip`.
5. **The Final Deduction**: scripting and synthesis: `bash` scripts, variables, loops, `sed awk`, `ssh` keys to localhost, `tmux`, `vim` basics, and a capstone that makes the learner combine everything.

Each act ends with a **boss case**: a multi-step puzzle reusing earlier skills, then the final act reveals the culprit using evidence the learner collected.

Target: [FILL: number] levels total. The first 10 levels must be very easy, one new idea each. After that, introduce one hard idea per 2-3 levels with review in between.

### 4.2 Learning curve rules

- One new command or concept per level at the start. Spiral review: older commands reappear in later puzzles.
- Beginner-friendly language. Define terms (path, flag, pipe) the first time they appear.
- No timers, no pressure. Difficulty rises slowly; every 5th level is a lighter "breather" or recap.
- Each level has: story beat, goal, "skills you will use", tiered hints (see 5.3), and a "what you learned" note shown after passing.
- Always teach self-help: every early level nudges `man <cmd>`, `<cmd> --help`, `type`, `help` (for builtins), `apropos`, `whatis`, and tab completion.

### 4.3 Level types (mix them)

1. **Flag hunt (Bandit style)**: find the next password in the sandbox.
2. **Evidence puzzle**: the clue is data (a log, CSV, config); the answer needs interpretation (for example "which IP appears most?").
3. **Lab task, graded (RHEL lab flavour)**: formatted like a Red Hat lab: *Outcomes, Before you begin, Instructions, Evaluation*. A grader checks the learner's work and reveals the next password only if checks pass. In the game container, tasks must stay inside the learner's own account (files, permissions on own files, own scripts, own crontab-style files, archives, symlinks, env vars, SSH keys to localhost). Root-level sysadmin labs (users, sudoers, services) live only in the `lab` container.
4. **Interactive dashboard items**: browser-only practice that grants points: command-to-purpose matching, "order the pipeline" builder, `chmod` octal calculator, "which command?" scenario cards, a file-tree explorer puzzle, and a **deduction board** where the learner assigns collected clues to suspects.
5. **Boss case**: combines 3+ earlier skills, worth more points.

## 5. Dashboard requirements

All data-driven from YAML. No external assets. Keyboard accessible, responsive, readable contrast, reduced-motion respected.

### 5.1 Views
- **Welcome / Guideline**: shown whenever nobody is SSH-connected. Contains: how to open a terminal and SSH in, the starting credentials, how the dashboard follows you, the rules of the game, how points work, how to ask for help (`man`, `--help`), how to reconnect after a reset, and the link to the free practice lab.
- **Level view**: the tab auto-follows the level the learner is SSH-connected to. Earlier unlocked levels stay readable (read-only). Locked levels are not retrievable.
- **Command Library**: searchable list of every command taught.
- **Casebook**: evidence and notes collected so far, plus the deduction board.
- **Score panel**: points, rank title (for example Constable → Detective → Inspector → Chief), badges, hint spend, level completion.

### 5.2 Clickable commands
Every command shown anywhere (level skills chips, library, hints) is clickable and opens a panel generated from `commands.yaml`:
- one-line purpose and a plain-English explanation,
- syntax summary and the 3-6 most useful options,
- **3 safe, copy-pasteable examples** that work in the container and explain their output,
- common mistakes,
- **"Learn more in the terminal"**: exact lines such as `man find`, `find --help`, `man -k keyword`, `whatis find`, `info coreutils`, and how to read a man page (`/` to search, `n` next, `q` quit),
- "Seen in: Level X, Y".
A build-time validator must fail if a command referenced by a level is missing from `commands.yaml` or not installed in the image.

### 5.3 Hints and points
- Hints are tiered: nudge, direction, near-solution (never the password). Each tier costs points. The learner chooses to spend them.
- Suggested scheme (propose adjustments): base points per level by difficulty, bonus for no hints, small bonus for puzzle items, boss cases worth more, points can never go below zero, no time pressure or time penalties.
- Points are computed and stored server-side (for example a JSON file owned by `gameserver`). They persist across `docker compose restart`. They reset only on `down`, and the README documents this. Add an instructor export (`/api/export` bound to localhost or a CLI script) so a mentor can see progress.
- Ranks and badges are cosmetic motivation only.

## 6. Authoring pipeline and validator (build this early)

Extend `levels.yaml` (propose the schema) with: `id`, `act`, `type`, `points`, `story`, `goal`, `commands`, `hints` (tiered with costs), `learned`, `setup`, `solution` (author-only; NEVER copied into the served data or the runtime image), `verify` (graded labs), `casebook` entries.

Add `tools/validate_levels.py`, run during build and in CI. It fails the build if:
- users or passwords are duplicated, or a password is weak or appears in any learner-visible text,
- a command is referenced but undocumented or not installed,
- a level's `solution` does not actually produce the next credential (automated solvability test),
- a graded lab's `verify` passes on the untouched state (it must FAIL initially),
- any story/hint text is missing, too long, or contains forbidden strings.

## 7. Test suite (guardrail against breakage)

Provide `tests/` plus a one-command runner for Windows (PowerShell or `make` under WSL) that:
1. builds both images from scratch,
2. starts compose and waits for health,
3. solves **every level over SSH** using its author `solution`, asserting the dashboard moves to each level and points update correctly,
4. asserts isolation: as `levelN`, reading `level(N+1)`'s home, `/opt/game`, `/var/lib/game`, scores, and `levels.yaml` all fail; `sudo -l` shows nothing; no setuid binaries beyond Ubuntu defaults,
5. crawls every `/api/*` response and greps for any known password or flag,
6. simulates abuse: `rm -rf ~`, a fork bomb, filling the disk in the home dir, then `compose down/up` and verifies a clean state,
7. runs the stack with outbound network disabled to prove it needs no internet,
8. verifies `man`, `vim`, `sudo` (lab), and the clickable-command examples all execute.
Fail loudly with readable messages.

## 8. Things I may have missed: include them

- Offline export bundle: one script produces `linux-game.tar` + Docker `.deb` files + README + instructor guide, and checks the tar loads.
- Instructor guide (separate file, NOT in the image): full solutions, learning objectives per level, suggested pacing, and a skills checklist.
- Reset and recovery documentation, including a clear statement of what persists across restart vs `down`.
- Versioning and a CHANGELOG; the dashboard footer shows the build version.
- Image-size budget and a note on what `unminimize` adds.
- A "cheat sheet" PDF/Markdown generated from `commands.yaml` for printing.
- Honest limits: `systemctl`, `hostnamectl`, `journalctl` need systemd and do not work in a container. Do not fake them. Teach them with plain-text log files in the game, and propose a separate optional VM module for real systemd practice.
- Accessibility and a calm tone for anxious beginners.

## 9. How to work (strict protocol)

Work in phases. **Finish one phase, show me the diff summary and test results, then STOP and wait for my approval.** Never start the next phase on your own.

- **Phase 0**: read the repo, audit, fix defects, add the base test (a login on each service works, dashboard follows the SSH session).
- **Phase 1**: schema design, validator, full test harness (sections 6 and 7) against the existing 6 levels.
- **Phase 2**: `commands.yaml`, command panel, Command Library.
- **Phase 3**: guideline page, points, tiered hints, ranks, instructor export.
- **Phase 4**: Act 1 and Act 2 story and levels, with passing solvability tests.
- **Phase 5**: graded lab type and the `lab` container's RHEL-style labs; interactive puzzle items; deduction board.
- **Phase 6**: Acts 3-5, boss cases, final reveal.
- **Phase 7**: polish, accessibility pass, offline export bundle, instructor guide.

At the start of each phase: state the plan, list files you will touch, and list open questions. Before declaring a phase done: run the whole test suite, paste the results, update the README and CHANGELOG, and list anything you could not verify.

If something is ambiguous, ask me. Never silently invent requirements, never weaken a guardrail to make a test pass, and tell me plainly if you cannot test something in your environment.
