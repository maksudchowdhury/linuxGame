# Nimbus Casebook — Story Bible (structural outline)

Level authors: follow this outline exactly (ids, types, titles, mechanics, chips).
Expand story prose, hints, setup, and casebook text yourself — playful, intuitive,
beginner-friendly. Mechanics must satisfy the contracts in `AUTHORING.md`.
Where a mechanic sketch says "pw", the `setup` script hides `$NEXT_PW` accordingly.

## Cast

- **Junior Investigator** — the learner. Addressed as "Investigator".
- **Inspector Prompt** — mentor. Leaves short NOTES that ask questions
  ("What would `ls -a` say about a 'empty' folder?"), never lectures.
- **Morgan Vault** — the vanished lead sysadmin (victim). Loved locks, hidden
  files, and passive-aggressive sticky notes.
- **Milo** — the intern. Over-helpful, speaks in bullet points. Red herring.
- **Dee Vider** — night-shift ops. Talks in log lines and ratios. Red herring.
- **Ada Looper** — automation fanatic; "it loops, it loops". Red herring.
- **Cache Money** — retired admin who still thinks he has root. Comic relief.
- **The CFO** — only speaks in spreadsheet cells. Red herring.
- Company: **Nimbus Corp** (hostname `nimbus`). Story page: http://localhost:9021.

## Act arcs & twists

1. **The Empty Desk** (L0–L8): orientation. Twist: the desk was *not* empty —
   Morgan hid a vault behind "nothing".
2. **The Paper Trail** (L9–L18): search & text forensics. Twist: the access logs
   were **edited** — someone covered their tracks.
3. **The Locked Rooms** (L19–L25): permissions & identity. Twist: files were
   **re-owned after the fact**; the badge logs disagree with the file metadata.
4. **The Night Shift** (L26–L36): processes, system, network, archives. Twist:
   the nightly "backup" job was **packing things up, not saving them**.
5. **The Final Deduction** (L37–L47): scripting & synthesis. Reveal: Morgan's
   still-alive tmux session holds his last message; the evidence board convicts
   **Dee Vider** — copied the migration keys into a hidden archive to sell to
   Stratus Corp; Morgan chased after him. Milo is innocent (always was).

## Chain levels (48)

Format: **L*id* · type · title** — mechanic — chips — points · casebook clue.

### Act 1 — The Empty Desk (L0–L8)

- **L0 · flag · The New Badge** — `pwd`, `ls`, `cat`: welcome folder contains
  `readme.txt` with the next key. 100 · clue: `c-sticky` Morgan's sticky note
  ("Back in 5. Or 500.").
- **L1 · flag · Behind the Dust** — hidden files: plain `ls` shows nothing;
  `ls -a` reveals `.vault`. chips: `ls`, `cd`. 100 · clue: `c-scratch` a
  scratched-off combination on the vault note.
- **L2 · flag · The Awkward Filename** — file literally named
  `my secret notes.txt` (decoy `notes.txt` too). Quoting / Tab completion.
  chips: `cat`, `ls`, `cd`. 100.
- **L3 · flag · A Place for Everything** — scattered papers; make folder
  `case`, move the memos in, then identify the real key file with `file`
  (the others are PNG/pdf fakes). chips: `mkdir`, `mv`, `file`. 110 ·
  clue: `c-moved` a memo that was moved and re-hidden.
- **L4 · flag · First Look Backwards** — key is the last line of a 40-line
  letter: `tail` (and `head`/`less` as alternate routes). chips: `head`,
  `tail`, `less`. 100.
- **L5 · breather · The Bigger Picture** — gentle: folder maze via `tree`,
  then `stat` on three candidate files — the biggest one holds the key
  (no other idea needed). chips: `tree`, `stat`. 80.
- **L6 · flag · The Long Hallway** — navigate a deep maze following
  directions ("go where the directory name points"), using the directory
  stack; extract the final folder's basename as a sanity check, read the key
  file. chips: `pushd`, `popd`, `dirs`, `basename`, `dirname`. 120 ·
  clue: `c-path` Morgan's note about "path of least resistance".
- **L7 · task · The Label Maker** (graded) — create exactly `report.txt`
  (copy of `source.txt`) and `report.bak` (backup copy), plus `notes/`
  folder. Server grades via `verify`, then writes the next key to
  `~/.cleared`. chips: `touch`, `cp`. 150. Teach the "Check my work" flow.
- **L8 · boss · The Empty Desk** — boss: multi-step use of
  `ls cd cat file head tail stat tree mkdir mv` through Morgan's desk
  labyrinth to the final key. 250 · clue: `c-deskplate` engraved plate
  "V. = visibility".

### Act 2 — The Paper Trail (L9–L18)

- **L9 · evidence · The Migration Phrase** — `grep -r` across 30 logs for the
  phrase "migration keys" → matching line carries the key. chips: `grep`,
  `find`. 120 · clue: `c-phrase` the phrase "migration keys" appears 3×.
- **L10 · evidence · The Odd File Out** — find the only file whose line
  count is exactly 7 with `wc -l`, then read it. chips: `wc`, `ls`. 110.
- **L11 · evidence · Double Vision** — duplicated export; the unique line is
  the key: `sort | uniq -u`. chips: `sort`, `uniq`. 120 · clue: `c-dupe`
  one export is doubled-up — the tampering starts here.
- **L12 · evidence · Cutting Remarks** — roster lines `name|role|key`; extract
  field 3 with `cut`, trim stray characters with `tr`. chips: `cut`, `tr`. 120.
- **L13 · evidence · Pipe Dream** — build a three-stage pipeline
  (`grep | cut | sort`) and save a copy of the result with `tee found.txt`.
  chips: `tee`, `grep`, `cut`, `sort`. 130 · clue: `c-timestamps` a log
  line with an impossible timestamp (the edit).
- **L14 · evidence · The Ledger Column** — whitespace-separated night ledger;
  print column 4 with `awk`. chips: `awk`, `nl`. 120.
- **L15 · evidence · Sed Aside** — the key is written with decoy dashes
  (`ab-cd-ef…`): `sed 's/-//g'` cleans it. chips: `sed`. 120.
- **L16 · evidence · A Difficult Truth** — two manifests; `diff`/`cmp` show
  exactly one changed line — it names the file holding the key.
  chips: `diff`, `cmp`. 130 · clue: `c-manifest` manifest B differs by ONE
  line — someone edited the record.
- **L17 · task · Split Decision** (graded) — split `incident.txt` into
  10-line chunks (`split -l 10`) named exactly `part_`; graded reveal.
  chips: `split`. 150.
- **L18 · boss · The Paper Trail** — boss: comm/xargs/formatting review
  (`comm`, `xargs`, `fmt`/`fold` peek) + earlier search tools; two suspect
  lists compared, the unique name's file holds the key. 250 · clue:
  `c-lists` the two duty lists don't match — one name was added.

### Act 3 — The Locked Rooms (L19–L25)

- **L19 · flag · Permission Slip** — `ls -l` reads the story: the key file
  is mode 000; owner (you) restores it with `chmod u+r`. chips: `chmod`,
  `ls`. 120 · clue: `c-mode0` a file locked to 000 — panic, not planning.
- **L20 · flag · Group Project** — file group `nightshift` mode 640;
  `id` proves you're in the group; then practice `chgrp` on a copy of your
  own file. chips: `id`, `chgrp`. 120 · clue: `c-badge` the nightshift
  group's badge log.
- **L21 · task · Chain of Custody** (graded) — produce exact modes:
  `evidence/` = 700, `report.txt` = 640, `check.sh` = 755, verified then
  revealed. chips: `chmod`, `stat`. 150.
- **L22 · flag · The Hard Link** — find the inode twins with `ls -i`;
  the second name of the twin pair holds the key (`ln` hard link story).
  chips: `ln`, `stat`. 130 · clue: `c-inode` two names, one inode — someone
  left a back door.
- **L23 · flag · Symlink Street** — follow a chain of symlinks (`ls -l`
  shows targets) to the real file. chips: `ln`, `ls`. 130.
- **L24 · flag · The Pipeline Room** — a named pipe: read from it while a
  writer fills it (background `&` + `cat`); `mkfifo` story. chips:
  `mkfifo`. 130 · clue: `c-fifo` a pipe left open on the floor.
- **L25 · boss · The Locked Rooms** — boss: permissions forensics
  (`chmod stat ln id file tree` + review) to rebuild Morgan's lock
  scheme; the re-owned file's history points to the night shift. 250 ·
  clue: `c-reowned` mtimes say files were re-owned AFTER the disappearance.

### Act 4 — The Night Shift (L26–L36)

- **L26 · evidence · The Server's Vitals** — collect system identity; the
  file whose contents match `uname -m`'s answer holds the key. chips:
  `uname`, `hostname`, `whoami`, `date`, `cal`. 120.
- **L27 · evidence · Room for More** — disk story: `du` finds the fattest
  folder (a bloated "archive"); the key sits inside it. chips: `df`, `du`,
  `free`, `uptime`, `ps`. 120 · clue: `c-fatdir` a directory 10× fatter
  than its siblings.
- **L28 · flag · Environmental Matter** — `~/.bashrc` exports
  `NIGHT_SHIFT_KEY` at login; discover it with `printenv`/`env`/`set`.
  chips: `env`, `printenv`, `set`. 130 · clue: `c-envnote` Morgan logged
  keys "the lazy way".
- **L29 · task · The Cron Reading Room** (graded) — read the plain files in
  `/etc/cron.d`, identify the job that runs nightly, write its name to
  `answer.txt`; graded reveal. chips: `ls`, `grep`, `find`. 150 ·
  clue: `c-0300` something runs at 03:00 — every night.
- **L30 · breather · Compressed Reading** — gentle recap: a gzipped memo —
  `zcat`/`zgrep` read it without unpacking; `gzip`/`gunzip` basics; peek at
  `top -b -n1` for fun. chips: `gzip`, `gunzip`, `zcat`, `zgrep`, `top`. 80.
- **L31 · flag · Kill the Noise** — start the provided `noisy.sh`
  (learner's own background job), find it with `ps`/`pgrep`, stop it with
  `kill`; stopping it prints the key to `quiet.txt`. chips: `ps`, `pgrep`,
  `pkill`, `kill`. 130.
- **L32 · flag · Background Business** — run `slow_calc.sh` in the
  background (`bg`/`jobs`), let it finish (`nohup`, `sleep`), read its
  output. chips: `jobs`, `bg`, `fg`, `nohup`, `sleep`. 130.
- **L33 · evidence · Tick Tock** — two identical-looking scripts; `time`
  shows which is slower — the slower one's folder holds the key;
  `watch`/`nice`/`renice`/`killall` flavour. chips: `time`, `watch`,
  `nice`, `renice`, `killall`. 130.
- **L34 · evidence · Ports in the Night** — read the candidate port list,
  use `ss`/`netstat` to see what is actually listening (plus `ip`, `ping`,
  `ifconfig` recon), open the right key file. chips: `ss`, `netstat`,
  `ip`, `ifconfig`, `ping`. 130 · clue: `c-listener` one listener that
  shouldn't be there.
- **L35 · evidence · Fetch the Breadcrumb** — `curl`/`wget` the local
  dashboard, extract the PUBLIC start password from the welcome text, unzip
  `oldbox.zip` with it (`unzip -P`), decode the base64 line inside.
  chips: `curl`, `wget`, `nc`, `zip`, `unzip`, `base64`. 140 · clue:
  `c-oldbox` Morgan's old box still uses the start password.
- **L36 · boss · The Night Shift** — boss: archive forensics: find
  (`tree`/`file`), unpack `tar` variants (`.tgz`, `.tar.bz2` via `bzip2`,
  `.tar.xz` via `xz`), verify candidates with `md5sum`/`sha256sum`,
  the matching checksum's file holds the key. chips: `tar`, `bzip2`,
  `xz`, `md5sum`, `sha256sum`. 250 · clue: `c-backup` the "backup" job
  only ever *writes outward*.

### Act 5 — The Final Deduction (L37–L47)

- **L37 · flag · Echoes** — a greeting script that `read`s your input and
  `printf`s the welcome; say Morgan's nickname (given in story) to get the
  key; `echo`/`>>` timeline practice. chips: `echo`, `printf`, `read`. 120.
- **L38 · flag · Set in Stone** — `source notes.env` loads exported
  variables; `history`/`clear` flavour; find the exported key var.
  chips: `export`, `source`, `history`, `clear`. 130 · clue: `c-histline`
  one shell-history line from Morgan's last session.
- **L39 · flag · Exit Codes** — three check scripts; only the one built on
  `true` (exit 0) unlocks the folder — `&&`/`||` chains; `yes` as an
  inside joke (needs Ctrl-C). chips: `true`, `false`, `yes`, `seq`. 130.
- **L40 · flag · Expressions Everywhere** — a numeric door built from
  `expr` math; `eval`/`exec` explained as sharp tools. chips: `expr`,
  `eval`, `exec`. 130.
- **L41 · task · The Repetition Compulsion** (graded) — write `build_case.sh`
  using a loop to produce exactly 12 numbered evidence files; graded reveal.
  chips: `seq`, `echo`, `read`. 150.
- **L42 · evidence · Stream Editing the Trail** — reconstruct Morgan's last
  note: `sed` un-scrambles it, `awk` pulls the final column (review at
  depth). chips: `sed`, `awk`. 140.
- **L43 · flag · Keys to the Kingdom** — `ssh-keygen` a keypair (empty
  passphrase), install it into `authorized_keys`, then `ssh level43@localhost
  whoami` without a password; `scp`/`rsync` the evidence to `~/sent/` over
  loopback. chips: `ssh`, `scp`, `rsync`, `ssh-keygen`. 150 · clue:
  `c-authorized` Morgan's key was added to someone else's box.
- **L44 · flag · The Window That Stays Open** — start a detached `tmux`
  session that runs `last_words.sh` (writes the key file after 2s);
  `tmux ls` proves it's alive. chips: `tmux`. 150 · clue: `c-tmux` a
  detached session still running — Morgan never logged off.
- **L45 · flag · The Final Editor** — fix the two broken lines of
  `confession.txt` with `vim` (ex mode / guided in hints), then read the
  repaired key. chips: `vim`. 150.
- **L46 · task · The Reconstruction** (graded) — capstone prep: one shell
  script that greps, sorts, chmods and archives its own output; graded
  reveal. chips: `grep`, `sort`, `chmod`, `tar`. 150.
- **L47 · capstone · The Final Deduction** — combine everything: unpack the
  hidden archive, decode (base64/sed/awk), rebuild the timeline script,
  verify checksums, and produce `CASE-CLOSED`. Graded by `verify` (required);
  passing sets `closed`, plays the finale, awards Chief rank. chips:
  `tar`, `base64`, `sed`, `awk`, `sha256sum`, `ssh-keygen`, `tmux`, `vim`.
  300 · final reveal served by the dashboard.

## Interactive sidecar puzzles (6)

- **match-1 · Command Line-up** (act 1, requires 0): match purpose → command.
  chips: `pwd`, `cat`. 50.
- **tree-1 · Where Does It Live?** (act 1, requires 5): given a tree, click
  the path holding the evidence. chips: `tree`, `file`. 50.
- **order-1 · Build the Pipeline** (act 2, requires 11): order the steps of
  "find the unique line". chips: `uniq`, `sort`. 50.
- **chmod-1 · The Octal Calculator** (act 3, requires 19): symbolic ↔ octal
  drill. chips: `chmod`. 50.
- **scenario-1 · Which Command?** (act 4, requires 26): situation cards
  (disk full? listening ports? biggest folder?). chips: `du`, `ss`, `ps`,
  `df`. 50.
- **order-2 · Case Reconstruction** (act 5, requires 38): order the steps of
  Morgan's last night (story ordering + command ordering). chips: `awk`,
  `tar`. 50.

## Lab sidecar levels (5) — lab container, user `intern`, sudo OK

- **first-users · The User Files** (act 3, requires 19, 150): create two
  users (`nshift1`, `nshift2`), a group `nightshift`, add them, set a known
  password policy, demonstrate `su` between them; `verify` checks the
  user/group state. chips: `useradd`, `usermod`, `userdel`, `passwd`,
  `groupadd`, `su`.
- **package-desk · The Package Desk** (act 4, requires 26, 150): offline
  package forensics — `dpkg -l` inventory, `apt-cache` queries,
  `apt-mark` showhold; `add-apt-repository` documented as man-page
  literacy (offline reality). `verify` checks the inventory file.
  chips: `apt`, `apt-get`, `apt-cache`, `dpkg`, `apt-mark`,
  `add-apt-repository`.
- **network-room · The Network Room** (act 4, requires 26, 150): recon the
  lab — `ip a`, `ss -tln`, `ping 127.0.0.1`, `nc -z` sweep, then man-page
  literacy for `traceroute`/`dig`/`nslookup`/`host` (offline honesty);
  `verify` checks `recon.txt`. chips: `traceroute`, `dig`, `nslookup`,
  `host`, `nc`.
- **backup-run · The Backup Run** (act 4, requires 26, 150): build a real
  backup with `tar` + `cpio` + `dd` + `rename` + `bzip2`, verify checksums;
  `verify` checks the artifact. chips: `cpio`, `dd`, `rename` (plus tar/bzip2 review).
- **sudo-etiquette · Sudo Etiquette** (act 5, requires 37, 150): write a
  `/etc/sudoers.d/` rule granting a limited command to a helper user,
  prove it with `sudo -u`, clean up; `verify` checks the rule. chips:
  `sudo`, `alias`, `source`.

## Coverage note

Commands NOT placed above (should be none after authors place chips):
`gunzip`→L30, `zcat/zgrep`→L30, `tr`→L12, `paste/join`→place in L13/L14
(Act 2 author: add to an evidence level), `od/column/pr/fold/fmt/shuf`→
Act 2 author may attach to L18 boss or split across L10/L13 as "formatting
notes" flavour; `more`→L4 author (alternate to `less`); `whoami`→L26;
`whereis/locate/which/type/egrep`→Act 2 author (search family, e.g. L9/L10);
`xargs`→L18; `apt` family→package-desk lab; `ifconfig`→L34; `time`→L33.
Act authors: if a command from YOUR act's list is still unplaced after your
draft, attach it to a fitting level rather than inventing new levels.
