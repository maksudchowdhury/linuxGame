# Nimbus Casebook — Authoring Guide (schema, contracts, guardrails)

Single source of truth: `linuxgame/game/levels.yaml` (merged from act shards) +
`linuxgame/commands/commands.yaml` (merged from shards) + `linuxgame/game/secrets.yaml`
(generated, never hand-edited) + `linuxgame/solutions/solutionbook.yaml` (author-only,
NEVER copied into the runtime image).

Tone: playful, witty, intuitive detective story — never corporate, never boring.
Beginner rules: one new idea per level early on; define terms (path, flag, pipe,
permission, process) the first time they appear anywhere; no timers; every level
nudges self-help (`man`, `--help`, `type`, `apropos`, tab completion).

## 1. `levels.yaml` structure

```yaml
version: 1
meta:
  title: Nimbus Casebook
  ranks:
    - {name: Constable, at: 0}
    - {name: Detective, at: 800}
    - {name: Inspector, at: 2000}
    - {name: Chief, at: 3500}
  hint_costs: {nudge: 5, direction: 15, near: 30}
  base_points: {flag: 100, evidence: 120, task: 150, breather: 80, boss: 250, capstone: 300}
levels:        # THE CHAIN — index = level number, sequential from 0. Credential chain.
  - id: 0
    act: 1
    type: flag            # flag | evidence | task | breather | boss | capstone
    title: The New Badge
    points: 100           # optional; defaults from meta.base_points by type
    story: |
      2-5 short paragraphs. Playful detective prose. Inspector Prompt leaves notes
      that ASK questions instead of lecturing.
    goal: |
      One or two sentences: exactly what to achieve. Never contains a password.
    commands: [pwd, ls, cat]     # chips shown on the level; see rules below
    hints:
      - {tier: nudge, text: ...}
      - {tier: direction, text: ...}
      - {tier: near, text: ...}       # 1-3 hints; near = almost-solution, NEVER the password
    learned: |
      Shown AFTER the level is passed. Short recap + self-help pointers.
    setup: |
      bash -e script. Runs at IMAGE BUILD as root, cwd = /home/levelN.
      Env: NEXT_PW (next chain level's password; "" on the last chain level),
      LEVEL_ID, LEVEL_USER. May create files/folders, add groups (usermod), etc.
      Never echo $NEXT_PW to stdout.
    solution: |
      bash script. Runs at IMAGE BUILD as user levelN, cwd = /home/levelN,
      env NEXT_PW. MUST print the next password as the LAST line of stdout
      (nothing after it). This is the automated solvability test.
      EXCEPTION: the final `capstone` level has no next password — it must
      define `verify` instead, and its solution just performs the task.
    verify: |            # OPTIONAL — required for type: task and capstone
      bash grader. Runs as levelN. exit 0 = passed.
      MUST exit non-zero on the pristine (post-setup, pre-solution) state.
      After `solution` runs, MUST exit 0. Never contains a password.
    casebook:            # OPTIONAL evidence entries (collected when level <= reached)
      - {id: c-desk, title: Sticky note, text: "..."}   # <= 300 chars
interactive:   # browser-only point puzzles; NO role in the credential chain
  - id: match-1
    act: 1
    title: Command Line-up
    requires: 0          # unlocked when reached >= requires
    kind: match          # match | order | chmod | scenario | tree
    points: 50
    commands: [ls, cat]  # chips (count toward command coverage)
    teach: |             # short framing text shown above the puzzle (no password)
    data: {...}          # kind-specific, see below
    answer: ...          # validated SERVER-SIDE only; never sent to the browser before pass
labs:          # practice-lab sidecar levels (lab container, user intern, sudo)
  - id: first-users
    act: 3
    title: The User Files
    requires: 19         # unlocked when reached >= requires
    points: 150
    commands: [useradd, usermod, userdel, passwd, groupadd, su]
    story: | ...
    goal: | ...
    hints: [{tier: nudge, text: ...}, ...]   # 1-3
    learned: | ...
    setup: |             # runs at LAB IMAGE BUILD as root, cwd = /home/intern
    solution: |          # runs at LAB BUILD as intern (sudo OK); build-time test
    verify: |            # REQUIRED for labs; graded at runtime by the server via ssh
```

### 1b. Act shard files (exactly two per act — merge step S2.4.6 joins them)

The schema above shows `solution:` for reference only. **Shards keep solutions in
their own file**, so a solution can never leak into the runtime image.

**`linuxgame/levels/_actN.yaml`** — runtime content, **NO `solution:` key**:

```yaml
levels:
  - id: 19
    act: 3
    type: flag          # flag | evidence | task | breather | boss | capstone
    title: Permission Slip
    points: 120
    story: |
      ...
    goal: |
      ...
    commands: [chmod, ls]
    hints:
      - {tier: nudge, text: ...}
      - {tier: direction, text: ...}
      - {tier: near, text: ...}
    learned: |
      ...
    setup: |
      ...               # hides $NEXT_PW; never prints it
    verify: |           # ONLY for type task/boss/capstone
      ...
    casebook: [{id: c-mode0, title: ..., text: ...}]
interactive: []         # only if this act owns puzzles (STORY_BIBLE)
labs: []                # only if this act owns labs (STORY_BIBLE)
```

**`linuxgame/solutions/_actN.yaml`** — author/build-only, never copied into the image:

```yaml
solutions:
  - id: 19
    solution: |
      ...               # runs as levelN; LAST stdout line = next password
```

Merge rules: `game/levels.yaml` = `meta` + union of all `levels`/`interactive`/`labs`
(solutions stripped) ; `solutions/solutionbook.yaml` = union of all `solutions`.
**No `password:` key exists in any shard** — passwords are generated into
`game/secrets.yaml` by `tools/gen_secrets.py`.

### Interactive `kind` payloads

- `match`: `data: {pairs: [{left: "list files", right: "ls"}, ...]}` (4-6 pairs),
  `answer: {pairs: [[left, right], ...]}` — server checks the submitted mapping.
  Submit format: `{"pairs": [["list files","ls"], ...]}`.
- `order`: `data: {steps: ["sort lines", "drop duplicates", "print unique line"]}` in
  CORRECT order shown to author; `answer: ["sort lines", ...]`. Browser shuffles them.
- `chmod`: `data: {questions: [{files: "rw-r--r--", octal: "644"}, ...]}` (3-4),
  `answer: ["644", ...]` — browser shows symbolic, learner types octals (or reverse).
- `scenario`: `data: {cards: [{situation: "...", options: ["ps","df","du"], answer: "du", why: "..."}, ...]}` (3-4),
  `answer: ["du", ...]`.
- `tree`: `data: {tree: {name: "/home/levelX", children: [...]}, question: "...",
  options: ["/home/levelX/a/b.txt", ...]}`, `answer: "/home/levelX/a/b.txt"`.

## 2. Command chips (`commands` field)

- Chip strings MUST equal a `name` in `commands/commands.yaml` exactly.
- Use the bare command name (`ls`, `grep`), never `ls -a` or `pipe`.
- Concepts (quoting, Tab completion, pipes `|`, redirects `>` `>>`) go in story/goal/hints prose.
- Every command in `commands.yaml` must appear as a chip on AT LEAST ONE entry
  (chain, interactive, or lab) — the validator fails otherwise.

## 3. Solvability & grading contracts (validator enforces ALL of this)

1. Chain: `setup` (root) → pristine `verify` (if present) must FAIL → run `solution`
   as levelN → last stdout line == next level's password (from secrets.yaml) →
   `verify` (if present) must PASS.
2. Labs: same, except no password output requirement: `solution` then `verify` must PASS;
   pristine `verify` must FAIL. (Lab `solution` runs as intern, sudo allowed.)
3. No dead ends: a learner who deletes a clue can reconnect (`compose down/up` restores).
   Never require destroying anything outside the learner's own sandbox files.
4. `verify` runs at RUNTIME via the server (ssh as levelN / intern) and on PASS the
   server writes the next chain password into the learner's home as `~/.cleared`
   (chain task levels only). The password NEVER travels over HTTP.

## 4. Hard guardrails (never violate)

- **No password ever appears in** title, story, goal, commands, hints, learned,
  casebook, teach, data, labs text, or ANY API response except `start_password`
  (level 0 only, public `begin`). The validator greps every learner-visible field
  against every password in secrets.yaml (case-insensitive substring).
- **Offline**: no external URLs/hosts anywhere (allowed: `localhost`, `127.0.0.1`).
  No CDN, no web fonts, no pip/apt/npm at runtime.
- **No destructive reach**: exercises touch only the learner's own files (game) or
  the intern's scratch space (lab). No `rm -rf /`, no fork bombs required to pass.
- **Solutions stay out of the runtime image**: they live in `solutions/solutionbook.yaml`
  only. Never inline a solution into levels.yaml.
- LF line endings, UTF-8. No `[FILL`, `TODO`, `FIXME`, `lorem` in any shipped text.
- Text budgets: title ≤ 40 chars, goal ≤ 400, story ≤ 1600, hint ≤ 400,
  learned ≤ 500, casebook text ≤ 300.

## 5. Story spine (summary — full outline in STORY_BIBLE.md)

Nimbus Corp. Lead sysadmin **Morgan Vault** vanished the night before "the Great
Migration". Learner = Junior Investigator. Mentor = **Inspector Prompt** (short
notes, asks questions). Suspects: **Milo** (the intern, bullet-points), **Dee Vider**
(night shift, speaks in log lines), **Ada Looper** (automation fanatic), **Cache
Money** (retired root-holder), **the CFO** (spreadsheets only, red herring).
5 acts, each ends with a boss case; mid-act twists; Act 5 reveals the culprit
using evidence from the casebook.
