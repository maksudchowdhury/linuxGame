# Nimbus Casebook — API Contract (server.py ↔ index.html)

All responses JSON unless noted. `Cache-Control: no-store` always.
Errors: `{"error": "<code>"}` with 403 (locked), 400 (bad input), 409 (state conflict).

## GET / and /index.html
text/html — the dashboard (single file, no external assets, offline).

## GET /api/state
```json
{
  "connected": 7,            // level id of live terminal session, or null
  "reached": 9,              // highest level ever logged into (PAM progress)
  "total": 48,               // chain length
  "scores": {                // server-owned, /var/lib/game/scores.json
    "total": 1450,           // sum of earned points (puzzles+tasks+labs+deductions)
    "by_level": {"0": 100, "1": 100},
    "puzzles": {"match-1": true},
    "labs": {"first-users": 150},
    "deductions": {"L47": 300},
    "hints_used": {"2": [0, 1]}   // level -> hint indices already revealed
  },
  "rank": {"name": "Detective", "next": "Inspector", "next_at": 2000},
  "levels": [ {"n":0,"act":1,"type":"flag","title":"...","status":"done|open|connected|locked","points":100} ],
  "interactive": [ {"id":"match-1","act":1,"title":"...","requires":0,"points":50,"done":false} ],
  "labs": [ {"id":"first-users","act":3,"title":"...","requires":19,"points":150,"done":false,"verified":false} ],
  "clues": ["c-sticky"],      // casebook clue ids collected so far
  "closed": false,            // true after L47 capstone passes
  "ssh_port": 2222, "lab_port": 2223,
  "start_password": "begin"   // ONLY password ever exposed (level 0)
}
```

## GET /api/level?n=<id>
Only for `n <= reached`. Chain levels:
```json
{"n":12,"act":2,"type":"evidence","title":"...","story":"...","goal":"...",
 "commands":["cut","tr"],"points":120,
 "hint_count":3,"hints":0,          // hints revealed so far for this level
 "clue":"c-phrase",                 // clue id granted on pass (nullable)
 "lab":null,                        // or lab id for act-gated lab levels
 "next_user":"level13"}             // null on last level
```
Interactive (id given as `n="match-1"` string — actually served by /api/puzzle GET-less; see below).
**Never includes solutions, passwords (except start), or `setup` scripts.**

## GET /api/commands
```json
{"commands":[{"name":"grep","kind":"binary","group":"search","act":2,"summary":"...","syntax":"grep [opts] PATTERN FILE",
  "options":[{"flag":"-r","meaning":"recurse"}],
  "examples":[{"cmd":"grep -r 'key' logs/","note":"...","safe":true}],
  "mistakes":["..."],"learn_more":["man grep","grep --help","whatis grep"],"runtime":"image|lab"}],
 "acts":{"1":[...ids],"2":[...]} }
```

## GET /api/casebook
```json
{"clues":[{"id":"c-sticky","act":1,"level":0,"title":"Sticky Note","text":"..."}],
 "board":{"suspects":[...],"locked":"Dee Vider"}}   // finale board data
```

## POST /api/hint  `{"n": 12}`
- 403 if `n > reached` or all hints exhausted (`error:"no_more"`).
- 409 if total score < cost (`error:"low_score"`).
- Else spends cost (5/15/30 by hint index), returns:
  `{"hint":"...","cost":15,"total":1435,"index":1}`

## POST /api/verify  `{"n": 7}`  (graded task/boss/capstone levels)
- 403 if locked. Server ssh's `level<n>@localhost` (password from
  secrets, env-only) and runs the level's `check` script.
- Pass: writes next password to learner `~/.cleared`, grants points +
  clue, returns `{"ok":true,"points":150,"total":1650,"clue":"...","bonus":false}`
  (capstone adds `"closed":true`).
- Fail: `{"ok":false,"missing":["report.bak"],"feedback":"..."}` 400.

## POST /api/puzzle  `{"id":"match-1","answer":{...}}`
- 403 if `reached < requires`. One attempt scored; wrong → `{"ok":false,"why":"..."}`.
- Right: `{"ok":true,"points":50,"total":...}`; idempotent (replay = ok, 0 pts).

## POST /api/labverify  `{"id":"first-users"}`
- 403 if `reached < requires`. Server ssh's `intern@localhost` (lab) and runs
  the lab's `check`. Same response shape as /api/verify (points 150, clue none).

## POST /api/deduction  `{"suspect":"Dee Vider","evidence":["c-manifest","c-tmux"]}`
- Final act deduction (act 5 board). Correct + all required clues → sets
  `closed`, awards capstone points: `{"ok":true,"closed":true,"total":...}`.
- Wrong: `{"ok":false,"why":"The timeline doesn't point there yet."}` 400.

## GET /api/export
`application/json` download — full learner export:
`{"profile":{"rank":...,"total":...},"levels":[...],"puzzles":{...},"labs":{...},
 "clues":[...],"hints_used":{...},"closed":bool,"exported_at":"ISO8601"}`.
No secrets, no passwords.

## Scoring constants (from levels.yaml meta)
- base points by type: flag 100 · evidence 120 · task 150 · breather 80 ·
  boss 250 · capstone 300 · interactive 50 · lab 150.
- hint costs: [5, 15, 30]. ranks: Constable 0, Detective 800,
  Inspector 2000, Chief 3500.

## Security rules
1. Passwords (except `begin`) NEVER appear in any HTTP response.
2. Scores computed ONLY server-side; browser POSTs answers, never scores.
3. /api/verify etc. are idempotent-safe: replaying a passed level re-grants 0.
4. All grading happens over local ssh with `SSHpass`-style env password —
   never argv, never a log line, never `Set-Content`-style plaintext files
   in the image.
