# Nimbus Casebook — Phase 5 Test Plan (implementation spec)

Owner: Planner (research + spec only, no test code). Date: 2026-10-10.
Read before implementing (paths relative to `E:\linux-game`): `docs/AUTHORING.md`
(§3 solvability, §4 guardrails), `docs/API_CONTRACT.md`, `docs/STORY_BIBLE.md`
(48 chain + 6 interactive + 5 labs inventory), `docs/PHASE0_AUDIT.md` (§4 defers
exactly these suites), `linuxgame/tests/base_test.py`, `linuxgame/tests/run-base-test.ps1`,
`linuxgame/tests/ssh-runner/Dockerfile`, `linuxgame/docker-compose.yml`,
`linuxgame/Dockerfile`, `linuxgame/game/server.py`, `game/setup.py`, `game/entrypoint.sh`,
`game/mark.sh`. Confidence HIGH = verified by reading those files today; every invented
mechanism is tagged `PLAN:` and needs Commander confirmation before coding.

## 0. The two test worlds (verified from the repo)

| world | guarantees | limits |
|---|---|---|
| **tester container** (`linux-game-tester`, compose profile `tests`, `docker compose --profile tests run --rm tester [cmd]`) | ubuntu 24.04 + `sshpass` + `python3` + `pyyaml`; reaches `game:9021`, `game:22`, `lab:22` by service name; image COPYs `tests/base_test.py` + `game/levels.yaml` to `/opt/test/` (`tests/ssh-runner/Dockerfile`) | no docker CLI: cannot `docker exec`, rebuild or mount |
| **host** (PowerShell 7 + python 3.12 + pyyaml + docker CLI — all verified on this machine) | drives `docker compose build/up/run/exec`, HTTP to `127.0.0.1:9021`, repo file IO | **no sshpass: every password-SSH assertion MUST run in the tester container** |

Base-suite world (existing): `tests/run-base-test.ps1` = build → `up -d` → TCP-probe
9021/2222/2223 → `truncate` progress → `docker compose --profile tests run --rm tester`
→ host greps progress for `level0`/`level1` → exit 0 only if all 21 in-container checks
plus the host PAM proof pass.
Agent-runner rule: invoke this suite's entrypoint whitespace-safe, e.g.
`powershell -ExecutionPolicy Bypass -File linuxgame\tests\run-all.ps1` (no quotes,
pipes, `$`, `;` in the command line).

## 1. Suite inventory

Common contract for every suite below: python 3 stdlib + pyyaml only; one
`[PASS]/[FAIL] <name> -- <detail>` line per assertion (same style as `base_test.check`);
final line `ALL CHECKS PASSED` or `FAILED n check(s):` list; exit 0 iff no failures,
exit 1 otherwise.

### 1.1 base (existing, must stay green) — `tests/base_test.py`
- Runs in the tester container via `run-base-test.ps1` (21 checks + host PAM grep).
- MODIFY (Phase 4, todo S3.1): line ~174 `get("/api/hint?n=0")` becomes
  `POST /api/hint` body `{"n":0}` expecting 200 JSON `{hint,cost,total,index}`;
  after the change the file must contain no GET `/api/hint` call.
- PLAN: if Phase 4 removes passwords from `game/levels.yaml`, add
  `COPY game/secrets.yaml /opt/test/secrets.yaml` to the tester Dockerfile and make
  line 141 compare `start_password` against the level-0 entry of secrets.

### 1.2 `tests/solve_all.py` — solvability harness (host world)
Purpose: prove AUTHORING §3 for all 48 chain levels, all 5 labs, plus gate sanity.
Test-time-only inputs (host paths, mounted `:ro`, never in any image):
`solutions/solutionbook.yaml` (PLAN schema: `solutions: {L0: <bash>, ..., <lab-id>: <bash>}`),
`game/secrets.yaml` (PLAN key shape per `tools/gen_secrets.py` S2.3.1),
`game/levels.yaml` (ids, types, `verify` scripts), `tests/_solve_level.sh` (executor, PLAN).
Mechanism per chain level N (0..47), one throwaway container per level so state is pristine:

    docker compose run --rm --no-deps --entrypoint bash
      -v <abs>/solutions/solutionbook.yaml:/tmp/solve/book.yaml:ro
      -v <abs>/game/secrets.yaml:/tmp/solve/secrets.yaml:ro
      -v <abs>/tests/_solve_level.sh:/tmp/solve/run.sh:ro
      game /tmp/solve/run.sh N

(`compose run` starts from the built image = post-`setup` homes, publishes no ports,
so the live game container is untouched.) Executor steps, all inside that container:
1. pristine `verify` (script from levels.yaml, run via `su levelN -c …`): must exit
   **non-zero**; levels without `verify` record `no-verify` and skip (verify is
   mandatory only for `task`/`boss`/`capstone` and labs).
2. run `solution` as `levelN` with env `NEXT_PW=secrets[N+1]` (`""` for N=47):
   last **non-empty** stdout line must equal `secrets[N+1]` for N<47; N=47 (capstone)
   has no password requirement — only step 3.
3. `verify` again: must exit **0** where declared.
Labs (5 ids from STORY_BIBLE): same flow as `intern` (sudo allowed), no password line,
`verify` mandatory, run against throwaway `lab` containers.
Phase gates: every `interactive` and `labs` entry must satisfy
`0 <= requires < len(levels)` (48) and `requires` must name a chain level that exists
in levels.yaml — out-of-range/`requires` on a missing level = unsatisfiable gate = FAIL.
Output: per-row table `L0..L47 | PASS/FAIL | reason`, `lab <id> | …`, `gates | n checked`;
exit nonzero on any failing row.
PLAN (Commander picks ONE): the throwaway `compose run` flow above, or the planned
Dockerfile *validator stage* (todo S3.3) built with BuildKit bind mounts whose report
lines `SOLVE L<n> PASS|FAIL <reason>` the suite parses.

### 1.3 `tests/isolation.py` — PAM/marking & reset (split across both worlds)
Phase A — tester container (needs sshpass), same `-tt` session helpers as base_test:
- wrong password `sshpass -p wrong ssh level2@game` → rc != 0 AND progress file
  unchanged AND `/api/state.reached` unchanged AND `/api/level?n=2` → 403.
- correct `level1` login → progress gains exactly the line `level1`, `reached==1`,
  level 1 → 200, levels 2 **and 3** → 403 (API form of "N+2 unreachable without
  clearing N+1").
- correct `level3` login → exactly `level3` appended, `reached==3`, level 4 → 403:
  a login advances only the level authenticated as; nothing above appears.
- FS form (PLAN: depends on home modes written by `setup.py` — line 15 `chmod -R
  u+rw…` must leave homes unreadable by other level users): as `level1`, reading the
  file in `/home/level2` holding `secrets[3]` must be permission-denied.
Phase B — host, run by run-all after it executes `docker compose down` then
`docker compose up -d`: `python tests/isolation.py --phase reset` asserts
- challenge reset (guardrail "down && up restores clean state"): a file deleted in
  Phase A (`/home/level0/readme.txt`) is back with content; junk the learner dropped
  in `/home/level0` is gone;
- **progress/scores semantics — both checked**: `docker-compose.yml` declares no
  volumes (verified), so today down/up also wipes progress and scores. Default spec
  asserts `reached==0` and scores file absent after up. PLAN (Commander): if
  progress/scores should SURVIVE down/up, add `volumes: [game-data:/var/lib/game]`
  and flip both assertions to "preserved"; the suite ships a flag
  `--expect full-reset|persist` (default `full-reset`).

### 1.4 `tests/secrets_leak.py` — leak hunt (host world)
Secret list = every value in `game/secrets.yaml` except `begin`. Feed all patterns to
grep in one file (`grep -RIf /tmp/pw.patterns <root>`) = one pass per root.
1. Learner-readable scan: `docker exec -u level0 linuxgame grep -RIl` over
   `/home /tmp /var /usr /etc` (exclude `/etc/shadow /etc/gshadow /proc /sys /dev`):
   `secrets[1]` appears ONLY under `/home/level0/` (its designed plant); `secrets[N]`
   for N>=2 gets 0 hits; `begin` ignored.
2. App/image files as root: `/opt/game /usr/local /etc/issue.net /var/lib/game /srv
   /root` plus `/var/www` (checked even though the image creates it never) → 0 hits
   for any non-`begin` password; this covers the served `index.html`.
3. Image metadata: `docker history --no-trunc linux-game` and `docker inspect`
   (`Config.Env`, `Config.Cmd`, `Args`) → 0 hits. PLAN optional/slow (~1 min):
   stream `docker save` layer tars through grep for full layer coverage.
4. HTTP crawl (host urllib) over every endpoint incl. error and fuzz paths: GET
   `/`, `/index.html`, `/api/state`, `/api/commands`, `/api/casebook`, `/api/export`,
   `/api/level?n=` x {0..47, -1, abc, 9999, empty}; POST `/api/hint`, `/api/verify`,
   `/api/puzzle`, `/api/labverify`, `/api/deduction` with valid and invalid bodies:
   no 2xx/4xx body contains any secret except `begin`; and assert
   `/api/state.start_password == "begin"` (the one password that IS served).
5. Runtime traces while a grading call is in flight: `grep -aHf /tmp/pw.patterns
   /proc/[0-9]*/cmdline` inside game → 0 hits (contract rule 4: password via env,
   never argv); `docker logs linuxgame` → 0 hits; contents of
   `/var/lib/game/scores.json` → 0 hits.
6. `/api/hint` GET removal: `GET /api/hint?n=0` must NOT return a hint (any 200
   carrying `hint` text = FAIL; PLAN: exact post-Phase-4 status 404/405 follows the
   server router). Pairs with the base_test POST conversion in §1.1.

### 1.5 `tests/abuse.py` — API hardening (host world)
State setup via `docker exec` using subprocess list args (no shell): set reached by
truncating + writing `level<k>` into `/var/lib/game/progress`; seed/drop
`/var/lib/game/scores.json` (PLAN: seed schema = contract `scores` object; server
recomputes `total`). Checks, each citing API_CONTRACT:
- `POST /api/verify {n: reached+1}` → 403; `{n:9999}` → 403; `{n:-1}` / `{n:"7"}` /
  missing `n` → 400.
- Score tampering: add `points/total/score/scores/by_level` fields to valid POSTs →
  grants stay server-side (verify 150 / puzzle 50) and `/api/state.scores.total`
  never reflects client values (contract security rule 2).
- Oversized body (5 MB) to every POST endpoint → handled 400, then `/api/state`
  still answers 200 (server survived).
- Malformed JSON (`{broken`, empty body, wrong types) → 400, never 5xx, server alive.
- Path traversal: `/api/level?n=../../etc/passwd`, `/api/level?n=%2e%2e%2f`,
  `/../etc/passwd`, `/api/export?file=/etc/shadow` → 4xx; no body ever contains
  `root:x:0:0` or file content.
- `/api/export` contains no password from the secrets list (contract: "No secrets").
- Replay idempotency: `POST /api/puzzle {"id":"match-1","answer":<answer read from
  levels.yaml>}` twice → first `ok:true` + 50 pts, replay `ok:true` + **0**; graded
  path: run L7's solution in the live game via the §1.2 executor (`docker exec`),
  then `POST /api/verify {"n":7}` twice → second grants `points:0`
  (contract rule 3; PLAN response shape `{"ok":true,"points":0,…}`).
- `POST /api/hint` with emptied scores → 409 `{"error":"low_score"}`; `n>reached` →
  403; after seeding 500 pts and spending all 3 hints → 403 `no_more`.

### 1.6 `tests/offline.py` — no network egress (host world)
Static scan (deterministic, containers optional): `game/index.html`, `game/server.py`,
`game/levels.yaml`, `commands/commands.yaml` plus live bodies (`GET /`,
`/api/commands`, `/api/casebook`, reachable `/api/level?n=…`): any `http(s)://` or
bare hostname that is not `localhost`/`127.0.0.1` → FAIL (AUTHORING §4 offline rule).
CSS/HTML specifics: no remote `@import`, no `url(http…)`, no tokens
`cdn.|jsdelivr|unpkg|googleapis|fonts.gstatic`, no `<link rel=stylesheet href=http`,
no external `<script src`.
Runtime: with the stack up and one live ssh session, `docker exec linuxgame
ss -tnH state established` (repeat for `linuxlab`) → every peer must be loopback or
the compose subnet (172.16/12); any public peer = FAIL.
PLAN: egress-blocked run via `tests/offline.compose.yml` override setting
`networks: {default: {internal: true}}`, then assert in-container
`curl -m 5 http://1.1.1.1` fails while `127.0.0.1:9021` still answers; Worker must
first confirm published ports stay host-reachable on an `internal` network, else run
all HTTP checks through `docker exec` (`--in-container` mode).

### 1.7 `tests/examples_run.py` — every chip example executed (host world)
Source: merged `commands/commands.yaml`, every `examples[].cmd`.
Population and user mapping:
- `safe:true` + `runtime:image` → game container, run as user `scratch`
  (PLAN: created once by the harness — `docker exec linuxgame useradd -m -s /bin/bash
  scratch` when absent — `HOME=/home/scratch`; never a level user, so level homes stay
  pristine).
- `safe:true` + `runtime:lab` → lab container as `intern` (lab has no secrets),
  counted in a separate bucket.
- `safe:false` → skipped, counted `unsafe_skipped`.
- tty-bound commands by name (`nano vim less more top htop watch tmux yes`) → skipped,
  counted `tty_skipped`, listed (they need a pty or Ctrl-C; this is a spec rule).
- cwd/fixture rules: every example runs with `cwd=/tmp/ex/<index>` (created first);
  `tests/fixtures/scratch/` (PLAN fixture dir: a few text files, a small tree, one
  plain archive) is `docker cp`'d to `/home/scratch/` at suite start; examples needing
  anything else are skipped with reason `missing-fixture` and listed by name — never
  silently dropped.
Assertion: exit code **0** within a 10 s timeout ("safe" = returns to the prompt
cleanly); timeout = FAIL unless on the tty skip list. PLAN optional schema extension:
per-example `expect_rc`.
Output: `ran X | passed Y | unsafe_skipped Z | tty_skipped W | fixture_skipped V` plus
the failing commands; exit nonzero on any ran-but-failed example.

## 2. Runner — `linuxgame/tests/run-all.ps1`
Calls the existing base runner (no logic duplication), then each suite, aggregates:

    param([switch]$Rebuild,[switch]$Down)          # same switches as run-base-test.ps1
    $ErrorActionPreference = "Stop"
    Push-Location (Split-Path -Parent $PSScriptRoot)   # linuxgame\
    $results = [ordered]@{}; $code = 0
    & "$PSScriptRoot\run-base-test.ps1" -Rebuild:$Rebuild   # build+up+21 checks+PAM
    $results["base"] = $LASTEXITCODE; if ($LASTEXITCODE) { $code = 1 }
    python "$PSScriptRoot\solve_all.py";   $results["solve_all"] = $LASTEXITCODE
    docker compose --profile tests run --rm tester python3 /opt/test/isolation.py  # phase A
    $results["isolation"] = $LASTEXITCODE
    python "$PSScriptRoot\isolation.py" --phase reset    # compose down && up -d + checks
    if ($LASTEXITCODE) { $results["isolation"] = 1 } else { $results["isolation"] = 0 }
    python "$PSScriptRoot\secrets_leak.py"; $results["secrets_leak"] = $LASTEXITCODE
    python "$PSScriptRoot\abuse.py";        $results["abuse"] = $LASTEXITCODE
    python "$PSScriptRoot\offline.py";      $results["offline"] = $LASTEXITCODE
    python "$PSScriptRoot\examples_run.py"; $results["examples_run"] = $LASTEXITCODE
    foreach ($k in $results.Keys) { if ($results[$k]) { $code = 1 }
        Write-Host ("[{0}] {1}" -f ($(if ($results[$k]) {"FAIL"} else {"PASS"}), $k)) }
    Write-Host "OVERALL: $(if ($code) {'FAIL'} else {'PASS'})"
    if ($Down) { docker compose --profile tests down }
    exit $code

Rules: after phase B's `down/up`, poll `GET http://127.0.0.1:9021/api/state` until 200
(max 90 s) before suite 4; every `docker compose run` uses `--rm`; `finally { Pop-Location }`.
PLAN (tester image): `tests/ssh-runner/Dockerfile` gains `COPY tests/*.py /opt/test/`
so `isolation.py` runs in-container; shared helpers (`check`, `wait_until`,
`ssh_base`, `reset_state`) live in `tests/_common.py`, imported by both base_test and
isolation (refactor, not rewrite).

## 3. Fixtures & data flow
- **Test-time-only inputs**: `solutions/solutionbook.yaml` and `game/secrets.yaml`
  reach containers only as `:ro` bind mounts (`compose run -v`) or `docker cp` into
  `/tmp/solve/`; no Dockerfile stage may `COPY` them. PLAN (Phase 4 decision this plan
  depends on): how the runtime server reads passwords — recommended
  `volumes: [./game/secrets.yaml:/run/secrets/secrets.yaml:ro]` on `game` so image
  layers stay clean (required by §1.4.2); the alternative (passwords stay inside
  `levels.yaml` in the image) must formally allowlist that file in §1.4.2 — a
  guardrail weakening that needs Commander sign-off.
- **Volumes**: none declared in `docker-compose.yml` (verified) → plain `down`
  (no `-v` needed) recreates containers from images; suites mutate state only inside
  containers via `docker exec`; nothing is written to the host by resets.
- **Reset between suites**: stateful suites assume `reached==0` + empty scores and
  call `reset_state()` (`truncate -s 0 /var/lib/game/progress` + `rm -f
  /var/lib/game/scores.json`, in `tests/_common.py`) in their preamble: base/isolation-A
  get it from run-base-test, secrets_leak, abuse, offline call it themselves.
  solve_all and examples_run need no reset (throwaway/scratch isolation). The single
  full restart is isolation phase B (`down && up -d`), which doubles as the reset proof.
- **Time budgets** (docker build excluded): base 4-6 min · solve_all 8-15 min
  (53 throwaway containers) · isolation 5-8 min (A+B incl. health waits) ·
  secrets_leak 3-6 min · abuse 2-4 min · offline 1-3 min (30 s socket window) ·
  examples_run 5-10 min (~150 commands, 10 s cap each) → full pass ≈ 30-55 min + build.
- **Cleanup traps**: every python suite wraps its body in `try/finally` removing
  `/tmp/solve`, `/tmp/ex`, `/tmp/examples`, `/tmp/pw.patterns` in game and lab,
  plus `userdel -r scratch`; throwaways rely on `--rm`; run-all uses `finally` for
  `Pop-Location` and `-Down` for teardown; a Ctrl-C'd run leaves at most throwaway
  containers, cleared by the next run's phase-B `down`.

## 4. Failure triage
| Symptom | Likely root cause | Owning file |
|---|---|---|
| `L<n>` solution last line != password | extra echo / wrong var in solution | `solutions/solutionbook.yaml` entry `L<n>` |
| pristine verify already PASSes | verify ignores post-setup state, or setup planted wrong | `game/levels.yaml` `setup`/`verify` of L<n> |
| verify still fails after solution | solution doesn't do the task, or verify too strict | `solutionbook.yaml` first, then `levels.yaml` |
| "chip not in commands.yaml" / coverage fail | shard merge incomplete (todo S2.2.6) | `commands/_shard*.yaml` → `commands/commands.yaml` |
| password found under `/opt/game` or image config | secrets baked by `COPY`/`ARG` at build | `Dockerfile` + `game/setup.py` + PLAN secrets delivery (§3) |
| `GET /api/hint` still returns a hint | Phase 4 kept the legacy GET route | `game/server.py` `do_GET`, then `tests/base_test.py:174` |
| wrong `reached` mid-suite (200 where 403 expected) | stale progress lines from earlier logins | suite preamble `reset_state()` in `tests/_common.py` |
| down/up test: challenge files not restored | setup non-idempotent or file written outside `/home/levelN` | `game/setup.py`, `game/entrypoint.sh` |
| example exits 127 | command not installed in the image | `linuxgame/Dockerfile` apt list vs chip `name` |
| example hangs to timeout | interactive cmd missing from tty skip list / bad `safe` flag | `commands/commands.yaml` example or §1.7 skip list |
| hint never returns 409 | scores seed absent or wrong schema | `game/server.py` scores loading + §1.5 seed PLAN |
| replay still grants points | endpoint not idempotent | `game/server.py` `/api/verify`, `/api/puzzle` |
| external URL flagged in HTML/CSS | CDN/font/remote asset link | `game/index.html` |
| password-SSH suite fails on host | suite run in the wrong world (host has no sshpass) | move the check into the tester container (§0) |

PLAN items needing Commander decision before implementation: (1) `solutionbook.yaml`
and `secrets.yaml` schemas; (2) solve_all mechanism — throwaway `compose run` vs
Dockerfile validator stage; (3) runtime secrets delivery (bind mount vs in-image
allowlist) — gates §1.4.2; (4) progress/scores persistence across `down/up`
(full-reset vs named volume); (5) offline compose override port reachability;
(6) optional `expect_rc` field; (7) tester Dockerfile `COPY tests/*.py` +
`tests/_common.py` refactor; (8) L7 live-solution replay step inside abuse.
