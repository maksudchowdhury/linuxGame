# Phase 0 Audit — Nimbus Casebook

Date: 2026-10-10 · Scope: read the repo, list bugs/risks/untested assumptions, fix defects,
add the base test (login on each service works, dashboard follows the SSH session).

## 1. Defects found and fixed

| # | Where | Problem | Fix |
|---|-------|---------|-----|
| D1 | `Dockerfile` | Image missing packages required by `commands-to-incorporate.txt`: `cpio`, `rename`, `locate`, `nc`, `traceroute`, `which`, `cal` | Added `cpio rename plocate netcat-openbsd traceroute which ncal` (`ncal` provides `/usr/bin/cal` in Ubuntu 24.04 — verified; `bsdextrautils` alone does **not** ship `cal`) |
| D2 | `Dockerfile` | `locate` database never built → `locate`/`updatedb` useless offline | `updatedb` runs at build time; `/etc/updatedb.conf` prunes `/home /opt /var/lib /proc /sys /dev …` so the world-readable db cannot leak other levels' home filenames or game internals (guardrail). Verified: `locate` works as `level0`; `locate secret` returns **no** `/home` paths |
| D3 | `entrypoint.sh` | If `sshd` failed to start, the container still "worked" (dashboard only) → silent broken state | `set -eu`; after starting sshd, poll port 22 for up to 10 s and **exit 1** if it never listens |
| D4 | `mark.sh` | Accepted and logged **any** `PAM_USER`; unquoted empty vars | Only `levelN` (1–2 digits) users are recorded; safe defaults for empty variables |
| D5 | `sshd_game.conf`, lab conf | Spec requires low `MaxAuthTries`; empty-password and keyboard-interactive logins not explicitly banned | `MaxAuthTries 3`, `LoginGraceTime 30`, `PermitEmptyPasswords no`, `KbdInteractiveAuthentication no` on both services. Verified via `sshd -T` at runtime (game: `allowusers level*`; lab: `allowusers intern`) |
| D6 | `docker-compose.yml` | Spec guardrail: add `ulimit nproc/nofile` so a fork bomb cannot hurt the host (`pids_limit` alone was present) | `ulimits: nofile 1024/2048, nproc 256/512` on both services |
| D7 | `docker-compose.yml` | No healthchecks → tests cannot wait deterministically | game = port 22 **and** `/api/state` respond; lab = port 22 responds; both reach `healthy` |
| D8 | `Dockerfile` (game) | PAM patch loop would **silently create a broken** `/etc/pam.d/<name>` containing *only* the pam_exec line if `sshd`/`su`/`su-l` were missing (su would then skip `common-session`) | Loop now **fails the build** if any of the three files is absent; prints which files were patched (build log: all three exist on Ubuntu 24.04 ✓) |
| D9 | repo root | No `.gitattributes` → on a Windows clone Git converts LF→CRLF (guardrail: LF everywhere) | Added `.gitattributes` (`* text=auto eol=lf`, `*.bat eol=crlf`) + `.gitignore`; Dockerfile's `\r`-strip of copied files kept as second line of defence |
| D10 | repo root | Not a git repo although the protocol requires "one logical change per commit" | `git init`; baseline commit, then one commit per logical change |
| D11 | `tests/base_test.py` | Test bug (found by running it): non-interactive `ssh cmd` gets **no pty**, so `connected()` (tty scan) correctly ignored it → false failure | Sessions spawn with `-tt` (forced pty), exactly like a real learner login; also added a **level1 login** so the PAM→progress→API chain is observable (`reached` 0→1 — a level0 login alone cannot change `reached`, so it proved nothing) |

## 2. Risks noted (accepted for now, tracked)

- **Image size**: `linux-game` 630 MB, `linux-lab` 629 MB (includes `unminimize` docs/man; both share the same base layer in the tar). Budget + `unminimize` note formalised in Phase 7.
- **`/var/lib/game/progress` grows** by one line per login. Negligible in practice; no rotation (documented limit).
- **`connected()` heuristic** = "newest live tty process owned by a levelN user". A stray background process holding a tty after logout would keep the dashboard on that level until it exits; `docker compose down && up -d` always clears it.
- **Base image not digest-pinned** (`ubuntu:24.04`): digest noted below; formal pinning optional in Phase 7 (build must stay reproducible on `linux/amd64`).
- **Lab `intern` password is public** (`learn`) — by design, the lab holds no secrets.
- **Tester image** (`linux-game-tester`, 197 MB) carries `game/levels.yaml` (passwords) — test-only artifact, profile `tests`, never started by a plain `up -d`, never exported by `build.bat`.

## 3. Untested assumptions carried by the original repo → verified this phase

| # | Assumption | Verification | Result |
|---|-----------|--------------|--------|
| A1 | Image builds on Windows with internet (`unminimize` + apt behave) | `docker compose build` | **PASS** — build succeeds; build log shows PAM hook installed in sshd, su, su-l |
| A2 | sshd password logins work under Docker default capabilities | base test: `level0` and `intern` logins over SSH | **PASS** |
| A3 | PAM `pam_exec` hook fires for `sshd` logins and runs privileged enough to append to the root-owned progress file | base test: level1 login ⇒ API `reached` 0→1; host check: `docker exec … grep level0/level1 progress` | **PASS** (both) |
| A4 | `server.py` as unprivileged `gameserver` reads progress + `/proc` correctly in-container | base test: `/api/state` transitions null→0→null→1→null | **PASS** |
| A5 | `lab` container: `intern` can sudo with a real password | base test: `echo learn \| sudo -kS id -u` → `0` | **PASS** |
| A6 | Host port bindings `127.0.0.1:9021/2222/2223` reachable | orchestrator TCP-connects to each port | **PASS** |
| A7 | Scripts copied into the image execute (line endings) | build runs `setup.py`; entrypoint runs; healthchecks pass | **PASS** |
| A8 | Healthchecks valid; services reach `healthy` | `docker compose ps` → both `healthy` | **PASS** |
| A9 | `locate`, `man`, `cal`, and the newly added packages actually work in the image | `command -v` sweep, `man -w find`, `locate` as `level0`, `cal` | **PASS** (`cal` initially missing → D1 fixed) |
| A10 | sshd drop-in config actually wins (first-value-wins semantics) | `sshd -T` inside both containers | **PASS** (values listed in D5) |

## 4. Test results (final gate for Phase 0)

Runner: `powershell -ExecutionPolicy Bypass -File tests\run-base-test.ps1`
(builds both images, starts compose, checks host ports, truncates the progress file,
runs the checks in the tester container, verifies the PAM hook from the host).

Final run (with `ncal` in the image), exit code 0:

```
== Phase 0 base test ==  game=game lab=lab levels=6
[PASS] dashboard GET / answers within 90s
[PASS] dashboard shows welcome screen
[PASS] initial: nobody connected
[PASS] initial: reached == 0 (progress truncated by runner)
[PASS] initial: total matches levels.yaml
[PASS] initial: public start password is level0's
[PASS] initial: only level 0 is open
[PASS] locked level /api/level?n=1 -> 403
[PASS] open level /api/level?n=0 -> 200
[PASS] lab: ssh intern@lab works
[PASS] lab: intern can sudo (real password)
[PASS] game: dashboard follows level0 SSH session
[PASS] while connected: level 1 still 403
[PASS] while connected: /api/hint?n=0 -> 200
[PASS] after level0 logout: connected back to null
[PASS] game: dashboard follows level1 SSH session
[PASS] PAM chain: reached advanced to 1 on level1 login
[PASS] level1 now readable via API
[PASS] level 2 still locked -> 403
[PASS] after level1 logout: connected back to null
[PASS] after level1 logout: reached stays 1 (persisted)
------------------------------------------------------------
ALL CHECKS PASSED
[PASS] PAM hook recorded level0 and level1 in /var/lib/game/progress

compose status:  linuxgame  Up (healthy)   127.0.0.1:9021->9021/tcp, 127.0.0.1:2222->22/tcp
                 linuxlab   Up (healthy)   127.0.0.1:2223->22/tcp
```

Also verified manually (host): `sshd -T` values on both services (D5),
`cal`/`locate`/`man` work in the image (A9), image sizes game 630 MB / lab 629 MB.

**Not verified in Phase 0** (deferred to Phase 1's full harness, as scoped by the spec):
abuse/reset cycle (`rm -rf`, fork bomb, `down && up`), full-solvability run of all levels,
API secret-leak crawl, isolation matrix, no-internet run of the whole stack.

